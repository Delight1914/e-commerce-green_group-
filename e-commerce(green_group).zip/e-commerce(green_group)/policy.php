<?php ob_start(); session_start(); include_once("inc/header.nav.php"); ?>
<div id="privacy_policy_page">
    <div class="cont_wrapper">
        <ul class="breadcrumb">
            <li><a href="./">Home</a></li><li><a href="javascript:void(0)">Help</a></li><li>Privacy policy</li>
        </ul>
    </div>
    <div class="title_container px-3 py-0">
        <div class="cont_wrapper"><h4 class="page_title text-center text-md-left m-0 text_capital">Privacy policy</h4></div>
    </div>
    <div class="page_banner my-3"></div>
    <div class="content_content_wrapper bg-white p-4">
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam quasi necessitatibus odio aperiam tenetur cupiditate vero sunt obcaecati accusantium earum.
        </p>
        <dl>
            <dt>Information That We Collect From You</dt>
            <dd>
               Lorem ipsum dolor sit amet consectetur adipisicing elit. Omnis deserunt molestias et tenetur maxime dolorem reprehenderit temporibus consequuntur repellendus incidunt.
            </dd>
            <dt>Use of your Information</dt>
            <dd>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam a dolores sapiente minus beatae, similique fuga quaerat nihil aut neque iure. Odit itaque eligendi omnis ea velit qui id sint.
            </dd>
            <dt> IP Address and Cookies</dt>
            <dd>
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Fuga, perferendis a? Inventore fugiat aperiam doloremque!

            </dd>
            <dt>Security and Data Retention</dt>
            <dd>
                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quam eos id quisquam aliquam dolores laborum odit accusantium, vero beatae voluptatum!
            </dd>
            <dt>Accessing and Updating</dt>
            <dd>
                Lorem ipsum dolor sit, amet consectetur adipisicing elit. Eaque aut fugit voluptatem quod nemo perferendis id temporibus. Accusamus, quisquam placeat!
            </dd>
            <dt>Changes to Our Privacy Policy</dt>
            <dd>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquam saepe error quae provident atque modi laboriosam. Vitae cupiditate numquam impedit.
            </dd>
        </dl>
    </div>
</div>
<?php include_once("inc/footer.nav.php"); ?>