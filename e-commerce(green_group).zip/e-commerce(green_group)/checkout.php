<?php ob_start(); session_start(); include_once("inc/header.nav.php"); ?>
<?php
echo "<script>
    var cart = JSON.parse(localStorage.getItem('shoppingCart'));
    if (typeof cart ==='undefined' || cart === null || cart.length === null || cart.length < 1 ) {
        window.location.replace('cart')
    }
    </script>";
$cid = isset($_SESSION['user_login']['customer_id'])?$_SESSION['user_login']['customer_id'] : 0;
include_once('controllers/config/database.php');
include_once('controllers/classes/User.class.php');
$db = new Database();
$user = new User($db->connect());
$address = $user->get_latest_shop_to_address($cid);
?>
<div class="container mt-5" id="checkout_page">
    <section class="row">
        <div class="col-lg-9" style="margin: 0 auto;">
            <div class="title_wrapper p-3"><h4 class="text_upper m-0">Check out</h4></div>
            <form name="checkout" id="checkout">
                <div class="bg-white mb-3">
                    <fieldset class="">
                        <legend class="border-bottom text_upper p-3">1. Receiver’s Details</legend>
                        <div class="p-3">
                            <div class="row">
                                <div class="col-12 col-md-6 mb-4">
                                    <div class="form_grp">
                                        <label class="text_capital d-block" for="firstname">First Name</label>
                                        <input type="text" class="d-block w-100" name="firstname" id="firstname"
                                               value="<?php
                                               if (isset($_SESSION['user_login_temp']['temp_fname'])) echo $_SESSION['user_login_temp']['temp_fname'];
                                               else if (isset($_SESSION['user_login']['firstname'])) echo $_SESSION['user_login']['firstname'];
                                               else echo "";
                                               ?>">
                                    </div>
                                </div>
                                <div class="col-12 col-md-6 mb-4">
                                    <div class="form_grp">
                                        <label class="text_capital d-block" for="lastname">Last Name</label>
                                        <input type="text" class="d-block w-100" name="lastname" id="lastname"
                                               value="<?php
                                               if (isset($_SESSION['user_login_temp']['temp_lname'])) echo $_SESSION['user_login_temp']['temp_lname'];
                                               else if (isset($_SESSION['user_login']['lastname'])) echo $_SESSION['user_login']['lastname'];
                                               else echo "";
                                               ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-6 mb-4">
                                    <div class="form_grp">
                                        <label class="text_capital d-block" for="email">Email Address</label>
                                        <input type="text" class="d-block w-100" name="email" id="email"
                                                value="<?php
                                                if (isset($_SESSION['user_login_temp']['temp_email'])) echo $_SESSION['user_login_temp']['temp_email'];
                                                else if (isset($_SESSION['user_login']['email'])) echo $_SESSION['user_login']['email'];
                                                else echo "";
                                                ?>">
                                    </div>
                                </div>
                                <div class="col-6 mb-4">
                                    <div class="form_grp">
                                        <label class="text_capital d-block" for="phone">Phone number</label>
                                        <input type="text" class="d-block w-100" name="phone" id="phone"
                                               value="<?php
                                               if (isset($_SESSION['user_login_temp']['temp_phone'])) echo $_SESSION['user_login_temp']['temp_phone'];
                                               else if (isset($_SESSION['user_login']['phone'])) echo $_SESSION['user_login']['phone'];
                                               else echo "";
                                               ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-12 col-md-8 mb-4">
                                    <div class="form_grp">
                                        <label class="text_capital d-block" for="address">Street Address</label>
                                        <input type="text" class="d-block w-100" name="address" id="address"
                                               value="<?= ($address !== false)?$address['receiver_address']:'';?>">
                                    </div>
                                </div>
                                <div class="col-5 col-md-4 mb-4">
                                    <div class="form_grp">
                                        <label class="text_capital d-block" for="state">State</label>
                                        <div class="select_drop_wrapper">
                                            <select name="state" id="state" class="w-100">
                                                <option value="">-Select-</option>
                                                <option value="Abia" <?= ($address!==false && $address['receiver_state']=='Abia')?'selected':'';?>>Abia</option>
                                                <option value="Adamawa" <?= ($address!==false && $address['receiver_state']=='Adamawa')?'selected':'';?>>Adamawa</option>
                                                <option value="AkwaIbom" <?= ($address!==false && $address['receiver_state']=='AkwaIbom')?'selected':'';?>>AkwaIbom</option>
                                                <option value="Anambra" <?= ($address!==false && $address['receiver_state']=='Anambra')?'selected':'';?>>Anambra</option>
                                                <option value="Bauchi" <?= ($address!==false && $address['receiver_state']=='Bauchi')?'selected':'';?>>Bauchi</option>
                                                <option value="Bayelsa" <?= ($address!==false && $address['receiver_state']=='Bayelsa')?'selected':'';?>>Bayelsa</option>
                                                <option value="Cross River" <?= ($address!==false && $address['receiver_state']=='Cross River')?'selected':'';?>>Cross River</option>
                                                <option value="Delta" <?= ($address!==false && $address['receiver_state']=='Delta')?'selected':'';?>>Delta</option>
                                                <option value="Ebonyi" <?= ($address!==false && $address['receiver_state']=='Ebonyi')?'selected':'';?>>Ebonyi</option>
                                                <option value="Edo" <?= ($address!==false && $address['receiver_state']=='Edo')?'selected':'';?>>Edo</option>
                                                <option value="Ekiti" <?= ($address!==false && $address['receiver_state']=='Ekiti')?'selected':'';?>>Ekiti</option>
                                                <option value="Enugu" <?= ($address!==false && $address['receiver_state']=='Enugu')?'selected':'';?>>Enugu</option>
                                                <option value="FCT" <?= ($address!==false && $address['receiver_state']=='FCT')?'selected':'';?>>FCT</option>
                                                <option value="Imo" <?= ($address!==false && $address['receiver_state']=='Imo')?'selected':'';?>>Imo</option>
                                                <option value="Jigawa" <?= ($address!==false && $address['receiver_state']=='Jigawa')?'selected':'';?>>Jigawa</option>
                                                <option value="Kaduna" <?= ($address!==false && $address['receiver_state']=='Kaduna')?'selected':'';?>>Kaduna</option>
                                                <option value="Kano" <?= ($address!==false && $address['receiver_state']=='Kano')?'selected':'';?>>Kano</option>
                                                <option value="Katsina" <?= ($address!==false && $address['receiver_state']=='Katsina')?'selected':'';?>>Katsina</option>
                                                <option value="Kogi" <?= ($address!==false && $address['receiver_state']=='Kogi')?'selected':'';?>>Kogi</option>
                                                <option value="Kwara" <?= ($address!==false && $address['receiver_state']=='Kwara')?'selected':'';?>>Kwara</option>
                                                <option value="Lagos" <?= ($address!==false && $address['receiver_state']=='Lagos')?'selected':'';?>>Lagos</option>
                                                <option value="Nasarawa" <?= ($address!==false && $address['receiver_state']=='Nasarawa')?'selected':'';?>>Nasarawa</option>
                                                <option value="Niger" <?= ($address!==false && $address['receiver_state']=='Niger')?'selected':'';?>>Niger</option>
                                                <option value="Ogun" <?= ($address!==false && $address['receiver_state']=='Ogun')?'selected':'';?>>Ogun</option>
                                                <option value="Ondo" <?= ($address!==false && $address['receiver_state']=='Ondo')?'selected':'';?>>Ondo</option>
                                                <option value="Osun" <?= ($address!==false && $address['receiver_state']=='Osun')?'selected':'';?>>Osun</option>
                                                <option value="Oyo" <?= ($address!==false && $address['receiver_state']=='Oyo')?'selected':'';?>>Oyo</option>
                                                <option value="Rivers" <?= ($address!==false && $address['receiver_state']=='Rivers')?'selected':'';?>>Rivers</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </fieldset>
                    <input type="hidden" name="total_amount" id="total_amount">
                    <input type="hidden" name="order_shipping" id="order_shipping">
                    <input type="hidden" name="total_qty" id="total_qty">
                    <input type="hidden" name="s_email" id="s_email" value="<?= isset($_SESSION['user_login']['email'])?$_SESSION['user_login']['email']:""; ?>">
                    <input type="hidden" name="payment_ref" id="payment_ref">
                </div>
                <div class="bg-white mb-3">
                    <fieldset class="">
                        <legend class="border-bottom text_upper p-3">2. Payment Method</legend>
                        <div class="row p-3">
                            <div class="col-12 col-md-6">
                                <div class="form_grp mb-3">
                                    <input type="radio" class="radio_rej d-block w-100" name="payment_method" id="bank_transfer" value="BankTransfer" checked>
                                    <label class="text_capital" for="bank_transfer">
                                        <span class="custom_radio"></span>
                                        <span>Bank Transfer</span>
                                    </label>
                                </div>
                                <div class="show" id="seller_account_details">
                                    <ul>
                                        <li><p>Bank Account name:<br /><span>#### #### #### ####</span></p></li>
                                        <li><p>Bank Account Number:<br /><span>#### #### #### ####</span></p></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-12 col-md-6">
                                <div class="form_grp mb-3">
                                    <input type="radio" class="radio_rej d-block w-100" name="payment_method" id="third_party" value="DebitCard">
                                    <label class="text_capital" for="third_party">
                                        <span class="custom_radio"></span><span>Third-party payment interface</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </fieldset>
                </div>
                <div class="bg-white mb-3">
                    <fieldset class="">
                        <legend class="border-bottom text_upper p-3">3. SHIPPING </legend>
                        <h6 class="text-muted text-uppercase pl-3" style="font-size: 0.86em">Standard delivery (1-7 working days, not including weekends or public holidays)</h6>
                        <div class="row p-3 shippingFee">
                            <div class="col-12">
                                <div class="form_grp mb-3">
                                    <input type="radio" class="radio_rej shipping_option" name="shipping_option" id="shipping_option_one" value="shipStandardMain" checked>
                                    <label class="text_capital" for="shipping_option_one">
                                        <span class="custom_radio"></span><span>Lagos Mainland: ₦1,000</span>
                                    </label>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form_grp mb-3">
                                    <input type="radio" class="radio_rej shipping_option" name="shipping_option" id="shipping_option_two" value="shipNextIs">
                                    <label class="text_capital" for="shipping_option_two">
                                        <span class="custom_radio"></span><span>Lagos Island: ₦1,500</span>
                                    </label>
                                </div>
                            </div>
                            <p class="small text-muted font-italic pl-3">( Note: Delivery fee is subject to change depending on your location)</p>
                        </div>
                    </fieldset>
                </div>

                <!-- Order Summary -->
                <div class="order_summary_section">
                    <div class="title_wrapper p-3"><h5 class="text_upper m-0">Order Summary</h5></div>
                    <div class="bg-white mb-3">
                        <div class="p-3 border-bottom"><h6 class="m-0">YOUR ORDER ( <span class="total-count"></span>&nbsp;<span>ITEM</span> )</h6></div>
                        <div class="p-3 border-bottom">
                            <ul class="p-0">
                                <li><span>1</span>&nbsp;<span>Items</span></li>
                                <li>
                                    <div class="flex_just_spb">
                                        <div class="text_capital">Subtotal:</div><div><strong><span>₦</span>&nbsp;<span class="font-weight-bolder sub-total-cart"></strong></div>
                                    </div>
                                </li>
                                <li>
                                    <div class="flex_just_spb">
                                        <div class="text_capital">Shipping</div><div><span>₦</span>&nbsp;<span class="font-weight-bolder total-shipping"></div>
                                    </div>
                                </li>
                                <li>
                                    <div class="flex_just_spb">
                                        <div class="text_upper">Vat</div><div><strong>--</strong></div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div class="p-3">
                            <ul class="p-0">
                                <li>
                                    <div class="flex_just_spb">
                                        <div class="text_capital">Total to pay:</div><div><strong><span>₦</span>&nbsp;<span class="font-weight-bolder total-cart"></strong></div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="form-group text-center" style="display: flex; justify-content: center; flex-wrap: wrap">
                    <a href="cart" class="modify_cart_btn px-5 white_btn btn-lg mr-md-2 my-1 text_upper">Modify Cart</a>
                    <button type="submit" class="confirm_cart_btn px-5 green_btn btn-lg my-1 text_upper" id="checkout_btn">Confirm Order</button>
                </div>
            </form>
        </div>
    </section>
    <!-- Modal -->
    <div class="modal fade" id="payWithTransfer" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h6 class="modal-title" id="staticBackdropLabel">Enter sender account name(If transfer has been made)</h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form name="transfer_request_form" id="pay_with_transfer">
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="account_name" class="col-form-label">Sender Account Name:</label>
                            <input type="text" class="form-control" id="account_name" name="account_name">
                        </div>
                        <div class="form-group">
                            <label for="amount_transferred" class="col-form-label">Amount Transferred (₦)</label>
                            <input readonly type="text" class="form-control" id="amount_transferred" name="amount_transferred" />
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="white_btn btn-md py-2 px-5 rounded" id="pay_transfer_btn">
                            <i class="fa fa-spinner fa-spin mr-3 d-none"></i> Submit
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php  include_once("inc/footer.nav.php"); ?>