<?php ob_start(); if (!isset($_SESSION['temp_searched'])){session_start();}

include_once('controllers/config/database.php');
include_once('controllers/classes/Product.class.php');
include_once("controllers/classes/GlobalApi.class.php");

$db = new Database();
$connection = $db->connect();
$productCon = new Product($connection);

// Default limit
$limit = isset($_GET['per_page']) ? $_GET['per_page'] : 20;

// Default offset
$offset = 0;
$current_page = 1;
if(isset($_GET['page-number'])) {
    $current_page = (int)$_GET['page-number'];
    $offset = ($current_page * $limit) - $limit;
}

$whereSQL = $orderSQL = '';
//if(!empty($_GET['brand'])){
//    $brand = implode("','", $_GET['brand']);
//    $whereSQL .= " AND brand_id IN('" .$brand. "')";
//}
if(!empty($_GET['price_start']) && !empty($_GET['price_end'])){
    $whereSQL .= " AND (product_price BETWEEN ".$_GET['price_start']." AND ". $_GET['price_end'].")";
}
if(!empty($_GET['size'])){
    $size = implode("','", $_GET['size']);
    $whereSQL .= " AND product_size IN('".$size."')";
}
if(!empty($_GET['os'])){
    $os = implode("','", $_GET['os']);
    $whereSQL .= " AND product_os IN('".$os."')";
}
if(!empty($_GET['rate'])){
    $rate = implode("','", $_GET['rate']);
    $whereSQL .= " AND review_rate IN('".$rate."')";
}
if(!empty($_GET['sortBy'])){
    $orderSQL = " ORDER BY product_price ".$_GET['sortBy'];
} else {
    $orderSQL = " ORDER BY sno DESC ";
}

$query = $connection->query("SELECT tbl_product.*,tbl_review.review_rate FROM tbl_product LEFT JOIN tbl_review ON tbl_review.product_id=tbl_product.product_id
    WHERE product_title LIKE '%".$_SESSION['temp_searched']."%' $whereSQL $orderSQL");
if($query->num_rows > 0) {
    $latest_arr = array();
    while ($row = $query->fetch_assoc()){
        $latest_arr[] = array(
            "product_id" => $row['product_id'], "product_title" => $row['product_title'], "product_sku" => $row['product_sku'],
            "product_img" => $row['product_img'], "product_price" => $row['product_price'],
            "product_size" => $row['product_size'],"product_os" => $row['product_os'],"review_rate" => $row['review_rate']
        );
    }
    $products = $latest_arr;
    $paged_products = array_slice($products, $offset, $limit);
    $total_products = count($products);

// Get the total pages rounded up the nearest whole number
    $total_pages = ceil( $total_products / $limit );
    $paged = $total_products > count($paged_products) ? true : false;

    if (count($paged_products)) {
        foreach ($paged_products as $product) { ?>
            <div class="col-12 col-sm-4 col-lg-3">
                <div class="card product_card product_card_search_output shadow border-0 m-1">
                    <div class="row no-gutters">
                        <div class="col-6 col-sm-12">
                            <form class="wish_form flex_just_flexend p-1">
                                <div>
                                    <input class="wish_toggler" type="hidden" name="wish">
                                    <button class="<?=($productCon->fetch_all_wishlist_by_pid($product['product_id'])?'active ':'')?>wish_btn add_to_wlist"
                                            id="wBtn<?=$product['product_id']; ?>" data-id="<?=$product['product_id']; ?>"><i class="fas fa-heart"></i>
                                    </button>
                                </div>
                            </form>
                            <img src="admin/adminImg/products/<?=$product['product_img'];?>" class="card-img-top" alt="">
                        </div>
                        <div class="col-6 col-sm-12">
                            <div class="card-body">
                                <a href="details/<?=$product['product_sku'];?>">
                                    <h6 class="card-title text_capital">
                                        <?=(strlen($product['product_title'])>46)?substr($product['product_title'],0,46).'...':$product['product_title'];?>
                                    </h6>
                                </a>
                                <p class="card-text prod_price">₦ <?=$product['product_price'];?><br/>
                                    <span>
                                        <?php for ($i = 1; $i <= 5; $i++) {
                                            if ($i <=$productCon->read_average_review_rating($product['product_id'])) echo "<i class='fas fa-star'></i>";
                                            else echo "<i class='far fa-star'></i>";
                                        }
                                        ?>
                                    </span>
                                    <?php if($productCon->read_average_review_rating($product['product_id'])<=0){?>
                                        <small class="rating_info">(No review yet)</small>
                                    <?php } ?>
                                </p>
                                <button class="btn-block text_upper mt-2 py-1 light_grn_btn add-to-cart"
                                        data-title="<?= $product['product_title']; ?>"
                                        data-count="1"
                                        data-id="<?= $product['product_id']; ?>"
                                        data-price="<?= $product['product_price']; ?>"
                                        data-image="<?= $product['product_img']; ?>">Add to cart</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php }
        if ($paged) {require('pagination.php');}
    }  else {
        echo '<p class="alert alert-warning" >No Products found.</p>';
    }
} else {
    echo '<p class="alert alert-warning" >No Products found.</p>';
}