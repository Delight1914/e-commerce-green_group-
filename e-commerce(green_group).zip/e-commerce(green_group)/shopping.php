<?php ob_start(); session_start(); include_once("inc/header.nav.php"); ?>
    <style>
        #user_shopping_list .monthly_card .card-header {
            background: #c3df34 !important;
            opacity: 0.85;
        }
        .clist{color:#1F3200; background:#c3df34;}
        .clist:hover{color:#ffffff;}
    </style>
<div id="user_shopping_list">
    <div class="container my-3 d-none d-md-block"><h4 class="m-0 text_capital">Shopping List</h4></div>
    <div class="container my-3 d-block d-md-none">
        <button class="bo_back_history border-0" onclick="goBack()"><i class="fas fa-long-arrow-alt-left fa-2x"></i></button>
        <span class="">Order</span>
    </div>
    <section>
        <div class="text-center mb-5 py-3 page_banner">
            Create a shopping list of any item you want and have it delivered to your doorstep. Save time and money with our
            unique online shopping list feature.
        </div>
        <div class="container shopping-list-option-wrapper">
            <div class="row">
                <div class="col-12 col-md-6 text-center mr-auto ml-auto">
                    <div class="card w-100 monthly_card">
                        <h5 class="card-header text_upper">Features</h5>
                        <div class="card-body">
                            <ul class="text-left" style="color:#1F3200;">
                                <li>Make a list of 1 - 30 products</li>
                                <li class="mt-4">Home delivery</li>
                                <li class="mt-4">Affordable price for the products and delivery</li>
                            </ul>
                            <a href="create-shopping-list" class="btn-block font-weight-bolder py-2 clist">
                                Create List
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<?php include_once("inc/footer.nav.php"); ?>