<?php $filepath = realpath(dirname(__FILE__));
include_once($filepath."/../controllers/classes/GlobalApi.class.php"); define('CONTROLLER_ROOT_URL', 'http://localhost/e-commerce(green_group)/controllers'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <base href="http://localhost/e-commerce(green_group)/">
    <link rel="icon" href="./images/favIcon.png" type="image/x-icon" sizes="16x16">
    <title>GAC - eCommerce shopping website</title>
    <link rel="stylesheet" href="./css/font_awesome/css/all.min.css" />
    <link rel="stylesheet" href="./css/bootstrap.min.css" />
    <link rel="stylesheet" href="./css/owl.carousel.min.css" />
    <link rel="stylesheet" href="./css/owl.theme.default.min.css" />
    <link rel="stylesheet" href="./css/main.css" />
    <link rel="stylesheet" href="./css/toastr.min.css" />
    <link rel="stylesheet" href="./css/jquery-confirm.min.css" />
    <style>
        .subcategoryShow {background-color: #747474 !important;color: #ffffff !important; }
        .subcategoryShow a {color: inherit !important; }
        form .error {color: #e74c3c;border-color: #e74c3c !important;}
        form label.error{font-size: 0.8rem;}
        .yum { color:#ffffff;background:#98AC31; font-weight:bolder}
        .yum:hover{ background:#c3df34; color:#ffffff; }
        #user_shopping_list .monthly_card .card-header {background: #FF8585 !important;}
    </style>
</head>
<body>
<main>
    <nav class="main_nav_lg bg-white sticky-top d-none d-md-block py-2">
        <div class="cont_wrapper main_nav_inner">
            <div class="fl_itm_1">
                <a href="./" class="navbar-brand"><img src="./images/GAC_logo.png" alt="GAC"></a>
                <nav class="nav">
                    <li class="nav-item dropdown top_nav_dropdown">
                        <a class="nav-link custom_dropdown_toggle pseudo_after" href="#" id="navbarDropdown" role="button" aria-haspopup="true" aria-expanded="false">
                            Help
                        </a>
                        <div class="dropdown-menu border-0" aria-labelledby="navbarDropdown">
                            <ul class="category_list_lg_scrn">
                                <li><a href="faqs">FAQ</a></li>
                                <li><a href="contact-us">Contact Us</a></li>
                            </ul>
                        </div>
                    </li>
                    <a title="Shopping made easy, shop by describing the product" class="nav-link px-4 ml-md-4 yum" href="shopping">Shopping List</a>
                </nav>
            </div>
            <div class="fl_itm_2">
                <form class="search_form_lg-scrn" action="search" method="get" style="display: flex;">
                    <input value="<?= isset($_GET['searched'])?$_GET['searched']:null;?>" class="mr-2 rounded-left py-2 px-2"
                         type="text" placeholder="search product" name="searched" style="width: 85%">
                    <button class="px-3 rounded-right text_upper y_btn">Search</button>
                </form>
            </div>
            <div class="fl_itm_3">
                <ul class="nav justify-content-end">
                    <li class="nav-item dropdown top_nav_dropdown">
                        <?php if (isset($_SESSION['user_login']) && isset($_SESSION['user_login']['customer_id'])) { ?>
                            <?php $f_name = explode(" ", $_SESSION['user_login']['firstname']); ?>
                        <a class="nav-link custom_dropdown_toggle pseudo_after" href="javascript:void(0)" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <?=$f_name[0];?>
                        </a>
                        <div class="dropdown-menu px-3 border-0" aria-labelledby="navbarDropdown">
                            <ul class="category_list_lg_scrn">
                                <li class="text-center rounded p-0"><a href="account/">Account</a></li>
                                <li class="text-center rounded p-0"><a href="account/orders">Orders</a></li>
                                <li class="text-center rounded p-0"><a href="account/wishlist">Saved Item</a></li>
                                <li class="text-center rounded p-0"><a href="account/pending-review">Pending Reviews</a></li>
                                <div class="dropdown-divider"></div>
                                <li class="text-center rounded p-0">
                                    <a href="logout/<?= bin2hex($_SESSION['user_login']['email'].$_SESSION['user_login']['customer_id'].$f_name['0']); ?>">
                                        Logout
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <?php } else { ?>
                        <a class="nav-link custom_dropdown_toggle pseudo_after" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Login
                        </a>
                        <div class="dropdown-menu px-3 border-0" aria-labelledby="navbarDropdown">
                            <ul class="category_list_lg_scrn">
                                <li class="text-center rounded p-0"><a href="login">Login</a></li>
                                <div class="dropdown-divider"></div>
                                <li class="text-center rounded p-0"><a href="sign-up">Sign Up</a></li>
                            </ul>
                        </div>
                        <?php } ?>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link txt_green" href="cart" style="display: flex;align-items: center;">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                <path d="M20 7h-4v-3c0-2.209-1.791-4-4-4s-4 1.791-4 4v3h-4l-2 17h20l-2-17zm-11-3c0-1.654 1.346-3 3-3s3 1.346 3 3v3h-6v-3zm-4.751 18l1.529-13h2.222v1.5c0 .276.224.5.5.5s.5-.224.5-.5v-1.5h6v1.5c0 .276.224.5.5.5s.5-.224.5-.5v-1.5h2.222l1.529 13h-15.502z"/>
                            </svg>&nbsp;(<span class="font-weight-bolder total-count">0</span>)
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="main_nav_cateory_wrapper d-none d-md-block">
        <div class="cont_wrapper" style="display: flex; align-items: center; flex-wrap: wrap; justify-content: space-between;">
            <ul class="nav" style="width: 90%; justify-content: space-between;">
                <li class="nav-item dropdown category_dropdown_alt">
                    <a class="nav-link category_dropdown_toggle pseudo_after category_title pl-1" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        All Categories
                    </a>
                    <div class="dropdown-menu border-0 p-0" aria-labelledby="navbarDropdown" style="min-width:12rem !important">
                        <ul class="category_list_lg_scrn">
                            <?php
                            $url = CONTROLLER_ROOT_URL."/v1/read-product-categories.php";
                            $object = $api->curlQueryGet($url);$n=0;
                            foreach ($object->category as $cat) {$n=$n+1;
                            ?>
                            <li class="all_category_menu_item">
                                <a href="javascript:void(0)"><?=$cat->category_name;?></a>
                                <div class="<?=($n==2)?' container-fluid ':'';?> content" <?=($n==2)?'style=\'height:400px;\'':''; ?>>
                                    <ul class="<?=($n==2)?'row':'';?>">
                                        <?php
                                        $url = CONTROLLER_ROOT_URL."/v1/read-product-subcat-by-cat-id.php?cat_id=".$cat->cat_id;
                                        $inObj = $api->curlQueryGet($url);?>
                                        <?php if($n==50 || $n==50){ ?>
                                        <div class="text-center">
                                            <h4 class="font-weight-bold">Coming soon</h4>
                                            <p>Make a list of <?=($n==50)?'books':'beauty products';?> you want</p>
                                            <a href="shopping" class="link_hover font-weight-bold" style="color:#C3DF34;">CLICK HERE</a>
                                        </div>
                                        <?php } else {
                                        foreach ($inObj->subcategory as $sub) {
                                        ?>
                                            <li <?=($n==2)?'class="col-4"':'';?>><a href="category/<?=$sub->subcat_id;?>"><?=$sub->subcat_name;?></a></li>
                                        <?php } ?>
                                        <?php } ?>
                                    </ul>
                                </div>
                            </li>
                            <?php } ?>
                        </ul>
                    </div>
                </li>
                <?php
                $url = CONTROLLER_ROOT_URL."/v1/read-product-categories.php";
                $object = $api->curlQueryGet($url);$n=0;
                foreach ($object->category as $cat) {$n=$n+1;
                ?>
                <li class="nav-item category_dropdown">
                    <a class="nav-link category_title" href="javascript:void(0)"><?=$cat->category_name;?></a>
                    <div class="category_dropdown_list absolute_position"
                    <?php
                    if ($n==1) echo 'style="width: 35%; left: 13.47%"';
                    elseif ($n==2) echo 'style="width: 75%; left: 15%"';
                    elseif ($n==3) echo 'style="width: 35%; left: 36%"';
                    elseif ($n==4) echo 'style="width: 35%; left: 42%"';
                    elseif ($n==5) echo 'style="width: 35%; left: 50%"';
                    elseif ($n==6) echo 'style="width: 35%; left: 59%"';
                    elseif ($n==7) echo 'style="width: 35%; left: 65%"';
                    ?>
                    >
                        <ul class="mx-2 my-3 <?=($n==2)?'row':'';?>">
                            <?php
                            $url = CONTROLLER_ROOT_URL."/v1/read-product-subcat-by-cat-id.php?cat_id=".$cat->cat_id;
                            $inObj = $api->curlQueryGet($url);
                            ?>
                            <?php if($n==50 || $n==50){ ?>
                            <div class="text-center">
                                <h4 class="font-weight-bold">Coming soon</h4>
                                <p>Make a list of <?=($n==50)?'books':'beauty products';?> you want</p>
                                <a href="shopping" class="link_hover font-weight-bold" style="color:#C3DF34;">CLICK HERE</a>
                            </div>
                            <?php } else {
                                foreach ($inObj->subcategory as $sub) {
                            ?>
                    <li <?=($n==2)?'class="col-4"':'';?>><a href="category/<?=$sub->subcat_id;?>"><?=$sub->subcat_name;?></a></li>
                            <?php } ?>
                            <?php } ?>
                        </ul>
                    </div>
                </li>
                <?php } ?>
            </ul>
        </div>
    </div>

    <!-- small screen header -->
    <nav class="cust_nav navbar-expand-lg navbar-light p-0 sticky-top d-block d-md-none">
        <div class="bg-white">
            <div class="cont_wrapper flex_just_spb right_0 left_0 align_center">
                <span>
                    <!-- Brand-logo -->
                    <button class="navbar-toggler border-0" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <a class="navbar-brand" href="./"><img src="./images/GAC_logo.png" alt="GAC"></a>
                </span>
                <span>
                    <a class="nav-link txt_green" href="cart" style="display: flex;align-items: center;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                        <path d="M20 7h-4v-3c0-2.209-1.791-4-4-4s-4 1.791-4 4v3h-4l-2 17h20l-2-17zm-11-3c0-1.654 1.346-3 3-3s3 1.346 3 3v3h-6v-3zm-4.751 18l1.529-13h2.222v1.5c0 .276.224.5.5.5s.5-.224.5-.5v-1.5h6v1.5c0 .276.224.5.5.5s.5-.224.5-.5v-1.5h2.222l1.529 13h-15.502z"/>
                    </svg>&nbsp;(<span class="font-weight-bolder total-count">0</span>)
                    </a>
                </span>
            </div>
        </div>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mb-0">
                <li class="nav-item bg-white py-4 my-2 inline_flex">
                    <div class="text-center margin-auto-0">
                        <?php if (isset($_SESSION['user_login']) && isset($_SESSION['user_login']['customer_id'])) { ?>
                            <a class="access_btn py-2 px-5 white_btn mr-2" href="../account/account-profile.php">
                                <i class="fa fa-user mr-2"></i>My Account
                            </a>
                            <a class="access_btn py-2 px-5 white_btn" href="logout/<?= bin2hex($_SESSION['user_login']['email'].$_SESSION['user_login']['customer_id'].$f_name['0']); ?>">
                                Logout
                            </a>
                        <?php } else { ?>
                        <a class="access_btn py-2 px-5 white_btn mr-2" href="login">Login</a>
                        <a class="access_btn py-2 px-5 white_btn" href="sign-up">Sign Up</a>
                        <?php } ?>
                    </div>
                </li>
            </ul>
            <h6 class="container bg-white py-3 text_capital">All Categories</h6>
            <div class="bg-white">
                <div class="container">
                    <div class="accordion" id="accordionExample">
                        <?php
                        $url = CONTROLLER_ROOT_URL."/v1/read-product-categories.php";
                        $object = $api->curlQueryGet($url);$n=0;
                        foreach ($object->category as $cat) {$n=$n+1;
                        ?>
                        <div class="card border-0">
                            <button class="btn btn-link cust_nav_link_dropdown px-0" type="button" data-toggle="collapse" data-target="#test<?=$cat->cat_id;?>" aria-expanded="true" aria-controls="<?=$cat->cat_id;?>" id="<?=$cat->cat_id;?>">
                                <span><?=$cat->category_name;?></span>
                                <span><i class="fas fa-angle-right"></i></span>
                            </button>
                            <div id="test<?=$cat->cat_id;?>" class="subcategoryShow collapse" aria-labelledby="<?=$cat->cat_id;?>" data-parent="#accordionExample">
                                <div class="card-body py-0">
                                    <?= ($n==2)?'<div class="container-fluid">':null;?>
                                    <ul class="navbar-nav category_list_wrapper mr-auto <?=($n==2)?'row flex-row':'';?>">
                                        <?php
                                        $url = CONTROLLER_ROOT_URL."/v1/read-product-subcat-by-cat-id.php?cat_id=".$cat->cat_id;
                                        $inObj = $api->curlQueryGet($url);
                                        ?>
                                        <?php if($n==4 || $n==5){ ?>
                                        <div class="text-center">
                                            <h4 class="font-weight-bold">Coming soon</h4>
                                            <p>Make a list of <?=($n==4)?'books':'beauty products';?> you want</p>
                                            <a href="shopping" class="link_hover font-weight-bold" style="color:#C3DF34;">CLICK HERE</a>
                                        </div>
                                        <?php } else {
                                        foreach ($inObj->subcategory as $sub) {
                                        ?>
                                        <li class="nav-item active <?=($n==2)?'col-6':'';?>"><a class="nav-link text_capital" href="category/<?=$sub->subcat_id;?>"><?=$sub->subcat_name;?></a></li>
                                        <?php } ?>
                                        <?php } ?>
                                        <?= ($n==2)?'</div>':null;?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <?php } ?>
                    </div>
                    <div class="accordion mt-3" id="accordionExample2">
                        <div class="card border-0">
                            <button class="btn btn-link cust_nav_link_dropdown px-0" type="button" data-toggle="collapse" data-target="#faq" aria-expanded="true" aria-controls="faq" id="faqHeading">
                                <span>Help</span>
                                <span><i class="fas fa-angle-right"></i></span>
                            </button>
                            <div id="faq" class="collapse" aria-labelledby="faqHeading" data-parent="#accordionExample2">
                                <div class="card-body py-0">
                                    <ul class="navbar-nav category_list_wrapper mr-auto" style="list-style-type: none">
                                        <li class="nav-item" style="list-style-type: none"><a class="nav-link text_capital" href="faqs">FAQ</a></li>
                                        <li class="nav-item" style="list-style-type: none"><a class="nav-link text_capital" href="contact-us">Contact Us</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <a href="shopping" class="text-dark"><h6 class="container bg-white py-3 text_capital" style="border-top: 7px solid #e5e5e5">Shopping List</h6></a>
        </div>
    </nav>
    <div class="py-2 search_input_wrapper d-block d-md-none">
        <form class="cont_wrapper" action="search" method="get">
            <div class="input-group border search_input_grp">
                <input value="<?= isset($_GET['searched'])?$_GET['searched']:null;?>" type="text" class="form-control border-0" name="searched" placeholder="search by title">
                <div class="input-group-append">
                    <button class="btn btn-outline-secondary border-0 bg-white" style="color:#6c757d;">
                        <i class="fas fa-search"></i>
                    </button>
                </div>
            </div>
        </form>
    </div><!-- /header -->