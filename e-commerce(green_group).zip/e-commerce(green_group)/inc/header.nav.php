<?php $filepath = realpath(dirname(__FILE__));
include_once($filepath."/../controllers/classes/GlobalApi.class.php"); define('CONTROLLER_ROOT_URL', 'http://localhost/e-commerce(green_group)/controllers'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <base href="http://localhost/e-commerce(green_group)/">
    <link rel="icon" href="./images/favIcon.png" type="image/x-icon" sizes="16x16">
    <title>GAC - eCommerce shopping website</title>
    <link rel="stylesheet" href="./css/font_awesome/css/all.min.css" />
    <link rel="stylesheet" href="./css/bootstrap.min.css" />
    <link rel="stylesheet" href="./css/owl.carousel.min.css" />
    <link rel="stylesheet" href="./css/owl.theme.default.min.css" />
    <link rel="stylesheet" href="./css/main.css" />
    <link rel="stylesheet" href="./css/toastr.min.css" />
    <link rel="stylesheet" href="./css/jquery-confirm.min.css" />
    <link rel="stylesheet" href="./css/style.min.css" />

    <style> !important;}
        form label.error{font-size: 0.8rem;}
        .yum { color:#ffffff;background:#98AC31; font-weight:bolder}
        .yum:hover{ background:#c3df34; color:#ffffff; }
        #user_shopping_list .monthly_card .card-header {background: #FF8585 !important;}
    </style>
</head>
<body>
<header class="sticky-top">
    <nav class="toolbar">
        <div class="" id="toolbar-sm">
            <div class="mobile-tools">
                <nav class="navbar navbar-expand-lg navbar-light">
                    <button class="navbar-toggler border-0" id="sidenav-toggler" type="button" data-toggle="" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <div class="cust-bar"></div><div class="cust-bar"></div><div class="cust-bar"></div>
                    </button>
                    <a class="navbar-brand" href="#"><div class="brandlogo-img-wrapper"><img src="./images/GAC_logo.png" alt="" class="img-fluid" /></div></a>
                    <div class="ml-auto">
                        <a href="#" class="shopping-cart">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M20 7H16V4C16 1.791 14.209 0 12 0C9.791 0 8 1.791 8 4V7H4L2 24H22L20 7ZM9 4C9 2.346 10.346 1 12 1C13.654 1 15 2.346 15 4V7H9V4ZM4.249 22L5.778 9H8V10.5C8 10.776 8.224 11 8.5 11C8.776 11 9 10.776 9 10.5V9H15V10.5C15 10.776 15.224 11 15.5 11C15.776 11 16 10.776 16 10.5V9H18.222L19.751 22H4.249Z" fill="black" />
                            </svg>
                            <span class="shopping-cart-label">Cart(3)</span>
                        </a>
                    </div>
                </nav>
            </div>
        </div>
        <div class="inner container-fluid main-wrapper" id="toolbar-lg">
            <div class="brandlogo-img-wrapper"><img src="./images/GAC_logo.png" alt="" class="img-fluid" /></div>
            <div class="nav-item custom-dropdown drop-icon">
                <a class="nav-link" href="#">Help</a>
                <div class="dropdown-container">
                    <div class="dropdown-content border-0 shadow-sm bg-white">
                        <ul class="list-style-none px-0 mb-0">
                            <li><a href="./faqs" class="nav-link">FAQ</a></li>
                            <li><a href="./contact-us" class="nav-link">Contact Us</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div><a title="Shopping made easy, shop by describing the product" href="shopping" class="btn nav-call-to-action">Shopping List</a></div>
            <div>
                <form class="search-form" action="search" method="get">
                    <input value="<?= isset($_GET['searched'])?$_GET['searched']:null;?>" type="text" placeholder="search product" name="searched">
                    <button class="btn">Search</button>
                </form>
            </div>
            <div class="nav-item custom-dropdown drop-icon">
                <a class="nav-link" href="login">Login</a>
                <div class="dropdown-container">
                    <div class="dropdown-content border-0 shadow-sm bg-white">
                        <ul class="list-style-none px-0 mb-0">
                            <li><a href="login" class="nav-link">Login</a></li>
                            <li><a href="sign-up" class="nav-link">Sign Up</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <a href="cart" class="shopping-cart">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M20 7H16V4C16 1.791 14.209 0 12 0C9.791 0 8 1.791 8 4V7H4L2 24H22L20 7ZM9 4C9 2.346 10.346 1 12 1C13.654 1 15 2.346 15 4V7H9V4ZM4.249 22L5.778 9H8V10.5C8 10.776 8.224 11 8.5 11C8.776 11 9 10.776 9 10.5V9H15V10.5C15 10.776 15.224 11 15.5 11C15.776 11 16 10.776 16 10.5V9H18.222L19.751 22H4.249Z" fill="black" />
                </svg>
                <span class="shopping-cart-label nav-link px-0">Cart(<span class="font-weight-bolder total-count">0</span>)</span>
            </a>
        </div>
    </nav>
</header>
<div class="mobile-search-form">
    <form class="search-form" action="search" method="get">
        <input value="<?= isset($_GET['searched'])?$_GET['searched']:null;?>" type="text" placeholder="search product" name="searched" required>
        <button class="btn"><i class="fas fa-search"></i></button>
    </form>
</div>
<div id="sidebar">
    <div id="auth-nav">
        <div class="inner">
            <a href="login" class="btn">Login</a>
            <a href="sign-up" class="btn">Sign up</a>
        </div>
    </div>
    <div id="category">
        <div class="title">All category</div>
        <div class="category-list-wrapper">
            <div class="accordion" id="accordionExample">
                <?php
                $url = CONTROLLER_ROOT_URL."/v1/read-product-categories.php";
                $object = $api->curlQueryGet($url);$n=0;
                foreach ($object->category as $cat) {$n=$n+1;
                    ?>
                    <div class="card border-0">
                        <button class="btn btn-link cust_nav_link_dropdown px-0" type="button" data-toggle="collapse" data-target="#test<?=$cat->cat_id;?>" aria-expanded="true" aria-controls="<?=$cat->cat_id;?>" id="<?=$cat->cat_id;?>">
                            <span><?=$cat->category_name;?></span>
                        </button>
                        <div id="test<?=$cat->cat_id;?>" class="cat collapse" aria-labelledby="<?=$cat->cat_id;?>" data-parent="#accordionExample">
                            <div class="card-body py-0">
                                <ul class="navbar-nav category_list_wrapper mr-auto">
                                    <?php
                                    $url = CONTROLLER_ROOT_URL."/v1/read-product-subcat-by-cat-id.php?cat_id=".$cat->cat_id;
                                    $inObj = $api->curlQueryGet($url);
                                    if (isset($inObj->subcategory)){
                                        foreach ($inObj->subcategory as $sub) {
                                            ?>
                                            <li class="nav-item active"><a class="nav-link text_capital" href="category/<?=$sub->subcat_id;?>"><?=$sub->subcat_name;?></a></li>
                                        <?php } } ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
            <div class="accordion mt-3" id="accordionExample2">
                <div class="card border-0">
                    <button class="btn btn-link cust_nav_link_dropdown px-0" type="button" data-toggle="collapse" data-target="#faq" aria-expanded="false" aria-controls="faq" id="faqHeading">
                        <span>Help</span>
                    </button>
                    <div id="faq" class="collapse" aria-labelledby="faqHeading" data-parent="#accordionExample2">
                        <div class="card-body py-0">
                            <ul class="navbar-nav category_list_wrapper mr-auto">
                                <li class="nav-item active"><a class="nav-link text_capital" href="contact-us">Contact Us</a></li>
                                <li class="nav-item"><a class="nav-link text_capital" href="faqs">FAQ</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<main>