</main>
<footer class="py-3 mt-5">
    <div class="container">
        <div class="row">
            <div class="col-6 col-md-4">
                <h6 class="text_upper footer_col_title">Company</h6>
                <ul class="p-0">
                    <li><a href="policy">Privacy policy</a></li>
                    <li><a href="faqs">FAQs</a></li>
                    <li><a href="about-us">About us</a></li>
                    <li><a href="terms-and-conditions">Terms and conditions</a></li>
                    <li><a href="return-policy">Return and refund policy</a></li>
                </ul>
            </div>
            <div class="col-6 col-md-4">
                <h6 class="text_upper footer_col_title">Payment Method</h6><ul class="p-0">
                    <li><a href="javascript:void(0)">Transfer</a></li>
                    <li><a href="javascript:void(0)">Mastercard</a></li>
                    <li><a href="javascript:void(0)">Visa</a></li>
                    <li><a href="javascript:void(0)">Interswitch</a></li>
                    <li><a href="javascript:void(0)">Verve</a></li>
                </ul>
            </div>
            <div class="col-12 col-md-4">
                <h6>SUBSCRIBE TO OUR NEWS LETTER</h6>
                <form name="newsLetter" id="newsLetter" class="newsletter_form">
                    <input class="rounded-left py-2 border-0 px-2" type="text" name="subscriber_email" id="subscriber_email" required aria-label="">
                    <button type="submit" class="green_btn rounded-right py-2">Subscribe</button>
                </form><div class="errorNews"></div><br /><br />
                <h6 class="text_upper footer_col_title">CONNECT WITH US</h6>
                <ul class="p-0 social_icons_wrapper">
                    <li><a href="#"><i class="fab fa-facebook-square"></i></a></li>
                    <li><a href="#"><i class="fab fa-twitter-square"></i></a></li>
                    <li><a href="#"><i class="fab fa-instagram-square"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="copyright mt-3 text_capital">
        2021 &copy; GAC Corporation
    </div>
</footer>

<script src="./js/jquery-3.5.1.min.js"></script>
<script src="./js/popper.min.js"></script>
<script src="./js/bootstrap.min.js"></script>
<script src="./js/owl.carousel.min.js"></script>
<script src="./js/serialObject.js"></script>
<script src="./js/jquery.validate.min.js"></script>
<script src="./js/cart-reducer.js"></script>
<script src="./js/action-reducer.js"></script>
<script src="./js/toastr.min.js"></script>
<script src="./js/jquery-confirm.min.js"></script>
<script src="./js/lga.min.js"></script>
<script src="./js/main.js"></script>
</body>
</html>