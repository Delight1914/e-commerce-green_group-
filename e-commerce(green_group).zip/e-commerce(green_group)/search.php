<?php ob_start(); session_start();
include_once("inc/header.nav.php");
if (isset($_GET['searched']) && !empty($_GET['searched'])){
    include_once('controllers/config/database.php');include_once('controllers/classes/Product.class.php');
    $db = new Database();$connection = $db->connect();
    $searchedProd = $_GET['searched'];
    $_SESSION['temp_searched']=$searchedProd;
        ?>
        <style>.width_full{outline: 0 !important;box-shadow: none !important;}.width_full:focus{box-shadow: none !important;}</style>
        <div id="search_page">
            <div class="cont_wrapper" id="search_page_breadcrumb">
                <ul class="breadcrumb">
                    <li><a href="./">Home</a></li>
                    <li>Search Result</li>
                </ul>
            </div>
            <div class="cont_wrapper">
                <div class="container-fluid product_action_filter">
                    <div class="row d-none py-2 search_apply_ctrl_wrapper">
                        <div class="col">
                            <div class="text-right bg-white py-2"><button class="px-4" id="search_apply_ctrl">Apply</button></div>
                        </div>
                    </div>
                    <div class="row no-gutters">
                        <div class="col-12 col-md-3 filter_sidenav">
                            <h6 class="text-center text-md-left search_item_title">Search Results - <?=$_GET['searched'];?></h6>
                            <section class="mr-1 toggledNavItem d-none d-md-block">
                                <div class="filt_title_cont"><h6 class="m-0 text_upper">Category</h6></div>
                                <ul>
                                    <?php
                                    $query = $connection->query("SELECT * FROM tbl_category");
                                    if($query->num_rows > 0) {
                                        while ($row = $query->fetch_assoc()) {
                                            echo '<li class="list_sect"><ul class="pl-4">
                                                <a class="link link_hover" href="categories/'.$row['cat_id'].'">'.$row['category_name'].'</a>
                                                </ul></li>';
                                        }
                                    }
                                    ?>
                                </ul>
                            </section>
                            <section class="mr-1 toggledNavItem d-none d-md-block">
                                <div class="filt_title_cont"><h6 class="m-0 text_upper">Price</h6></div>
                                <ul>
                                    <li class="container list_sect">
                                        <div class="form-row">
                                            <div class="col">
                                                <label class="sr-only" for="priceStart">From</label>
                                                <div class="input-group mb-2">
                                                    <div class="input-group-prepend"><div class="input-group-text" style="padding:.375rem .5rem">₦</div></div>
                                                    <input type="number" class="form-control bg-white price_start width_full" id="priceStart" placeholder="From">
                                                </div>
                                            </div>
                                            <div class="col">
                                                <label class="sr-only" for="priceEnd">To</label>
                                                <div class="input-group mb-2">
                                                    <div class="input-group-prepend"><div class="input-group-text" style="padding:.375rem .5rem">₦</div></div>
                                                    <input type="number" class="form-control bg-white price_end width_full" id="priceEnd"  placeholder="To">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col">
                                                <button type="submit" class="btn-block text_upper mt-2 py-1 light_grn_btn product_check">Apply</button>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </section>
                            <section class="mr-1 toggledNavItem d-none d-md-block">
                                <div class="filt_title_cont"><h6 class="m-0 text_upper">Rating</h6></div>
                                <ul>
                                    <li class="list_sect"><br/>
                                        <?php
                                        $query = $connection->query("SELECT review_rate FROM tbl_review GROUP BY review_rate ORDER BY review_rate DESC");
                                        if($query->num_rows > 0) {
                                            while ($row = $query->fetch_assoc()) {
                                        ?>
                                        <input value="<?=$row['review_rate'];?>" type="checkbox" name="four_stars" id="<?=$row['review_rate'];?>"
                                               class="check_rej product_check rate">
                                        <label for="<?=$row['review_rate'];?>">
                                            <span class="custom_check"></span>
                                            <?php
                                                for ($i=1;$i<=5;$i++) {
                                                    if ($i <= $row['review_rate']) echo '<i class="fas fa-star"></i>';
                                                    else echo '<i class="far fa-star"></i>';
                                                }
                                            ?>
                                            <br/>
                                        </label><br/>
                                        <?php
                                            }
                                        }
                                        ?>
                                    </li>
                                </ul>
                            </section>
                            <section class="mr-1 toggledNavItem d-none d-md-block">
                                <div class="filt_title_cont"><h6 class="m-0 text_upper">Screen Sizes</h6></div>
                                <ul>
                                    <li class="">
                                        <ul>
                                        <?php
                                        $query = $connection->query("SELECT DISTINCT product_size FROM tbl_product WHERE product_size !='' ORDER BY product_size DESC");
                                        if($query->num_rows > 0) {
                                            while ($row = $query->fetch_assoc()) {
                                        ?>
                                            <li class="list_sect">
                                                <input type="checkbox" value="<?=$row['product_size'];?>" id="<?=$row['product_size'];?>" class="check_rej product_check size">
                                                <label for="<?=$row['product_size'];?>"><span class="custom_check"></span><span class="tv_size"><?=substr($row['product_size'],0,2);?></span></label>
                                            </li>
                                        <?php } } ?>
                                        </ul>
                                    </li>
                                </ul>
                            </section>
                            <section class="mr-1 toggledNavItem d-none d-md-block">
                                <div class="filt_title_cont"><h6 class="m-0 text_upper">Operating System</h6></div>
                                <ul>
                                    <?php
                                    $query = $connection->query("SELECT DISTINCT product_os FROM tbl_product WHERE product_os !='' ORDER BY product_os ASC");
                                    if($query->num_rows > 0) {
                                        while ($row = $query->fetch_assoc()) {
                                            ?>
                                            <li class="list_sect">
                                                <input type="checkbox" value="<?=$row['product_os'];?>" id="<?=$row['product_os'];?>" class="check_rej product_check os">
                                                <label for="<?=$row['product_os'];?>"><span class="custom_check"></span><span class="os_name"><?=$row['product_os'];?></span></label>
                                            </li>
                                        <?php } } ?>
                                </ul>
                            </section>
                            </div>
                        <div class="col-12 col-md-9">
                            <div class="row sorting_comp_wrapper d-none d-md-block">
                                <div class="col">
                                    <form class="items_sorting_form">
                                        <div class="form_inner_wrapper">
                                            <div>Sort By: &nbsp;</div>
                                            <div>
                                                <input type="radio" class="radio_rej product_check sortBy" value="" name="sorting" id="newArrival">
                                                <label for="newArrival">
                                                    <span class="custom_radio"></span>
                                                    <span class="label_text">New Arrival</span>
                                                </label>
                                            </div>
                                            <div>
                                                <input type="radio" class="radio_rej product_check sortBy" value="asc" name="sorting" id="lowToHigh">
                                                <label for="lowToHigh">
                                                    <span class="custom_radio"></span>
                                                    <span class="label_text">Price: Low to High</span>
                                                </label>
                                            </div>
                                            <div>
                                                <input type="radio" class="radio_rej product_check sortBy" value="desc" name="sorting" id="highToLow">
                                                <label for="highToLow">
                                                    <span class="custom_radio"></span>
                                                    <span class="label_text">Price: High to low</span>
                                                </label>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>

                            <div class="product_search_items product_click">
                                <div class="row no-gutters all-products" id="all-products">
                                    <div class="loading-overlay" style="display:none;"><img src="./images/common/ajax-loader-line.gif" alt="load"></div>
                                    <?php require('searched_products.php'); ?>
                                </div>
                            </div>

                            <div class="row d-block d-md-none filter_sort_wrapper">
                                <div class="col">
                                    <div class="py-2 bg-white">
                                        <div class="m-auto flex_just_spb filter_sort_inner">
                                            <div>
                                                <button class="px-3 py-2 serch_ctrl_btn text_upper" id="filter_btn">Filter</button>
                                            </div>
                                            <div>
                                                <button class="px-3 py-2 serch_ctrl_btn text_upper" id="sort_btn">Sort</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    <?php } else { ?>
    <div class="container" style="margin: 50px auto;display: flex;flex-direction: column;align-items: center;">
        <h1 class="text-center text-danger" style="font-size: 120px">404</h1>
        <p class="text-center" style="font-size: 24px">Page not found </p>
        <p class="text-center" style="font-size: 16px"><a href="./">Back to homepage</a></p>
    </div>
<?php } ?>
<?php  include_once("inc/footer.nav.php"); ?>
<script>
    $(document).ajaxStart(function() {$('.loading-overlay').show();});
    $(document).ajaxStop(function() {$('.loading-overlay').hide();});
</script>
<script src="js/searched.js"></script>

