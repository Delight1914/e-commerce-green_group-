<?php
ob_start(); session_start();
if (!isset($_SESSION['shoppingList'])) header('Location: shopping');
include_once("inc/header.nav.php");
?>
    <style>
        .form_section_wrapper {
            max-width: 460px !important;
        }
    </style>
<div id="payment">
    <div class="banner py-3 pr-4 mb-5">
        <ul>
        <li class="cont_wrapper mb-2">
            Kindly input your personal information (name, valid email and WhatsApp number) to
            enable us reach out to you regarding the price of the items requested.
        </li>
        <li class="cont_wrapper mb-2">
            On completion of your order, we will send you the cost of the items requested and you are to make
            payment to validate your order as soon as possible. Failure to pay means your order will not be processed.
        </li>
            <li class="cont_wrapper">
                On confirmation of your payment, your order be processed and items delivered within the next 24hrs
            </li>
        </ul>
    </div>
    <section>
        <form name="shoppingListPayment" id="shoppingListPayment">
            <fieldset class="form_section_wrapper mb-3">
                <div class="border-bottom p-4">
                    <legend class="text_upper text-center m-0">Personal Details</legend>
                </div>
                <div class="p-4">
                    <div class="row">
                        <div class="col-12 col-md-12 mb-4">
                            <div class="form_grp">
<!--                                <label class="text_capital d-block text_capital" for="shop_fullname">Full Name</label>-->
                                <input type="text" class="d-block w-100" placeholder="Enter your name" name="shop_fullname" aria-label=""/>
                            </div>
                        </div>
                        <div class="col-12 col-md-12 mb-4">
                            <div class="form_grp">
<!--                                <label class="text_capital d-block text_capital" for="shop_email">Email Address</label>-->
                                <input type="text" class="d-block w-100" placeholder="Enter your email address" name="shop_email" aria-label=""/>                          </div>
                        </div>
                        <div class="col-12 col-md-12 mb-4">
                            <div class="form_grp">
<!--                                <label class="text_capital d-block text_capital" for="shop_email">WhatsApp Number</label>-->
                                <input type="text" class="d-block w-100" placeholder="Enter your whatsApp number" name="shop_phone" aria-label=""/>                          </div>
                        </div>
                    </div>
                </div>
            </fieldset>

            <div class="form_grp mb-3 text-center">
                <div class="control_btn_wrapper">
                    <button class="py-2 px-5 my-2 light_grn_btn rounded" onclick="goBack()">Back</button>
                    <button type="submit" class="py-2 px-5 my-2 light_grn_btn rounded" id="shoppingListPaymentBtn">
                        <i class="fa fa-spinner fa-spin mr-3 d-none"></i>Complete
                    </button>
                </div>
            </div>
        </form>
    </section>
</div><?php include_once("inc/footer.nav.php"); ?>