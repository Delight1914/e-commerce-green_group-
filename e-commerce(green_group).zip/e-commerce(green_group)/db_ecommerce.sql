-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.7.33 - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             11.2.0.6213
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for db_ecommerce
CREATE DATABASE IF NOT EXISTS `db_ecommerce` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `db_ecommerce`;

-- Dumping structure for table db_ecommerce.tbl_admin
CREATE TABLE IF NOT EXISTS `tbl_admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(150) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` longtext NOT NULL,
  `role` set('super','admin') NOT NULL DEFAULT 'admin',
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Data exporting was unselected.

-- Dumping structure for table db_ecommerce.tbl_brand
CREATE TABLE IF NOT EXISTS `tbl_brand` (
  `brand_id` int(11) NOT NULL AUTO_INCREMENT,
  `brand_name` varchar(150) NOT NULL,
  `brand_logo` longtext NOT NULL,
  PRIMARY KEY (`brand_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5814 DEFAULT CHARSET=latin1;

-- Data exporting was unselected.

-- Dumping structure for table db_ecommerce.tbl_category
CREATE TABLE IF NOT EXISTS `tbl_category` (
  `cat_sno` int(11) NOT NULL AUTO_INCREMENT,
  `cat_id` int(11) NOT NULL,
  `category_name` varchar(200) NOT NULL,
  PRIMARY KEY (`cat_sno`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- Data exporting was unselected.

-- Dumping structure for table db_ecommerce.tbl_coupon
CREATE TABLE IF NOT EXISTS `tbl_coupon` (
  `coupon_id` int(11) NOT NULL AUTO_INCREMENT,
  `coupon_title` varchar(100) NOT NULL,
  `coupon_code` longtext NOT NULL,
  `coupon_discount` int(11) NOT NULL,
  `coupon_status` varchar(50) NOT NULL,
  PRIMARY KEY (`coupon_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Data exporting was unselected.

-- Dumping structure for table db_ecommerce.tbl_customer
CREATE TABLE IF NOT EXISTS `tbl_customer` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `lastname` longtext NOT NULL,
  `firstname` longtext NOT NULL,
  `email` longtext NOT NULL,
  `phone` varchar(50) NOT NULL,
  `password` longtext NOT NULL,
  `active` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Data exporting was unselected.

-- Dumping structure for table db_ecommerce.tbl_newsletter
CREATE TABLE IF NOT EXISTS `tbl_newsletter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_email` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=latin1;

-- Data exporting was unselected.

-- Dumping structure for table db_ecommerce.tbl_order
CREATE TABLE IF NOT EXISTS `tbl_order` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_ref` varchar(50) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `order_amount` float NOT NULL,
  `order_qty` int(11) NOT NULL,
  `order_vat` float DEFAULT NULL,
  `order_ship_fee` float NOT NULL,
  `receiver_fname` varchar(150) NOT NULL,
  `receiver_lname` varchar(150) NOT NULL,
  `receiver_email` varchar(200) NOT NULL,
  `receiver_phone` varchar(50) NOT NULL,
  `receiver_address` text NOT NULL,
  `receiver_state` varchar(50) NOT NULL,
  `shipping_type` varchar(100) NOT NULL,
  `payment_option` varchar(50) NOT NULL,
  `order_status` set('New Order','Processing/shipped','Delivered') NOT NULL DEFAULT 'New Order',
  `order_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Data exporting was unselected.

-- Dumping structure for table db_ecommerce.tbl_order_details
CREATE TABLE IF NOT EXISTS `tbl_order_details` (
  `order_details_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `product_id` longtext NOT NULL,
  `product_qty` int(11) NOT NULL,
  `review_status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_details_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- Data exporting was unselected.

-- Dumping structure for table db_ecommerce.tbl_payment
CREATE TABLE IF NOT EXISTS `tbl_payment` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `payment_amount` float NOT NULL,
  `payment_ref` longtext NOT NULL,
  `payment_status` set('Paid','Unverified') NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Data exporting was unselected.

-- Dumping structure for table db_ecommerce.tbl_product
CREATE TABLE IF NOT EXISTS `tbl_product` (
  `sno` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` varchar(10) NOT NULL,
  `product_title` longtext NOT NULL,
  `product_sku` longtext NOT NULL,
  `cat_id` int(11) NOT NULL,
  `subcat_id` int(11) NOT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `product_img` longtext NOT NULL,
  `product_price` float NOT NULL,
  `product_size` varchar(50) DEFAULT NULL,
  `product_os` varchar(150) DEFAULT NULL,
  `overview` longtext,
  `description` longtext,
  `warranty` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`sno`),
  UNIQUE KEY `product_id` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

-- Data exporting was unselected.

-- Dumping structure for table db_ecommerce.tbl_pwd_reset
CREATE TABLE IF NOT EXISTS `tbl_pwd_reset` (
  `password_id` int(11) NOT NULL AUTO_INCREMENT,
  `reset_email` text NOT NULL,
  `reset_selector` text NOT NULL,
  `reset_token` longtext NOT NULL,
  `reset_expires` text NOT NULL,
  PRIMARY KEY (`password_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.

-- Dumping structure for table db_ecommerce.tbl_review
CREATE TABLE IF NOT EXISTS `tbl_review` (
  `review_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `product_id` varchar(50) NOT NULL,
  `review_comment` longtext NOT NULL,
  `review_rate` int(11) NOT NULL,
  `rated_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`review_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Data exporting was unselected.

-- Dumping structure for table db_ecommerce.tbl_shopping_list
CREATE TABLE IF NOT EXISTS `tbl_shopping_list` (
  `sno` int(11) NOT NULL AUTO_INCREMENT,
  `shopping_list_id` varchar(11) NOT NULL,
  `make_deposit` set('Yes','No') DEFAULT NULL,
  `shop_fullname` varchar(200) NOT NULL,
  `shop_email` varchar(200) NOT NULL,
  `shop_phone` varchar(200) NOT NULL,
  `shop_type` set('Weekly','Monthly') DEFAULT NULL,
  `shop_payment_status` set('Unverified','Paid') NOT NULL DEFAULT 'Unverified',
  PRIMARY KEY (`sno`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Data exporting was unselected.

-- Dumping structure for table db_ecommerce.tbl_shopping_list_details
CREATE TABLE IF NOT EXISTS `tbl_shopping_list_details` (
  `shopping_list_details_id` int(11) NOT NULL AUTO_INCREMENT,
  `shopping_list_id` int(11) NOT NULL,
  `shop_product_name` longtext NOT NULL,
  `shop_producer` text NOT NULL,
  `shop_qty` int(11) NOT NULL,
  `shop_cos` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`shopping_list_details_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Data exporting was unselected.

-- Dumping structure for table db_ecommerce.tbl_shopping_list_payment
CREATE TABLE IF NOT EXISTS `tbl_shopping_list_payment` (
  `shop_list_payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `shopping_list_id` int(11) NOT NULL,
  `shop_amount` float NOT NULL,
  `shop_reference` varchar(50) NOT NULL,
  `shop_pay_method` varchar(50) NOT NULL,
  `shop_account_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`shop_list_payment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Data exporting was unselected.

-- Dumping structure for table db_ecommerce.tbl_subcategory
CREATE TABLE IF NOT EXISTS `tbl_subcategory` (
  `subcat_id` int(11) NOT NULL AUTO_INCREMENT,
  `subcat_name` varchar(200) NOT NULL,
  `cat_id` int(11) NOT NULL,
  PRIMARY KEY (`subcat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6986 DEFAULT CHARSET=latin1;

-- Data exporting was unselected.

-- Dumping structure for table db_ecommerce.tbl_transfer_payment
CREATE TABLE IF NOT EXISTS `tbl_transfer_payment` (
  `transfer_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `account_name` varchar(50) NOT NULL,
  `transferred_amount` float NOT NULL,
  `transferred_status` int(11) NOT NULL DEFAULT '0',
  `transferred_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`transfer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Data exporting was unselected.

-- Dumping structure for table db_ecommerce.tbl_wishlist
CREATE TABLE IF NOT EXISTS `tbl_wishlist` (
  `wlist_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `product_id` varchar(50) NOT NULL,
  PRIMARY KEY (`wlist_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

-- Data exporting was unselected.

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
