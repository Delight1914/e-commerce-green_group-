<?php session_start();
if (isset($_GET['cmr_id']) && $_GET['cmr_id'] != NULL) {
    unset($_SESSION['user_login']);
    unset($_SESSION['user_login_temp']);
    header("Location: ../login");
}
?>
