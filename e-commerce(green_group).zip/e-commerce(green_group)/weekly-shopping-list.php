<?php ob_start(); session_start(); include_once("inc/header.nav.php"); $_SESSION['shoppingListType'] = 'Weekly';?>
<style>
    @media (max-width: 425px) {
        .list_wrapper{width: 80% !important;padding: 1.5em !important;}
    }
</style>
<div id="user_weekly_shopping_list">
        <div class="container my-3 flex_just_spb">
            <div class="flex_align_center">
                <a class="bo_back_history border-0 text-secondary" href="shopping"><i class="fas fa-long-arrow-alt-left fa-2x">&nbsp;</i></a>
                <h4 class="m-0 text_capital">Weekly</h4>
            </div>
            <div><span class="count-shop-list">1</span>/15</div>
        </div>
        <section>
            <div class="list_wrapper">
                <div class="py-3">
                    <div class="flex_align_center flex_just_spb">
                        <span><h5 class="m-0">List</h5></span>
                        <button class="text_capital w_btn border_lemon rounded py-2 px-4 add-shop-list">Add more</button>
                    </div>
                </div>
                <div class="accordion list_accordion" id="accordionExample">
                    <form name="shoppingList" id="shoppingListForm">
                        <div class="listing-more">
                            <!-- item 1 -->
                            <div class="card mb-2 rounded-0">
                                <div class="card-header" id="headingOne">
                                    <div class="mb-0 flex flex_just_spb">
                                        <button class="" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                            <i class="fas fa-chevron-down txt_lemon"></i>&nbsp;<span>#</span><span>1</span>&nbsp;<span>List</span>
                                        </button>

                                    </div>
                                </div>
                                <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="form_grp mb-3">
                                                    <label class="text_capital d-block" for="product_name">Product name</label>
                                                    <input type="text" class="d-block w-100 product_name_input" name="product_name[1]" id="product_name_1">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-12 col-md-9">
                                                <div class="form_grp mb-3">
                                                    <label class="text_capital d-block" for="producer">Brand/Manufacturer</label>
                                                    <input type="text" class="d-block w-100 producer_input" name="producer[1]" id="producer_1">
                                                </div>
                                            </div>
                                            <div class="col-12 col-md-3">
                                                <div class="form_grp mb-3">
                                                    <label class="text_capital d-block" for="qty">Quantity</label>
                                                    <input type="text" class="d-block w-100 qty_input" name="qty[1]" id="qty_1">
                                                </div>
                                            </div>
                                        </div>
                                        <!--  -->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form_grp mb-3 text-center">
                            <button type="submit" class="py-2 px-5 my-2 light_grn_btn rounded" id="shopBtn">
                                <i class="fa fa-spinner fa-spin mr-3 d-none"></i>Next
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </div>
<?php include_once("inc/footer.nav.php"); ?>
<script>
    $(document).ready(function () {

        $(".list_wrapper").on('click', '.add-shop-list', function () {
            var count = $('.count-shop-list').text();
            ++count;
            if (count > 15) {
                $.confirm({
                    icon: 'fa fa-exclamation-triangle',closeIcon: true, title: "Error!",typeAnimated: true, content: "Weekly maximum number of product list exceeded, consider monthly list",
                    type: 'red',buttons: {tryAgain: {text: 'Go to monthly', btnClass: 'btn-red', action: function(){window.location.replace('monthly-shopping-list')} }}
                });
            } else {
                $('.count-shop-list').html(count);
                $('.listing-more').append("<div class='card mb-2 rounded-0' id='dynamic_field"+count+"'>\n" +
                    "    <div class='card-header' id='headingOne'>\n" +
                    "        <div class='mb-0 flex flex_just_spb'>\n" +
                    "            <button class='' type='button' data-toggle='collapse' data-target='#collapse"+count+"' aria-expanded='true' aria-controls='collapse"+count+"'>\n" +
                    "                <i class='fas fa-chevron-down txt_lemon'></i>&nbsp;<span>#</span><span>"+count+"</span>&nbsp;<span>List</span>\n" +
                    "            </button>\n" +
                    "            <button class='btn_remove' id='"+count+"'><i class='fas fa-times-circle text-danger'></i></button>\n" +
                    "        </div>\n" +
                    "    </div>\n" +
                    "    <div id='collapse"+count+"' class='collapse' aria-labelledby='heading"+count+"' data-parent='#accordionExample'>\n" +
                    "        <div class='card-body'>\n" +
                    "            <div class='row'>\n" +
                    "                <div class='col-12'>\n" +
                    "                    <div class='form_grp mb-3'>\n" +
                    "                        <label class='text_capital d-block' for='product_name'>Product Name</label>\n" +
                    "                        <input type='text' class='d-block w-100 product_name_input' name='product_name["+count+"]' id='product_name_"+count+"'>\n" +
                    "                    </div>\n" +
                    "                </div>\n" +
                    "            </div>\n" +
                    "            <div class='row'>\n" +
                    "                <div class='col-12 col-md-9'>\n" +
                    "                    <div class='form_grp mb-3'>\n" +
                    "                        <label class='text_capital d-block' for='producer'>Brand/Manufacturer</label>\n" +
                    "                        <input type='text' class='d-block w-100 producer_input' name='producer["+count+"]' id='producer_"+count+"'>\n" +
                    "                    </div>\n" +
                    "                </div>\n" +
                    "                <div class='col-12 col-md-3'>\n" +
                    "                    <div class='form_grp mb-3'>\n" +
                    "                        <label class='text_capital d-block' for='qty'>Quantity</label>\n" +
                    "                        <input type='text' class='d-block w-100 qty_input' name='qty["+count+"]' id='qty_"+count+"'>\n" +
                    "                    </div>\n" +
                    "                </div>\n" +
                    "            </div>\n" +
                    "        </div>\n" +
                    "    </div>\n" +
                    "</div>");
            }
        });

        $(".list_wrapper").on('click', '.btn_remove', function () {
            var button_id = $(this).attr("id");
            var count = $('.count-shop-list').text();
            count=count-1;
            $('.count-shop-list').html(count);
            $('#dynamic_field'+button_id+'').remove();
        });

        $('form#shoppingListForm').on('submit', function () {
            $('.product_name_input').each(function () {
               $(this).rules("add",{required:true, messages:{required: "Product name is required",}});
            });

            $('.producer_input').each(function () {
                $(this).rules("add",{required:true, messages:{required: "Producer is required",}});
            });

            $('.qty_input').each(function () {
                $(this).rules("add",{required:true,digits:true, messages:{required: "Quantity is required",digits:"Invalid input"}});
            });
        });

        $("#shoppingListForm").validate({
            ignore:"",
            submitHandler: function(form, e) {
                e.preventDefault();
                var shopListForm = $('#shoppingListForm');

                $("#shopBtn").attr("disabled", true);
                $('#shopBtn').css("cursor", 'not-allowed');
                $(".fa-spin").addClass("d-inline-block");
                $.ajax({
                    url: "controllers/v1/hold-shop-list.php", type: "POST", data: shopListForm.serialize(),
                    success: function (data) {
                        toastr.options = {"closeButton": true, "positionClass": "toast-bottom-right"};
                        toastr["success"](data.message);
                        window.location.replace('shopping-list-payment');
                    },
                    error: function (errData) {
                        toastr.options = {"closeButton": true, "positionClass": "toast-bottom-right"};
                        toastr["error"](errData.responseJSON.message);
                    },
                    complete: function () {
                        $('#shopBtn').attr("disabled", false);
                        $('#shopBtn').css("cursor", 'pointer');
                        $(".fa-spin").removeClass("d-inline-block");
                    }
                });
            }
        });
    });
</script>
