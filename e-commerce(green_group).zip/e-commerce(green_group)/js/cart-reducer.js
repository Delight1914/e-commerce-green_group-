// ************************************************
// Shopping Cart API
// ************************************************
var shoppingCart = (function() {
    // =============================
    // Private methods and properties
    // =============================
    cart = [];
    // Constructor
    function Item(id,title, price,image, qty) {
        this.id = id;
        this.title = title;
        this.price = price;
        this.image = image;
        this.qty = qty;
    }

    // Save cart
    function saveCart() {
        localStorage.setItem('shoppingCart', JSON.stringify(cart));
    }

    // Load cart
    function loadCart() {
        cart = JSON.parse(localStorage.getItem('shoppingCart'));
    }
    if (localStorage.getItem("shoppingCart") != null) {
        loadCart();
    }

    // =============================
    // Public methods and propeties
    // =============================
    var obj = {};

    // Add to cart
    obj.addItemToCart = function(id,title,price,image, qty) {
        for(var item in cart) {
            if(cart[item].id === id) {
                cart[item].qty ++;
                saveCart();
                return;
            }
        }
        var item = new Item(id,title,price,image, qty);
        cart.push(item);
        saveCart();
    };
    // Set count from item
    obj.setCountForItem = function(id, qty) {
        for(var i in cart) {
            if (cart[i].id === id) {
                cart[i].qty = qty;
                break;
            }
        }
    };
    // Remove item from cart
    obj.removeItemFromCart = function(id) {
        for(var item in cart) {
            if(cart[item].id === id) {
                if(cart[item].qty <= 1)  return 1;
                else cart[item].qty --;
                break;
            }
        }
        saveCart();
    };

    // Remove all items from cart
    obj.removeItemFromCartAll = function(id) {
        for(var item in cart) {
            if(cart[item].id === id) {
                cart.splice(item, 1);
                break;
            }
        }
        saveCart();
    };

    // Clear cart
    obj.clearCart = function() {
        cart = [];
        saveCart();
    };

    // Count cart
    obj.totalCount = function() {
        var totalCount = 0;
        for(var item in cart) {
            totalCount += cart[item].qty;
        }
        return totalCount;
    };

    // Total cart
    obj.totalCart = function() {
        var totalCart = 0;
        for(var item in cart) {
            totalCart += cart[item].price * cart[item].qty;
        }
        return Number(totalCart.toFixed(2));
    };

    // List cart
    obj.listCart = function() {
        var cartCopy = [];
        for(i in cart) {
            item = cart[i];
            itemCopy = {};
            for(p in item) {
                itemCopy[p] = item[p];

            }
            itemCopy.total = Number(item.price * item.qty).toFixed(2);
            cartCopy.push(itemCopy)
        }
        return cartCopy;
    };

    // cart : Array
    // Item : Object/Class
    // addItemToCart : Function
    // removeItemFromCart : Function
    // removeItemFromCartAll : Function
    // clearCart : Function
    // countCart : Function
    // totalCart : Function
    // listCart : Function
    // saveCart : Function
    // loadCart : Function
    return obj;
})();


// *****************************************
// Triggers / Events
// *****************************************
// Add item

// $('.add-to-cart').click(function(event) {
    $(".list, .product_click").on("click",".add-to-cart",function (event) {
    event.preventDefault();
    var id = $(this).data('id');
    var title = $(this).data('title');
    var price = Number($(this).data('price'));
    var image = $(this).data('image');
    var qty = Number($(this).data('count'));

    shoppingCart.addItemToCart(id,title,price,image, qty);
    displayCart();
        toastr.options = {"closeButton": true, "positionClass": "toast-top-right"};
        toastr["success"]('Item '+title+' successfully added to cart');
});

$('.move-item-to-cart').click(function(event) {
    event.preventDefault();
    var wid = $(this).data('wlist_id');
    var id = $(this).data('id');
    var title = $(this).data('title');
    var price = $(this).data('price');
    var image = $(this).data('image');
    var qty = Number($(this).data('count'));

    shoppingCart.addItemToCart(id,title,price,image, qty);
    removeItemFromWishList(wid,title);
    displayCart();
});

// Clear items
$('.clear-cart').click(function() {
    shoppingCart.clearCart();
    displayCart();
});


function displayCart() {
    var cartArray = shoppingCart.listCart();
    var output = "";
    if (cartArray.length < 1 ){
        output +=" <section class='col-12 col-md-5 mt-5' style='margin: 0 auto;'>"
            +"<div class='container'><div class='text-center'><div class='m-auto'>"
            +"<div><img src='images/cart.svg'  style='border-radius: 50%; background: #fcf8e3;padding: 20px;width: 150px'></div>"
            +"</div>"
            +"<h5 class='mt-5 mb-4'>Your cart is empty!</h5>"
            +"<a href='./' class='d-block font-weight-bolder light_grn_btn px-5 py-3 text-center text-white process_btn process_checkout_btn'>" +
            "START SHOPPING</a></div></div>"
            +"</section>";
        $(".show_empty").html(output);
        // $(".will_hide").html("");
    } else {
        for (var i in cartArray) {
            output += "<div class='row bg-white p-2 mb-1'><div class='col-12 col-md-5'><div class='flex_align_center'>";
            output += "<img src='./admin/adminImg/products/"+cartArray[i].image+"' class='card-img mr-2' alt='Img' style='max-width: 100px;'>";
            output += "<div><h6 class='font-weight-bold'>"+cartArray[i].title+"</h6></div></div></div>";
            output += "<div class='col-4 col-md-2 item_qty_wrapper'><div>";
            output += "<small class='d-block d-md-none'>Quantity</small><div class='inline_flex border'>";
            output += "<button class='bg-white border-right myCtrl minus-item' data-id=" + cartArray[i].id + " style='color:#740774;'>-</button>";
            output += "<div class='text-center myCtrl item-count' data-id="+cartArray[i].id+">" + cartArray[i].qty +"</div><button class='bg-white border-left myCtrl plus-item' data-id=" + cartArray[i].id + " style='color:#740774;'>+</button>";
            output += "</div></div></div><div class='col-8 col-md-2'><div class='font-weight-bold'>₦ "+cartArray[i].price+"</div>";
            output += "<div class='initial_cal' style='color: #868686'><span>₦"+cartArray[i].price+"</span>&nbsp;x&nbsp;";
            output += "<span>"+cartArray[i].qty+"</span>&nbsp;Item</div></div><div class='col-12 col-md-2'><div class='cart_btn_wrapper'>";
            output += "<button class='cart_item_btn delete-item' data-id="+cartArray[i].id+"><small><i class='fas fa-trash mr-2'></i>Remove</small></button>";
            output += "<button class='cart_item_btn mt-md-3 move_to_wlist' data-id=" + cartArray[i].id + "><small><i class='fas fa-heart mr-2'></i>Save Item</small></button>";
            output += "</div></div></div>";
        }

        $('.show-cart').html(output);
    }


    $('.sub-total-cart').html(Number(shoppingCart.totalCart()).toFixed(2));
    $('.total-cart').html((Number(shoppingCart.totalCart())+1000).toFixed(2));
    $('.total-count').html(shoppingCart.totalCount());
    $('.total-shipping').html((1000).toFixed(2));

    //for checkout input
    $("#total_amount").val(Number(shoppingCart.totalCart())+1000);
    $("#total_qty").val(shoppingCart.totalCount());
    $("#amount_transferred").val(Number(shoppingCart.totalCart())+1000);
    $("#order_shipping").val((1000));
}

// Delete item button
$('.show-cart').on("click", ".delete-item", function(event) {
    var id = $(this).data('id');
    shoppingCart.removeItemFromCartAll(id);
    displayCart();
    toastr.options = {"closeButton": true, "positionClass": "toast-top-right"};
    toastr["success"]('Item removed successfully');
});

$('.show-cart').on("click", ".move_to_wlist", function(event) {
    var product_id = $(this).data('id');
    $.ajax({
        url: "controllers/v1/create-user-wishlist.php",
        type : "POST",
        contentType : 'application/json',
        data : JSON.stringify({product_id:product_id}),
        success: function(data) {
            shoppingCart.removeItemFromCartAll(product_id);
            displayCart();
            toastr.options = {"closeButton": true};
            toastr["success"]('Item saved to your WishList');
        },
        error: function(errData){
            $.confirm({
                icon: 'fa fa-exclamation-triangle',closeIcon: true, title: "Error!",typeAnimated: true, content: errData.responseJSON.message,
                type: 'red',buttons: {tryAgain: {text: 'Login', btnClass: 'btn-red', action: function(){window.location.replace('login')} }}
            });
        }
    });
});

$(document).on('click', '.wishlist_remove', function() {
    var wList_id = $(this).data('id');
    removeItemFromWishList(wList_id,'r');
});

function removeItemFromWishList(id,title){
    if (id==="") {
        toastr.error('Invalid product');
    } else {
        $.ajax({
            url: "controllers/v1/delete-wishlist.php",
            type : "POST",
            contentType : 'application/json',
            data : JSON.stringify({wList_id:id}),
            success: function(data) {
                toastr.options = {"closeButton": true, "positionClass": "toast-top-right"};
                if (title !=='r') toastr["success"]("Item "+title+" added to cart successfully");
                else toastr["success"](data.message);
                setTimeout(function () {window.location.reload();}, 1000);
            },
            error: function(errData){
                toastr.options = {"closeButton": true, "positionClass": "toast-bottom-right"};
                toastr["error"](errData.responseJSON.message);
            }
        });
    }
}

// -1
$('.show-cart').on("click", ".minus-item", function(event) {
    var id = $(this).data('id');
    shoppingCart.removeItemFromCart(id);
    displayCart();
});
// +1
$('.show-cart').on("click", ".plus-item", function(event) {
    var id = $(this).data('id');
    shoppingCart.addItemToCart(id);
    displayCart();
});

// Item count input
$('.show-cart').on("change", ".item-count", function(event) {
    var id = $(this).data('id');
    var count = Number($(this).val());
    shoppingCart.setCountForItem(id, count);
    displayCart();
});

displayCart();

$(".shippingFee").on("click",".shipping_option",function (event) {

    if($('input[name=shipping_option]:checked', '#checkout').val() === 'shipStandardMain') {var amount=1000; }
    if($('input[name=shipping_option]:checked', '#checkout').val() === 'shipNextIs') {var amount=1500; }
    // if($('input[name=shipping_fee]:checked', '#checkout_form').val() === 'shipNextMain') {var amount=2500; }
    // if($('input[name=shipping_fee]:checked', '#checkout_form').val() === 'shipSaturdayIs') {var amount=2500; }
    // if($('input[name=shipping_fee]:checked', '#checkout_form').val() === 'shipSameDayIs') {var amount=2500; }
    // if($('input[name=shipping_fee]:checked', '#checkout_form').val() === 'shipSameDayMain') {var amount=3000; }
    // if($('input[name=shipping_fee]:checked', '#checkout_form').val() === 'shipSaturdayMain') {var amount=3000; }

    $('.total-cart').html((Number(shoppingCart.totalCart())+amount).toFixed(2));
    $('.total-shipping').html((amount).toFixed(2));

    $("#total_amount").val((Number(shoppingCart.totalCart())+amount));
    $("#amount_transferred").val((Number(shoppingCart.totalCart())+amount));
    $("#order_shipping").val((amount));


});

