$(document).ready(function() {
    /* toggle sidenav */
    $("#sidenav-toggler").click(function() {
        $("#sidenav").toggleClass("open");
        $("#overlay").toggleClass("open");
        $(this).toggleClass("tran");
        $('#sidebar').toggleClass("show");
    })

    /* hero slider */
    $('.slider').bxSlider({
        auto: true,
        // mode: 'fade'
    });


    /* latest product */
    var latestProductSlider = $('.latestProductSlider');
    latestProductSlider.owlCarousel({
        margin: 10,
        loop: true,
        autoplay: true,
        autoplayTimeout: 4000,
        autoplaySpeed: 3000,
        dots: false,
        lazyLoad: true,
        responsive: {
            0: {
                items: 2
            },
            600: {
                items: 3
            },
            1000: {
                items: 5
            }
        }
    });
    // Go to the next item
    $('#latest-product .next').click(function() {
            latestProductSlider.trigger('next.owl.carousel', [700]);
        })
        // Go to the previous item
    $('#latest-product .prev').click(function() {
            // With optional speed parameter
            // Parameters has to be in square bracket '[]'
            latestProductSlider.trigger('prev.owl.carousel', [700]);
        })
        /* latest product */
    var bestSellingProductSlider = $('.bestSellingProductSlider');
    bestSellingProductSlider.owlCarousel({
        margin: 10,
        loop: true,
        autoplay: true,
        autoplayTimeout: 6000,
        autoplaySpeed: 3000,
        rtl: true,
        dots: false,
        lazyLoad: true,
        responsive: {
            0: {
                items: 2
            },
            600: {
                items: 3
            },
            1000: {
                items: 5
            }
        }
    });
    // Go to the next item
    $('#best-selling-product .next').click(function() {
            bestSellingProductSlider.trigger('next.owl.carousel', [700]);
        })
        // Go to the previous item
    $('#best-selling-product .prev').click(function() {
        // With optional speed parameter
        // Parameters has to be in square bracket '[]'
        bestSellingProductSlider.trigger('prev.owl.carousel', [700]);
    })
})