$(function() {
    $("form[name='registration']").validate({
        rules: {
            firstname: "required",
            lastname: "required",
            email: {required: true, email: true},
            phone:{required:true,digits:true},
            password: {required: true, minlength: 6},
            confirm_password: { equalTo: '[name="password"]'}
        },
        messages: {
            firstname: "Enter your firstname",
            lastname: "Enter your lastname",
            email: "Enter a valid email address",
            phone:"enter valid mobile number",
            password: {required: "Provide a password", minlength: "Your password must be at least 6 characters long"},
            confirm_password: { equalTo: "Enter Confirm password same as password"}
        },
        submitHandler: function (form, e) {
            e.preventDefault();
            var registration_form = $('#registration');
            var form_data = JSON.stringify(registration_form.serializeObject());

            $("#registration_btn").attr("disabled", true);
            $('#registration_btn').css("cursor", 'not-allowed');
            $(".fa-spin").addClass("d-inline-block");
            $.ajax({
                url: "controllers/v1/create-customer.php",
                type: "POST",
                contentType: 'application/json',
                data: form_data,
                success: function (data) {
                    document.getElementById("registration").reset();
                    $.confirm({
                        icon: 'fa fa-check-circle',closeIcon: false, title: "Registration successful",typeAnimated: true, content: data.message,
                        type: 'green',buttons: {tryAgain: {text: 'Proceed to login', btnClass: 'btn-green', action: function(){window.location.replace(data.location);} }}
                    });
                },
                error: function (errData) {
                    $.confirm({
                        icon: 'fa fa-exclamation-triangle', title: 'Registration failed',typeAnimated: true, buttons: false,
                        content:errData.responseJSON.message, type: 'red'
                    });
                },
                complete: function () {
                    $('#registration_btn').attr("disabled", false);
                    $('#registration_btn').css("cursor", 'pointer');
                    $(".fa-spin").removeClass("d-inline-block");
                }
            });
        }
    });

    $("form[name='login']").validate({
        rules: {
            email: {required: true, email: true},
            password: "required"
        },
        messages: {
            email: "Please enter a valid email address",
            password: "Please provide your password"
        },
        submitHandler: function (form, e) {
            e.preventDefault();
            var login_form = $('#login');
            var form_data = JSON.stringify(login_form.serializeObject());

            $("#login_btn").attr("disabled", true);
            $('#login_btn').css("cursor", 'not-allowed');
            $(".fa-spin").addClass("d-inline-block");
            $.ajax({
                url: "controllers/v1/login-customer.php",
                type: "POST",
                contentType: 'application/json',
                data: form_data,
                success: function (data) {
                    document.getElementById("login").reset();
                    window.location.replace(data.location);
                },
                error: function (errData) {
                    $.confirm({
                        icon: 'fa fa-exclamation-triangle', title: 'Registration failed',typeAnimated: true, buttons: false,
                        content:errData.responseJSON.message, type: 'red'
                    });
                },
                complete: function () {
                    $('#login_btn').attr("disabled", false);
                    $('#login_btn').css("cursor", 'pointer');
                    $(".fa-spin").removeClass("d-inline-block");
                }
            });
        }
    });

    $("form[name='update_profile']").validate({
        rules: {
            firstname: "required",
            lastname: "required",
            phone: "required",
            email: {required: true, email: true},
        },
        messages: {
            firstname: "Enter your firstname",
            lastname: "Enter your lastname",
            phone: "Enter your mobile phone number",
            email: "Please enter a valid email address",
        },
        submitHandler: function(form, e) {
            e.preventDefault();
            var update_profile_form = $('#update_profile');
            var form_data = JSON.stringify(update_profile_form.serializeObject());

            $("#update_btn").attr("disabled", true);
            $('#update_btn').css("cursor", 'not-allowed');
            $(".fa-spin").addClass("d-inline-block");
            $.ajax({
                url: "controllers/v1/send-update-profile.php", type : "POST", contentType : 'application/json',
                data : form_data,
                success: function(data) {
                    $.confirm({icon: 'fa fa-check-circle',title:'Updated successfully',typeAnimated: true,content:data.message,type:'green',
                        buttons: false,
                    });
                },
                error: function(errData){
                    if (errData.responseJSON.status===400){
                        $.confirm({
                            icon: 'fa fa-exclamation-triangle',title:'Hey!',typeAnimated:true,content:errData.responseJSON.message,type:'dark',
                            buttons:false,
                        });
                    } else {
                        $.confirm({
                            icon: 'fa fa-exclamation-triangle',title:'Error!',typeAnimated:true,content:errData.responseJSON.message,type:'red',
                            buttons:false,
                        });
                    }
                },
                complete: function () {
                    $('#update_btn').attr("disabled", false);
                    $('#update_btn').css("cursor", 'pointer');
                    $(".fa-spin").removeClass("d-inline-block");
                }
            });
        }
    });

    $("form[name='reset_pwd_form']").validate({
        submitHandler: function(form, e) {
            e.preventDefault();
            var reset_pwd_form = $('#reset_pwd_form');
            var form_data = JSON.stringify(reset_pwd_form.serializeObject());
            $("#reset_btn").attr("disabled", true);
            $('#reset_btn').css("cursor", 'not-allowed');
            $(".fa-spin").addClass("d-inline-block");
            $(".errorResponse").html('');
            $.ajax({
                url: "controllers/v1/send-forgot-password.php",
                type : "POST",
                contentType : 'application/json',
                data : form_data,
                success: function(data) {
                    $(".successResp").html("<p class='my-4 txt_lemon'>Please check your email</p>");
                    $.confirm({
                        icon: 'fa fa-check-circle', title: 'Success',typeAnimated: true, buttons: false, content:data.message, type: 'green'
                    });
                    document.getElementById("reset_pwd_form").reset();
                },
                error: function(errData){
                    $(".errorResponse").html("<div class='my-4 py-3 text-center bg-danger text-white'><p class='m-0'>Invalid email address</p></div>");
                    $.confirm({
                        icon: 'fa fa-exclamation-triangle', title: 'Error!',typeAnimated: true, buttons: false,
                        content:errData.responseJSON.message, type: 'red'
                    });
                },
                complete: function () {
                    $('#reset_btn').attr("disabled", false);
                    $('#reset_btn').css("cursor", 'pointer');
                    $(".fa-spin").removeClass("d-inline-block");
                }
            });
        }
    });

    $("form[name='update_reset_form']").validate({
        rules: {
            pwd: {required: true, minlength: 6},
            confirm_password: { equalTo: '[name="password"]'}
        },
        messages: {
            pwd: {required: "Please provide a password", minlength: "Your password must be at least 6 characters long"},
            confirm_password: { equalTo: "Enter Confirm password same as password"}
        },
        submitHandler: function(form, e) {
            e.preventDefault();
            var update_reset_form = $('#update_reset_form');
            var form_data = JSON.stringify(update_reset_form.serializeObject());

            $("#update_reset_btn").attr("disabled", true);
            $('#update_reset_btn').css("cursor", 'not-allowed');
            $(".fa-spin").addClass("d-inline-block");
            $.ajax({
                url: "controllers/v1/reset-update-password.php",
                type : "POST",
                contentType : 'application/json',
                data : form_data,
                success: function(data) {
                    document.getElementById("update_reset_form").reset();
                    $.confirm({
                        icon: 'fa fa-check-circle', title: 'PASSWORD SAVED',typeAnimated: true, content:data.message, type: 'green',
                        buttons: {tryAgain: {text: 'Proceed to login', btnClass: 'btn-green', action: function(){window.location.replace('login');} }}
                    });
                },
                error: function(errData){
                    $.confirm({
                        icon: 'fa fa-exclamation-triangle', title: 'Error!',typeAnimated: true, content:errData.responseJSON.message, type: 'red',
                        buttons: {tryAgain: {text: 'Proceed to forgot password', btnClass: 'btn-red', action: function(){window.location.replace('forgot-password');} }}
                    });
                },
                complete: function () {
                    $('#update_reset_btn').attr("disabled", false);
                    $('#update_reset_btn').css("cursor", 'pointer');
                    $(".fa-spin").removeClass("d-inline-block");
                }
            });
        }
    });

    $("form[name='checkout']").validate({
        rules: {
            firstname:"required",
            lastname:"required",
            email:{required:true,email:true},
            phone:{required:true,digits:true},
            address:"required",
            state:"required"
        },
        messages: {
            firstname:"enter receivers firstname",
            lastname:"enter receivers lastname",
            email:"enter a valid email address",
            phone:"enter valid mobile number",
            address:"enter receivers address",
            state:"enter receivers state"
        },
        submitHandler: function(form, e) {
            e.preventDefault();
            if ($.trim($('#s_email').val()) !== "") {
                if($('input[name=payment_method]:checked', '#checkout').val() === 'DebitCard') {
                    var total_amount = $('#total_amount').val();
                    FlutterwaveCheckout({
                        public_key: "FLWPUBK-61f3eff2fc9c3134a22556aa1f0cb707-X",
                        tx_ref: ''+Math.floor((Math.random() * 1000000000) + 1),
                        amount: total_amount,
                        currency: "NGN",
                        payment_options: "card,mobilemoney,ussd",
                        customer: {
                            email: $.trim($('#s_email').val())
                        },
                        callback: function (data) {
                            $("#payment_ref").val(data.transaction_id);
                            $("#checkout_btn").attr("disabled", true);
                            $('#checkout_btn').css("cursor", 'not-allowed');
                            $(".fa-spin").addClass("d-inline-block");
                            if (data.status==="successful"){
                                var checkout_form = $('#checkout');
                                var form_data = JSON.stringify(checkout_form.serializeObject());
                                $.ajax({url: "controllers/v1/create-order.php",type:"POST", contentType:'application/json', data: form_data,
                                    success: function (data){
                                        storeOrderDetails(data.order_id);
                                        document.getElementById("checkout").reset();
                                        localStorage.removeItem('shoppingCart');
                                        window.location.replace("success");
                                    }, error: function () {
                                        toastr.options = {"closeButton": true, "positionClass": "toast-bottom-right"};
                                        if (errData.responseJSON.message !== "AuthErr") {
                                            toastr["error"](errData.responseJSON.message);
                                        } else {
                                            window.location.replace('login');
                                        }
                                    }
                                });
                            }
                        },
                        customizations: {
                            title: "Amazon Lagos",
                            description: "Payment for items in cart",
                            logo: "http://localhost/amazonlagos/images/amazon_brand_logo.png",
                        },
                        onclose: function() {
                            alert('Transaction Cancelled');
                            $('#checkout_btn').attr("disabled", false);
                            $('#checkout_btn').css("cursor", 'pointer');
                            $(".fa-spin").removeClass("d-inline-block");
                        },
                    });
                } else {
                    $('#payWithTransfer').modal({
                        keyboard: false
                    });
                }
            } else {
                var checkout_form = $('#checkout');
                var form_data = checkout_form.serializeObject();
                $.ajax({
                    url: "controllers/v1/storeUrl.php", type : "POST", data : form_data,
                    success: function(data) {
                        // $.confirm({
                        //     icon: 'fa fa-exclamation-triangle',closeIcon: true, title: "Error!",typeAnimated: true, content: "You need to be logged in to complete order",
                        //     type: 'red',buttons: {tryAgain: {text: 'Login', btnClass: 'btn-red', action: function(){} }}
                        // });
                        window.location.replace('login');
                    }
                });
            }
        }
    });

    $("form[name='transfer_request_form']").validate({
        rules: {account_name:"required"},
        messages: {account_name:"enter sender account name"},
        submitHandler: function(form, e) {
            e.preventDefault();
            var name = $("#account_name").val();
            var amount_trans = $("#amount_transferred").val();
            $("#checkout_btn").attr("disabled", true);
            $("#pay_transfer_btn").attr("disabled", true);
            $('#checkout_btn').css("cursor", 'not-allowed');
            $('#pay_transfer_btn').css("cursor", 'not-allowed');
            $(".fa-spin").addClass("d-inline-block");
            var checkout_form = $('#checkout');
            var form_data = JSON.stringify(checkout_form.serializeObject());
            $.ajax({url: "controllers/v1/create-order.php",type:"POST", contentType:'application/json', data: form_data,
                success: function (data){
                    storeOrderDetails(data.order_id);
                    document.getElementById("checkout").reset();
                    localStorage.removeItem('shoppingCart');
                    storeTransferRequest(data.order_id,name,amount_trans);
                    window.location.replace("_success");
                }, error: function () {
                    toastr.options = {"closeButton": true, "positionClass": "toast-bottom-right"};
                    if (errData.responseJSON.message !== "AuthErr") {
                        toastr["error"](errData.responseJSON.message);
                    } else {
                        window.location.replace('login');
                    }
                },complete: function () {
                    $('#checkout_btn').attr("disabled", false);
                    $('#pay_transfer_btn').attr("disabled", false);
                    $('#checkout_btn').css("cursor", 'pointer');
                    $('#pay_transfer_btn').css("cursor", 'pointer');
                    $(".fa-spin").removeClass("d-inline-block");
                }
            });
        }
    });

    $("form[name='review']").validate({
        rules: {
            review_name: "required",
            rating_value: "required",
            review_comment: {required:true,minlength:20},
        },
        messages: {
            review_name: "Name is required",
            rating_value: "Rating is required",
            review_comment: {required: "Comment is required", minlength: "Comment must be at least 20 characters"},
        },
        submitHandler: function (form, e) {
            e.preventDefault();
            var review_form = $('#review');
            var form_data = JSON.stringify(review_form.serializeObject());

            $("#review_btn").attr("disabled", true);
            $('#review_btn').css("cursor", 'not-allowed');
            $(".fa-spin").addClass("d-inline-block");
            $.ajax({
                url: "controllers/v1/create-review-rating.php",
                type: "POST",
                contentType: 'application/json',
                data: form_data,
                success: function () {
                    document.getElementById("review").reset();
                    window.location.replace('_feedback');
                },
                error: function (errData) {
                    toastr.options = {"closeButton": true, "positionClass": "toast-bottom-right"};
                    toastr["error"](errData.responseJSON.message);
                },
                complete: function () {
                    $('#review_btn').attr("disabled", false);
                    $('#review_btn').css("cursor", 'pointer');
                    $(".fa-spin").removeClass("d-inline-block");
                }
            });
        }
    });

    $("form[name='newsLetter']").on('submit',function (e) {
        e.preventDefault();
        var newsLetter = $('#newsLetter');
        var form_data = JSON.stringify(newsLetter.serializeObject());
        $("#newsBtn").attr("disabled", true);$('#newsBtn').css("cursor", 'not-allowed');
        $.ajax({
            url: "controllers/v1/create-newsletter.php", type: "POST", contentType: 'application/json', data: form_data,
            success: function (data) {
                document.getElementById("newsLetter").reset();
                toastr.options = {"closeButton": true, "positionClass": "toast-bottom-right"};
                toastr["success"](data.message);
            },
            error: function (errData) {
                toastr.options = {"closeButton": true, "positionClass": "toast-bottom-right"};
                toastr["error"](errData.responseJSON.message);
            },
            complete: function () {
                $('#newsBtn').attr("disabled", false);$('#newsBtn').css("cursor", 'pointer');
            }
        });
    });

    $("form[name='shoppingListPayment']").validate({
        rules: {shop_fullname:"required", shop_email:{required:true,email:true},shop_phone:{required:true,digits:true}},
        messages: {shop_fullname:"Fullname is required", shop_email:"Enter a valid email address",shop_phone:"Enter a valid WhatsApp number"},
        submitHandler: function(form, e) {
            e.preventDefault();

            $("#shoppingListPaymentBtn").attr("disabled", true);
            $('#shoppingListPaymentBtn').css("cursor", 'not-allowed');
            $(".fa-spin").addClass("d-inline-block");
                var shoppingListPayment = $('#shoppingListPayment');
                var form_data = JSON.stringify(shoppingListPayment.serializeObject());
                $.ajax({
                    url: "controllers/v1/create-shopping-list.php",type:"POST", contentType:'application/json', data: form_data,
                    success: function (data) {
                        document.getElementById("shoppingListPayment").reset();
                        $.confirm({
                            icon: 'fa fa-check-circle',closeIcon:false,title:"Success",typeAnimated:true,content:data.message,
                            type:'green',buttons:{tryAgain:{text:'Continue Shopping',btnClass:'btn-green',action:function(){window.location.replace('./')} }}
                        });
                    },
                    error: function (errData) {
                        toastr.options = {"closeButton": true, "positionClass": "toast-bottom-right"};
                        toastr["error"](errData.responseJSON.message);
                    }
                });
            }
    });

    $("form[name='shopTransferPayment']").validate({
        rules: {account_name:"required",shop_amount:{required:true,digits:true}},
        messages: {account_name:"enter sender account name",shop_amount:"invalid amount"},
        submitHandler: function(form, e) {
            e.preventDefault();
            var shop_fullname = $("#shop_fullname").val();
            var shop_email = $("#shop_email").val();
            var make_deposit = $('input[name=make_deposit]:checked', '#shoppingListPayment').val();
            var shop_account_name = $("#shop_account_name").val();
            var shop_amount = $("#shop_amount").val();
            var shop_pay_method = $('input[name=shop_pay_method]:checked', '#shoppingListPayment').val();

            $("#pay_transfer_btn").attr("disabled", true);
            $('#pay_transfer_btn').css("cursor", 'not-allowed');
            $(".fa-spin").addClass("d-inline-block");

            $.ajax({
                url: "controllers/v1/create-shopping-list.php",type:"POST", contentType:'application/json',
                data: JSON.stringify({shop_fullname,shop_email,make_deposit,shop_account_name,shop_amount,shop_pay_method}),
                success: function (data) {
                    document.getElementById("shopTransferPayment").reset();
                    $.confirm({
                        icon: 'fa fa-check-circle',closeIcon:false,title:"Success",typeAnimated:true,content:data.message,
                        type:'green',buttons:{tryAgain:{text:'Continue Shopping',btnClass:'btn-green',action:function(){window.location.replace('./')} }}
                    });
                },
                error: function (errData) {
                    toastr.options = {"closeButton": true, "positionClass": "toast-bottom-right"};
                    toastr["error"](errData.responseJSON.message);
                },
                complete:function () {
                    $('#pay_transfer_btn').attr("disabled", false);
                    $('#pay_transfer_btn').css("cursor", 'pointer');
                    $(".fa-spin").removeClass("d-inline-block");
                }
            });
        }
    });

    $("form[name='contactUs']").validate({
        rules: {
            email: {required: true, email: true},
            message: {required:true,minlength:20}
        },
        messages: {
            email: "Please enter a valid email address",
            message: "Message must be at least 20 charaters"
        },
        submitHandler: function (form, e) {
            e.preventDefault();
            var contactUs = $('#contactUs');
            var form_data = JSON.stringify(contactUs.serializeObject());

            $("#contactBtn").attr("disabled", true);
            $('#contactBtn').css("cursor", 'not-allowed');
            $(".fa-spin").addClass("d-inline-block");
            $.ajax({
                url: "controllers/v1/contact-us-api.php",
                type: "POST",
                contentType: 'application/json',
                data: form_data,
                success: function (data) {
                    document.getElementById("contactUs").reset();
                    toastr.options = {"closeButton": true, "positionClass": "toast-top-right"};
                    toastr["success"](data.message);
                },
                error: function (errData) {
                    $.confirm({
                        icon: 'fa fa-exclamation-triangle', title: 'Registration failed',typeAnimated: true, buttons: false,
                        content:errData.responseJSON.message, type: 'red'
                    });
                },
                complete: function () {
                    $('#contactBtn').attr("disabled", false);
                    $('#contactBtn').css("cursor", 'pointer');
                    $(".fa-spin").removeClass("d-inline-block");
                }
            });
        }
    });
});

$('.product_click').on('click', '.add_to_wlist', function(e) {
    e.preventDefault();
    var product_id = $(this).data('id');
    if (product_id==="") {
        $.confirm({
            icon: 'fa fa-exclamation-triangle', title: 'Encountered an error',typeAnimated: true, buttons: false,
            content: 'Something went wrong, refresh and try again.', type: 'red'
        });
    } else {
        $.ajax({
            url: "controllers/v1/create-user-wishlist.php", type : "POST", contentType : 'application/json',
            data : JSON.stringify({product_id:product_id}),
            success: function(data) {
                toastr.options = {"closeButton": true, "positionClass": "toast-bottom-right"};
                toastr["success"](data.message);
                $('#wBtn'+product_id).addClass('active');
            },
            error: function(errData){
                if (errData.responseJSON.status===400) {
                    $.confirm({
                        icon: 'fa fa-exclamation-triangle',closeIcon: true, title: "Error!",typeAnimated: true, content: errData.responseJSON.message,
                        type: 'red',buttons: {tryAgain: {text: 'Login', btnClass: 'btn-red', action: function(){window.location.replace('login')} }}
                    });
                } else {
                    toastr.options = {"closeButton": true, "positionClass": "toast-bottom-left"};
                    toastr["error"](errData.responseJSON.message);
                }
            }
        });
    }
});

function storeOrderDetails(id) {
    //Retrieve Data from Local Storage
    var order_id_arr = [];
    var general_arr=[];

    var cart = JSON.parse(localStorage.getItem('shoppingCart'));
    order_id_arr.push({order_id: id});
    general_arr.push(order_id_arr,cart);

    general_arr = JSON.stringify(general_arr);
    $.ajax({
        url: "controllers/v1/create-order-details.php", type : "POST", contentType : 'application/json', data : general_arr,
        success: function(data) {},
        error: function(errData){}
    });
}

function storeTransferRequest(order_id,account_name,amount) {
    $.ajax({
        url: "controllers/v1/create-transfer-request.php", type : "POST", contentType : 'application/json',
        data : JSON.stringify({order_id:order_id,account_name:account_name,amount:amount}),
        success: function(data) {
            document.getElementById("checkout").reset();
            setTimeout(function () {window.location.replace("_success");}, 1500);
        },
        error: function(errData){
            toastr.options = {"closeButton": true, "positionClass": "toast-bottom-right"};
            toastr["error"](errData.responseJSON.message);
        }
    });
}

$("#user_order_details").on("click",".remove-order-item",function (e) {
    e.preventDefault();
    var odi = $(this).data('odi');

    $(".remove-order-item").attr("disabled", true);$('.remove-order-item').css("cursor", 'not-allowed');
    $.confirm({
        type:'dark',title:false,content:'Are you sure you want to return item ?',autoClose:'cancelAction|8000',
        buttons: {
            confirm: {text: 'Yes, Return',action: function () {
                    $.get("controllers/v1/return-order-item-product.php?odi="+parseInt(odi), function () {
                        $.alert({title:false,content:"Request sent, our customer support will contact you shortly",
                            buttons: {okay: {action: function () {window.location.reload();}}}
                        });
                    });
                }},
            cancelAction: {text: 'cancel',action: function () {} }
        }
    });
    $(".remove-order-item").attr("disabled", false);$('.remove-order-item').css("cursor", 'pointer');
});