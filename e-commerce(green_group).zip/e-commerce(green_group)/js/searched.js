$(document).on('click', '.page-link', function(e){
    e.preventDefault();
    var page_number = $(this).data('page-number');
    var current_query;
    if( $(this).data('query') ) {
        current_query = '?' + $(this).data('query');
    } else {
        current_query = '';
    }
    $.get('searched_products.php' + current_query, {'page-number' : page_number}, function(data){
        $('#all-products').html(data);
    });
});

$(document).ready(function () {
    $(".product_action_filter").on('click','.product_check',function (e) {
        $('.loading-overlay').show();
        var brand = get_filter_text('brand');

        // queryBuilder("?brand="+brand);


        var sortBy = get_filter_text_radio('sortBy');
        var size = get_filter_text('size');
        var rate = get_filter_text('rate');
        var os = get_filter_text('os');

        var price_start = get_filter_text_input('price_start');
        var price_end = get_filter_text_input('price_end');
        var per_page = get_filter_text_input('page');

        $(".form-control").css("border-color", '#ccc');

        var err1 = 0;var err2 = 0;
        if (price_start ==='') { err1 = err1 + 1; }
        if (price_end ==='') { err2 = err2 + 1; }

        if (err1 ===0 && err2 ===0) {}

        $.get('searched_products.php', {brand,sortBy,size,os,price_start,price_end,rate,per_page}, function(data){
            $('.loading-overlay').fadeOut("slow");
            $('#all-products').html(data);
        });
    });

    function get_filter_text(text_id) {
        var filterData = [];
        $('.'+text_id+':checked').each(function() {filterData.push($(this).val());});
        return filterData;
    }
    function get_filter_text_input(text_id) {return $('.'+text_id).val();}
    function get_filter_text_radio(text_id) {
        var filterData ='';
        $('.'+text_id+':checked').each(function() {filterData = $(this).val();});
        return filterData;
    }

    // function queryBuilder(qString) {
    //     var newurl = window.location.protocol + "//" + window.location.host + window.location.pathname + qString;
    //     window.history.pushState({path: newurl}, '', newurl);
    // }

});


