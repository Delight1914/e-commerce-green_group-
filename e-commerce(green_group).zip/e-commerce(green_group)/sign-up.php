<?php ob_start(); session_start();
include_once("inc/header.nav.php"); ?>
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="card my-5 acc_form_wrapper">
                    <div class="card-header bg-white"><h5 class="text-center text_upper">Sign Up</h5></div>
                    <div class="card-body px-5">
                        <form name="registration" id="registration">
                            <div class="row">
                                <div class="col-12 col-md-6 mb-3">
                                    <div class="form_grp">
                                        <label class="text_capital d-block" for="firstname">First Name</label>
                                        <input type="text" class="d-block w-100" name="firstname" id="firstname">
                                    </div>
                                </div>
                                <div class="col-12 col-md-6 mb-3">
                                    <div class="form_grp">
                                        <label class="text_capital d-block" for="lastname">Last Name</label>
                                        <input type="text" class="d-block w-100" name="lastname" id="lastname">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12">
                                    <div class="form_grp mb-3">
                                        <label class="text_capital d-block" for="email">Email Address</label>
                                        <input type="email" class="d-block w-100" name="email" id="email">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12">
                                    <div class="form_grp mb-3">
                                        <label class="text_capital d-block" for="phone">Phone Number</label>
                                        <input type="text" class="d-block w-100" name="phone" id="phone">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12 col-md-6 mb-3">
                                    <div class="form_grp mb-3">
                                        <label class="text_capital d-block" for="password">Password</label>
                                        <input type="password" class="d-block w-100" name="password" id="password">
                                    </div>
                                </div>
                                <div class="col-12 col-md-6 mb-3">
                                    <div class="form_grp mb-3">
                                        <label class="password_capital d-block" for="confirm_password">Confirm Password</label>
                                        <input type="password" class="d-block w-100" name="confirm_password" id="confirm_password">
                                    </div>
                                </div>
                            </div>
                            <div class="form_grp mb-3">
                                <button type="submit" class="btn-block py-2 light_grn_btn rounded" id="registration_btn">
                                    <i class="fa fa-spinner fa-spin mr-3 d-none"></i>Register
                                </button>
                            </div>
                        </form>
                        <div class="my-5">
                            <small class="d-block text-center mb-1">Already have an account?</small>
                            <a href="login" class="d-block text-center border_lemon py-2 txt_lemon green_hover rounded">Login</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php include_once("inc/footer.nav.php"); ?>