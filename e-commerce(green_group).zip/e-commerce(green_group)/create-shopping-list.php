<?php ob_start(); session_start(); include_once("inc/header.nav.php"); ?>
<style>
    .table td{ padding: 0.3em !important;}
    #user_weekly_shopping_list table thead tr th:nth-child(even) {
        background-color: #1f3200;
        opacity: 0.8;
    }
    #user_weekly_shopping_list table thead tr th:nth-child(odd) {
        background-color: #1f3200;
    }
</style>
<div id="user_weekly_shopping_list">
    <div class="container my-3">
        <div class="flex_align_center">
            <button class="bo_back_history border-0" onclick="goBack()"><i class="fas fa-long-arrow-alt-left fa-2x"></i></button>
            <h4 class="m-0 text_capital">List</h4>
        </div>
    </div>
    <section>
        <div class="shopping_form_wrapper m-3">
            <div class="inner">
                <form name="shoppingListForm" id="shoppingListForm">
                    <div class="table_wrapper">
                        <table class="table bg-white">
                            <thead>
                            <tr>
                                <th scope="col" class="sticky-col first-col border-right number_cell">S/N</th>
                                <th scope="col" class="name_cell">Product Name</th>
                                <th scope="col" class="brand_cell">Brand/Manufacturer</th>
                                <th scope="col" class="qty_cell">Quantity</th>
                                <th scope="col" class="info_cell">Color/Size/Other Info</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php for ($i=1; $i<=20;$i++) { ?>
                                <tr>
                                    <td scope="row" class="sticky-col first-col border-right number_cell font-weight-bolder"><?=$i;?></td>
                                    <td class="name_cell">
                                        <input type="text" class="shopping_list_form_input border-0 product_name_input" name="product_name[<?=$i;?>]" id="product_name_<?=$i;?>">
                                    </td>
                                    <td class="brand_cell">
                                        <input type="text" class="shopping_list_form_input border-0 producer_input" name="producer[<?=$i;?>]" id="producer_<?=$i;?>">
                                    </td>
                                    <td class="qty_cell">
                                        <input type="number" class="shopping_list_form_input border-0 qty_input" name="qty[<?=$i;?>]" id="qty_<?=$i;?>">
                                    </td>
                                    <td class="info_cell">
                                        <input type="text" class="shopping_list_form_input border-0 c_s_o_input" name="c_s_o[<?=$i;?>]" id="c_s_o_<?=$i;?>">
                                    </td>
                                </tr>
                            <?php } ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="form_grp mb-3 text-left">
                        <button type="submit" class="py-2 px-5 my-2 light_grn_btn rounded" id="shopBtn">
                            <i class="fa fa-spinner fa-spin mr-3 d-none"></i>Next
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </section>
</div>
<?php include_once("inc/footer.nav.php"); ?>
<script>
    $(document).ready(function () {
        $('form#shoppingListForm').on('submit', function (e) {
            e.preventDefault();
            var shopListForm = $('#shoppingListForm');

            $("#shopBtn").attr("disabled", true);
            $('#shopBtn').css("cursor", 'not-allowed');
            $(".fa-spin").addClass("d-inline-block");
            $.ajax({
                url: "controllers/v1/hold-shop-list.php", type: "POST", data: shopListForm.serialize(),
                success: function (data) {
                    toastr.options = {"closeButton": true, "positionClass": "toast-top-right"};
                    toastr["success"](data.message);
                    window.location.replace('shopping-list-payment');
                },
                error: function (errData) {
                    $.confirm({
                        icon: 'fa fa-exclamation-triangle', closeIcon: true, title: "Error!", typeAnimated: true,
                        content: errData.responseJSON.message, type: 'red',buttons:false
                    });
                },
                complete: function () {
                    $('#shopBtn').attr("disabled", false);
                    $('#shopBtn').css("cursor", 'pointer');
                    $(".fa-spin").removeClass("d-inline-block");
                }
            });
        });
    });
</script>
