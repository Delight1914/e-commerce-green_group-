Login Credentials

ADMIN
link - http://localhost/e-commerce(green_group)/Admin/
email - admin@gmail.com
password - 1234567

CUSTOMER
link - http://localhost/e-commerce(green_group)/login
email - customer@gmail.com
password - 1234567


Database Name - db_ecommerce