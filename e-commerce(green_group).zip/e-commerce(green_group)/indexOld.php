<?php ob_start(); session_start(); include_once("inc/header.nav.php"); ?>
<section>
    <div class="cont_wrapper">
        <div class="row my-0 my-md-2 my-lg-3 no-gutters">
            <div class="col-12 col-md-9 col-lg-9">
                <div class="bd-example" style="position: relative;">
                    <div id="carouselExampleCaptions" class="carousel slide carousel-fade" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
                            <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
                            <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
                        </ol>
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img src="./images/product_3.png" class="d-block w-100 rounded" alt="product three">
                            </div>
                            <div class="carousel-item">
                                <img src="./images/product_4.jpg" class="d-block w-100 rounded" alt="product four">
                            </div>
                            <div class="carousel-item">
                                <img src="./images/product_5.png" class="d-block w-100 rounded" alt="product five">
                            </div>
                        </div>
                    </div>
                    <div style="display: flex; justify-content: space-between; position: absolute; right: 1em; left: 1em; top: 40%; z-index: 3">
                        <span id="prev"></span>
                        <span id="next"></span>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-3 col-lg-3">
                <aside class="hero_aside" style="margin-left: 2px;">
                    <div class="inner">
                        <div class="pl-lg-2 pb-lg-1 w-100 d-none d-md-block card_1">
                            <a href="#">
                                <!-- image size = 355 X 270 -->
                                <img src="./images/test3_image.png" class="img-fluid rounded" alt="">
                            </a>
                        </div>
                        <div class="pt-2 pr-1 pr-md-0 text-center pl-lg-2 pt-lg-1 card_2 ">
                            <a href="#">
                                <!-- image size = 500 X 500 -->
                                <img src="./images/test5_image.png" class="img-fluid rounded" alt="">
                            </a>
                        </div>
                        <div class="pt-2 pl-1 pl-md-0 text-center pt-lg-1 pl-lg-2 card_3">
                            <a href="#">
                                <!-- image size = 500 X 500 -->
                                <img src="./images/test4_image.png" class="img-fluid rounded" alt="">
                            </a>
                        </div>
                    </div>
                </aside>
            </div>
        </div>
    </div>
</section>

<section>
    <div class="cont_wrapper bg-white section_inner my-3 rounded">
        <div class="border-bottom px-md-4"><h5 class="pt-2 mx-2 text_capital">Latest Products</h5></div>
        <div class="py-md-2 px-md-4">
            <div class="relative_position">
                <div class="owl-carousel owl-theme product_slider_one">
                <?php
                $url = CONTROLLER_ROOT_URL."/v1/read-latest-products.php";
                $object = $api->curlQueryGet($url);
                foreach ($object->latest_product as $item) {
                    ?>
                    <div class="card product_card shadow border-0 my-3">
                        <a href="details/<?=$item->product_sku;?>">
                            <img style="max-height: 230px" src="./admin/adminImg/products/<?=$item->product_img;?>" class="card-img-top" alt="<?=substr($item->product_title,0,15);?>">
                            <div class="card-body">
                                <h6 class="card-title text_capital m-0" style="min-height: 40px;"><?=$item->product_title;?></h6>
                                <p class="card-text prod_price">₦ <?=number_format($item->product_price,0);?></p>
                            </div>
                        </a>
                    </div>
                    <?php } ?>
                </div>
                <div class="custom_prod_nav_wrapper">
                    <span class="latest_product_nav_prev"></span>
                    <span class="latest_product_nav_next"></span>
                </div>
            </div>
        </div>
    </div>
</section>

<section>
    <div class="cont_wrapper my-3 bg-white pb-3">
        <div class="bg-dark rounded-top text-white py-3 mb-2">
            <div class="cont_wrapper"><h5 class="m-0 m-0 text_capital">Best Selling Products</h5></div>
        </div>
        <div class="cont_wrapper">
            <div class="row no-gutters">
                <?php
                $url = CONTROLLER_ROOT_URL."/v1/read-bestselling-products.php";
                $object = $api->curlQueryGet($url);
                if ($object->status == 200){
                foreach ($object->bestselling_products as $item) {
                ?>
                <div class="col-6 col-md-3 col-sm-6">
                    <div class="card product_card shadow border-0 m-1">
                        <a href="details/<?=$item->product_sku;?>">
                            <img src="./admin/adminImg/products/<?=$item->product_img;?>" class="card-img-top" alt="...">
                            <div class="card-body">
                                <h6 class="card-title text_capital m-0" style="min-height: 40px;"><?=$item->product_title;?></h6>
                                <p class="card-text prod_price">₦ <?=number_format($item->product_price,0);?></p>
                            </div>
                        </a>
                    </div>
                </div>
                <?php } } ?>
            </div>
        </div>
    </div>
</section>

<section>
    <div class="cont_wrapper section_inner bg-white my-3">
        <div class="border-bottom px-md-4"><h5 class="pt-2 mx-2 text_capital">Top Brands</h5></div>
        <div>
            <div class="owl-carousel brand_slider_one cont_wrapper">
                <div><img src="./images/nexus_brand_logo.png" alt="product brand thumbnail"></div>
                <div><img src="./images/scanfrost_brand_logo.png" alt="product brand thumbnail"></div>
            </div>
        </div>
    </div>
</section>

<section>
    <div class="cont_wrapper bg-white py-3 my-2">
        <div class="cont_wrapper">
            <h6 class="m-0 text_capital">About lagos Nigeria’s Largest Online Mall – GAC Corporation</h6><br />
            <p>
                GAC Corporation Lorem ipsum dolor sit, amet consectetur adipisicing elit. Eius sapiente unde dicta, laboriosam voluptatem 
                facere suscipit hic placeat porro natus cum officia, numquam culpa ab deleniti non. Magnam qui fuga facilis, sunt aut incidunt temporibus hic, 
                quae quasi expedita ipsa vitae quam molestiae voluptatem autem odit excepturi officia laboriosam ut ad, aliquam consectetur. Vero alias accusamus
                 quae nisi accusantium necessitatibus cupiditate sequi. Accusamus, iste tempore. Ratione eum, assumenda fugiat error nesciunt dolor architecto quisquam magni molestiae
                alias quaerat esse voluptatem nobis quod harum quos asperiores obcaecati delectus aut, ipsam quis illo qui officia laborum. 
                Quae quibusdam assumenda optio quaerat sequi!
            </p>
        </div>
    </div>
</section>

<?php include_once("inc/footer.nav.php"); ?>
