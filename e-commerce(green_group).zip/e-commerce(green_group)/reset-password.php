<?php ob_start(); session_start();
if (isset($_SESSION['user_login']) && isset($_SESSION['user_login']['customer_id'])) header('Location: index');
include_once("inc/header.nav.php"); ?>
    <style>
        .cstm_inner_wrapper{width:500px;}
        .acc_form_wrapper{width:450px;}
    </style>
<?php
$selector = isset($_GET['selector']) ? $_GET['selector']:null;
$validator = isset($_GET['validator']) ? $_GET['validator']:null;

if (empty($selector) || empty($validator)) { ?>
    <div class="container" style="margin: 50px auto;display: flex;flex-direction: column;align-items: center;">
        <h1 class="text-center text-danger" style="font-size: 120px">404</h1>
        <p class="text-center" style="font-size: 24px">Page not found (invalid link) </p>
        <p class="text-center" style="font-size: 16px"><a href="forgot-password">Back to forgot password</a></p>
    </div>
<?php } else {
    if (ctype_xdigit($selector) !== false && ctype_xdigit($validator) !== false) {
?>
<div class="cont_wrapper">
    <div class="bg-white mt-5 cstm_inner_wrapper">
        <div class="border-bottom p-3 text-center">
            <h6 class="m-0">Reset Password</h6>
        </div>
        <div class="py-4 px-2 acc_form_wrapper py-5">
            <form name="update_reset_form" id="update_reset_form">
                <input type="hidden" name="selector" id="selector" value="<?= $selector; ?>">
                <input type="hidden" name="validator" id="validator" value="<?= $validator; ?>">
                <div class="form_grp mb-4">
                    <label class="text_capital d-block" for="password">New Password</label>
                    <input type="password" class="d-block w-100 py-2" name="password" id="password">
                </div>
                <div class="form_grp mb-4">
                    <label class="text_capital" for="confirm_password">Confirm Password</label>
                    <input type="password" class="d-block w-100 py-2" name="confirm_password" id="confirm_password">
                </div>
                <div class="form_grp mb-4">
                    <button type="submit" class="btn-block py-2 light_grn_btn" id="update_reset_btn">
                        <i class="fa fa-spinner fa-spin mr-3 d-none"></i>SUBMIT
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
    <?php } else { ?>
        <div class="container" style="margin: 50px auto;display: flex;flex-direction: column;align-items: center;">
            <h1 class="text-center text-danger" style="font-size: 120px">404</h1>
            <p class="text-center" style="font-size: 24px">Page not found (invalid link)</p>
            <p class="text-center" style="font-size: 16px"><a href="forgot-password">Back to forgot password</a></p>
        </div>
   <?php } } ?>
<?php include_once("inc/footer.nav.php"); ?>