<?php ob_start(); session_start();
include_once("inc/header.nav.php");
?>
    <style>.myBg{background: #868686 !important;}
        .myCtrl{font-size:17px;font-weight: bold;padding: 5px 10px;}
    </style>
    <div class="container show_empty" id="cart_page_wrapper">
        <h5 class="py-2">Cart (<span class="total-count"></span> Item)</h5>
        <div class="row p-2 text-white heading_label myBg">
            <div class="col col-md-5 d-none d-md-block">Item</div>
            <div class="col col-md-2 d-none d-md-block">Quantity</div>
            <div class="col col-md-2 d-none d-md-block">Price</div>
            <div class="col col-md-2 d-none d-md-block"></div>
        </div>
        <!--  Cart  -->
        <div class="show-cart"></div>

        <!-- Total Amount -->
        <div class="row">
            <div class="col">
                <div class="cart_summary_wrapper float_r mb-2">
                    <label for="">TOTAL:&nbsp;</label>
                    <span class="total_cost"><span>₦</span>&nbsp;<span class="font-weight-bolder sub-total-cart"></span></span>
                    <div class="info">Without shipping fee</div>
                </div>
            </div>
        </div>
        <!-- Process buttons -->
        <div class="row">
            <div class="col">
                <div class="process_btn_wrapper">
                    <a href="checkout" class="light_grn_btn px-5 py-2 text-center process_btn process_checkout_btn">PROCEED TO CHECKOUT</a>
                    <a href="./" class="w_btn px-5 py-2 text-center process_btn continue_shopping_btn">CONTINUE SHOPPING</a>
                </div>
            </div>
        </div>
    </div>
<?php  include_once("inc/footer.nav.php"); ?>