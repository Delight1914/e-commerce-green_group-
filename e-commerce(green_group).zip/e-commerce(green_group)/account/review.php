<?php ob_start(); session_start();
if (!isset($_SESSION['user_login']) && !isset($_SESSION['user_login']['customer_id'])) header('Location: ../login');
if ($_GET['product_id']=='' || $_GET['order_detail_id']=='') {die("INVALID LINK");}

include_once("../inc/header.nav.php"); ?>
    <div class="cont_wrapper" id="user_review_page">
        <div class="container-fluid">
            <div class="row d-block d-md-none">
                <div class="col">
                    <button class="bo_back_history border-0" onclick="window.location.replace('account/index')">
                        <i class="fas fa-long-arrow-alt-left fa-2x"></i>
                    </button>
                </div>
                <div class="col"><h5 class="mt-2">Pending Review</h5></div>
            </div>
        </div>
        <div class="row mt-2 mt-md-5">
            <div class="col-12 col-md-3 d-none d-md-block">
                <?php require_once ('account-sidebar.php')?>
            </div>
            <main class="col-12 col-md-9 mb-3 mt-3 mt-md-0 p-0" id="user-profile-page">
                <div class="bg-white">
                    <div class="border-bottom p-3">
                        <h4 class="m-0">
                            <button class="back_history border-0" onclick="goBack()">
                                <i class="fas fa-long-arrow-alt-left"></i></button><span>Review product</span>
                        </h4>
                    </div>
                </div>
                <div>
                    <div class="text-white p-3" style="background: #FE5F55;"><aside>Help us get better by giving your feedback</aside></div>
                    <div class="border-bottom">
                        <?php
                        $url = CONTROLLER_ROOT_URL."/v1/read_product_by_order_details_id.php?order_detail_id=".$_GET['order_detail_id']."&product_id=".$_GET['product_id'];
                        $object = $api->curlQueryGet($url);
                        if ($object->status == 200){
                            foreach ($object->product as $item) {
                                ?>
                                <div class="card border-0 py-3">
                                    <div class="row no-gutters">
                                        <div class="col-md-4 text-md-center">
                                            <img style="width:200px;height:130px" src="admin/adminImg/products/<?=$item->product_img;?>" class="card-img" alt="...">
                                        </div>
                                        <div class="col-md-8">
                                            <div class="card-body">
                                                <h6 class="card-title"><?=$item->product_title;?></h6>
                                                <p class="card-text"><strong>Qty:</strong>&nbsp;<span><?=$item->product_qty;?></span></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php } }?>
                    </div>
                    <form name="review" id="review">
                        <div class="bg-white p-3">
                            <fieldset class="container">
                                <div class="row">
                                    <div class="col-12 col-md-6">
                                        <div class="form-row">
                                            <div class="col-12 mb-3">
                                                <label for="review_name">Name</label>
                                                <input type="text" class="d-block w-100" id="review_name" name="review_name" value="<?=$_SESSION['user_login']['fullname'];?>" readonly>
                                            </div>
                                            <div class="col-12 mb-3">
                                                <label for="rating" style="display: block">Rate</label>
                                                <span class="star-rating">
                                                    <i class="far fa-star text-warning review-star"></i>
                                                    <i class="far fa-star text-warning review-star"></i>
                                                    <i class="far fa-star text-warning review-star"></i>
                                                    <i class="far fa-star text-warning review-star"></i>
                                                    <i class="far fa-star text-warning review-star"></i>
                                                </span>
                                                <input type="hidden" name="rating_value" id="rating_value">
                                                <input type="hidden" name="order_details_id" id="order_details_id" value="<?=$_GET['order_detail_id'];?>">
                                                <input type="hidden" name="product_id" id="product_id" value="<?= $_GET['product_id']; ?>">
                                                <input type="hidden" name="customer_id" id="customer_id" value="<?=$_SESSION['user_login']['customer_id'];?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 col-md-6">
                                        <div class="form-row">
                                            <div class="col-12">
                                                <label for="review_comment">Comment</label>
                                                <textarea type="text" rows="5" class="d-block w-100" id="review_comment" name="review_comment"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>
                        </div>
                        <div class="pt-3">
                            <div class="container pt-3 px-0">
                                <div class="row">
                                    <div class="col">
                                        <button type="submit" class="review-btn px-md-5 light_grn_btn btn-lg" id="review_btn">
                                            <i class="fa fa-spinner fa-spin mr-3 d-none"></i>Submit
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </main>
        </div>
    </div>
<?php include_once("../inc/footer.nav.php"); ?>