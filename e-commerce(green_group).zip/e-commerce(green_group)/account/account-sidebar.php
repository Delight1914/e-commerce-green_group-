<div class="nav flex-column nav-pills bg-light" style="margin-bottom: 125px">
    <a class="account-tab-link text_capital
    <?php if(basename($_SERVER['PHP_SELF']) == 'account-profile.php' || basename($_SERVER['PHP_SELF']) == 'index.php')  echo 'active'; ?>"
       href="account/account-profile">My AL Account</a>
    <a class="account-tab-link text_capital
    <?php if(basename($_SERVER['PHP_SELF']) == 'orders.php' || basename($_SERVER['PHP_SELF']) == 'order-details.php') echo 'active'; ?>" href="account/orders">Orders</a>
    <a class="account-tab-link text_capital
    <?php if(basename($_SERVER['PHP_SELF']) == 'pending-review.php' || basename($_SERVER['PHP_SELF']) == 'review.php') echo 'active'; ?>"
       href="account/pending-review">Pending Reviews</a>
    <a class="account-tab-link text_capital
    <?php if(basename($_SERVER['PHP_SELF']) == 'wishlist.php') echo 'active'; ?>" href="account/wishlist">Saved Items</a>
</div>