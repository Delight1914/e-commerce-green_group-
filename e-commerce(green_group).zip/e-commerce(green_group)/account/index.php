<?php ob_start(); session_start();
if (!isset($_SESSION['user_login']) && !isset($_SESSION['user_login']['customer_id'])) header('Location: ../login');
include_once("../inc/header.nav.php"); ?>
<div class="cont_wrapper">
        <div class="container-fluid">
            <div class="row d-block d-md-none">
                <div class="col"><h6 class="font-weight-bolder py-2">MY DASHBOARD</h6></div>
            </div>
            <div class="row mt-2 mt-md-5">
                <div class="col-12 col-md-3">
                    <!-- sidebar -->
                    <?php require_once ('account-sidebar.php')?>
                </div>
                <main class="col-12 col-md-9 mb-3 mt-3 mt-md-0 p-0 d-none d-md-block" id="user-profile-page">
                    <form name="update_profile" id="update_profile">
                        <div class="form-wrapper bg-white">
                            <div class="border-bottom p-3"><h4 class="m-0"> Account Overview</h4></div>
                            <div class="card-body border-bottom">
                                <div class="row">
                                    <div class="col-12 col-md-6">
                                        <div class="form_grp mb-3">
                                            <label class="text_capital d-block" for="email">Current Email</label>
                                            <input type="email" class="d-block w-100" name="email" id="email" value="<?= $_SESSION['user_login']['email']; ?>" />
                                        </div>
                                    </div>
                                    <div class="col-12 col-md-6">
                                        <div class="form_grp mb-3">
                                            <label class="text_capital d-block" for="phone">Mobile Number</label>
                                            <input type="text" class="d-block w-100" name="phone" id="phone" value="<?= $_SESSION['user_login']['phone']; ?>" />
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12 col-md-6">
                                        <div class="form_grp mb-3">
                                            <label class="text_capital d-block" for="firstname">First Name</label>
                                            <input type="text" class="d-block w-100" name="firstname" id="firstname" value="<?= $_SESSION['user_login']['firstname']; ?>" />
                                        </div>
                                    </div>
                                    <div class="col-12 col-md-6">
                                        <div class="form_grp mb-3">
                                            <label class="text_capital d-block" for="lastname">Last Name</label>
                                            <input type="text" class="d-block w-100" name="lastname" id="lastname" value="<?= $_SESSION['user_login']['lastname']; ?>" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-12">
                                        <label class="text-muted font-weight-bold text-uppercase">
                                            <span class="text-danger">*</span> (leave it empty if you are not updating your password)
                                        </label>
                                    </div>
                                    <div class="col-6">
                                        <div class="form_grp mb-3">
                                            <label class="text_capital d-block" for="new_password">New Password</label>
                                            <input type="password" class="d-block w-100" name="new_password" id="new_password">
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form_grp mb-3">
                                            <label class="password_capital d-block" for="repeat_password">Repeat Password</label>
                                            <input type="password" class="d-block w-100" name="repeat_password" id="repeat_password">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form_grp my-3">
                            <button type="submit" class="py-2 light_grn_btn rounded px-4" id="update_btn">
                                <i class="fa fa-spinner fa-spin mr-3 d-none"></i>UPDATE PROFILE
                            </button>
                        </div>
                    </form>
                </main>
            </div>
        </div>
    </div>
<?php include_once("../inc/footer.nav.php"); ?>