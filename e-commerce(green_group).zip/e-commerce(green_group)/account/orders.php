<?php ob_start(); session_start();
if (!isset($_SESSION['user_login']) && !isset($_SESSION['user_login']['customer_id'])) header('Location: ../login');
include_once("../inc/header.nav.php"); ?>
    <div class="cont_wrapper">
        <div class="container-fluid">
            <div class="row d-block d-md-none">
                <div class="col">
                    <button class="bo_back_history border-0" onclick="window.location.replace('account/index')">
                        <i class="fas fa-long-arrow-alt-left fa-2x"></i>
                    </button>
                </div>
            </div>
            <div class="row mt-2 mt-md-5">
                <div class="col-12 col-md-3 d-none d-md-block">
                    <!-- sidebar -->
                    <?php require_once ('account-sidebar.php')?>
                </div>
                <main class="col-12 col-md-9 mb-3 mt-3 mt-md-0" id="user-orders-page">
                    <div class="form-wrapper p-3 bg-white">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-4 col-md-1 d-none d-md-block"><h6>#</h6></div>
                                <div class="col-8 col-md-2 d-none d-md-block"><h6>Date</h6></div>
                                <div class="col-8 offset-4 offset-md-0 col-md-3 d-none d-md-block"><h6>Ship to</h6></div>
                                <div class="col-4 offset-4 offset-md-0 col-md-2 d-none d-md-block"><h6>Order total</h6></div>
<!--                                <div class="col-4  col-md-2 d-none d-md-block"><h6>Payment</h6></div>-->
                                <div class="col-4  col-md-2 d-none d-md-block"><h6>Status</h6></div>
                                <div class="col-12 col-md-2 d-none d-md-block"><h6></h6></div>
                            </div>
                            <?php
                            $n = 0;
                            $url = CONTROLLER_ROOT_URL."/v1/read-order.php?customer_id=".$_SESSION['user_login']['customer_id'];
                            $object = $api->curlQueryGet($url);
                            if($object->status != 200 )  {
                                    echo "<tr><td><h5 class='text-danger'>No ordered item.</h5></td></tr>";
                                } else {
                                    foreach ($object->orders as $item) {
                            ?>
                            <div class="row my-1 p-2 bg-light">
                                <div class="col-4 col-md-1"><?= ++$n; ?></div>
                                <div class="col-8 col-md-2"><?= date('F j,Y', strtotime($item->order_on)); ?></div>
                                <div class="col-8 offset-4 offset-md-0 col-md-3"><?= $item->receiver_fullname; ?></div>
                                <div class="col-4 offset-4 offset-md-0 col-md-2">₦<?= number_format($item->order_amount,2); ?></div>
                                <div class="col-4  col-md-2 text-secondary">
                                    <?=($item->order_status==='Delivered')?"<span class='text-success'>Delivered</span>":"<span class='text-muted'>".$item->order_status."</span>"; ?>
                                </div>
                                <div class="col-12 col-md-2">
                                    <a class="btn-sm btn-block text-center light_grn_btn text-white" href="account/order-details/<?= bin2hex($item->order_id); ?>">View More</a></div>
                            </div>
                            <?php } } ?>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    </div>
<?php include_once("../inc/footer.nav.php"); ?>