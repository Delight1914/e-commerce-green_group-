<?php ob_start(); session_start();
if (!isset($_SESSION['user_login']) && !isset($_SESSION['user_login']['customer_id'])) header('Location: ../login');
include_once("../inc/header.nav.php"); ?>
<div class="cont_wrapper">
    <div class="container-fluid">
        <div class="row d-block d-md-none">
            <div class="col">
                <button class="bo_back_history border-0" onclick="window.location.replace('account/index')">
                    <i class="fas fa-long-arrow-alt-left fa-2x"></i>
                </button>
            </div>
            <div class="col"><h5 class="mt-2">Pending Review</h5></div>
        </div>
    </div>
    <div class="row mt-2 mt-md-5">
        <div class="col-12 col-md-3 d-none d-md-block">
            <?php require_once ('account-sidebar.php')?>
        </div>
        <main class="col-12 col-md-9 mb-3 mt-3 mt-md-0 p-0" id="user-orders-page">
            <div class="form-wrapper bg-white">
            <?php
            $url = CONTROLLER_ROOT_URL."/v1/read-order-pending-review.php?customer_id=".$_SESSION['user_login']['customer_id'];
            $object = $api->curlQueryGet($url);
            if($object->status != 200 )  {
                echo "<div class='card container-fluid mb-3 border-0'><div class='row no-gutters'><div class='col p-4'>No Product Found</div></div></div>";
            } else {
                foreach ($object->pendingReview as $item) {
            ?>
                <div class="card container-fluid mb-3 border-0">
                    <div class=" row no-gutters">
                        <div class="col-4 col-md-3 img_wrapper">
                            <img src="admin/adminImg/products/<?=$item->product_img;?>" class="card-img"style="width:135px">
                        </div>
                        <div class="col-8 col-md-7">
                            <div class="card-body">
                                <h6 class="card-title"><?=$item->product_title;?></h6>
                                <p class="card-text">
                                    <span class="txt_bold"><span>₦</span><span><?=number_format($item->product_price,0);?></span></span><br />
                                    <span><?= date('j F,Y', strtotime($item->order_on)); ?></span>&nbsp;&nbsp;|&nbsp;&nbsp;<span class="txt_lemon"><?=$item->order_status;?></span>
                                </p>
                            </div>
                        </div>
                        <div class="col-12 col-md-2">
                            <a href="account/review/<?=$item->order_details_id;?>/<?=$item->product_id;?>" class="text-center py-2 w-100 light_grn_btn rounded px-3 my-3" style="display: block; ">Rate this product</a>
                        </div>
                    </div>
                </div>
                    <hr class="d-block" style="color: #434343;width:100%;margin:0 auto;" />
                <?php } } ?>
            </div>
        </main>
    </div>
</div>
<?php include_once("../inc/footer.nav.php"); ?>