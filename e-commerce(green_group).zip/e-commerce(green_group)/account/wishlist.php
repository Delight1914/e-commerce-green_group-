<?php ob_start(); session_start();
if (!isset($_SESSION['user_login']) && !isset($_SESSION['user_login']['customer_id'])) header('Location: ../login');
include_once("../inc/header.nav.php"); ?>
    <style>
        .txt_bold{font-size: 18px;}
    </style>
    <div class="cont_wrapper">
        <div class="container-fluid">
            <div class="row d-block d-md-none">
                <div class="col">
                    <button class="bo_back_history border-0" onclick="window.location.replace('account/index')">
                        <i class="fas fa-long-arrow-alt-left fa-2x"></i>
                    </button>
                </div>
                <div class="col"><h5 class="mt-2">Saved Items</h5></div>
            </div>
        </div>
        <div class="row mt-2 mt-md-5">
            <div class="col-12 col-md-3 d-none d-md-block">
                <?php require_once ('account-sidebar.php')?>
            </div>
            <main class="col-12 col-md-9 mb-3 mt-3 mt-md-0 p-0" id="user-orders-page">
            <?php
            $url = CONTROLLER_ROOT_URL."/v1/read_all_wishlist.php?customer_id=".$_SESSION['user_login']['customer_id'];
            $object = $api->curlQueryGet($url);
            if($object->status != 200)  {
                echo "<h5 class='text-danger'>Empty Wishlist.</h5>";
            } else {
                foreach ($object->wishlist as $wItem) {
                    ?>
                <div class="form-wrapper bg-white">
                    <div class="card container-fluid mb-3 border-0">
                        <div class=" row no-gutters">
                            <div class="col-4 col-md-3 img_wrapper">
                                <img style="width: 180px" src="admin/adminImg/products/<?=$wItem->product_img;?>" class="card-img" alt="...">
                            </div>
                            <div class="col-8 col-md-7">
                                <div class="card-body">
                                    <h6 class="card-title text-uppercase font-weight-bold"><?=$wItem->product_title;?></h6>
                                    <p class="card-text">
                                        <span class="txt_bold">
                                            <span>₦ </span>
                                            <span><?=number_format($wItem->product_price,0);?></span>
                                        </span>
                                    </p>
                                </div>
                            </div>
                            <div class="col-12 col-md-2">
                                <div class="d-flex d-md-block">
                                    <button class="text-center py-3 w-100 light_grn_btn rounded px-3 mx-1 my-3 move-item-to-cart" style="display: block; "
                                    data-title="<?= $wItem->product_title; ?>"
                                    data-id="<?= $wItem->product_id; ?>"
                                    data-wlist_id="<?= $wItem->wlist_id; ?>"
                                    data-count="1"
                                    data-price="<?= $wItem->product_price; ?>"
                                    data-image="<?= $wItem->product_img; ?>">Add To Cart</button>
                                    <button class="text-center py-2 w-100 text-danger rounded px-3 mx-1 my-3 wishlist_remove" data-id="<?= $wItem->wlist_id; ?>" style="display: block; ">
                                        <i class="fas fa-trash mr-2"></i>Remove
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php } }?>
            </main>
        </div>
    </div>
<?php include_once("../inc/footer.nav.php"); ?>