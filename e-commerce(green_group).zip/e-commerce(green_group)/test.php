<?php ob_start(); session_start();
if (!isset($_SESSION['user_login']) && !isset($_SESSION['user_login']['customer_id'])) header('Location: ../login');
include_once("../inc/header.nav.php");
?>
<style>
    .remove-order-item{color:#FA5252; background: #efefef;}
    .remove-order-item:hover{background: #CCCCCC;}
</style>
<div class="cont_wrapper" id="user_order_details">
    <div class="container-fluid">
        <div class="row d-block d-md-none">
            <div class="col">
                <button class="bo_back_history border-0" onclick="window.location.replace('account/index')">
                    <i class="fas fa-long-arrow-alt-left fa-2x"></i>
                </button>
            </div>
        </div>
        <div class="row mt-2 mt-md-5">
            <div class="col-12 col-md-3 d-none d-md-block">
                <!-- sidebar -->
                <?php require_once ('account-sidebar.php')?>
            </div>
            <main class="col-12 col-md-9 mb-3 mt-3 mt-md-0" id="user-orders-page">
                <div class="bg-white">
                    <?php
                    $url = CONTROLLER_ROOT_URL."/v1/read-order-details-by-id.php?order_id=".$_GET['order_id'];
                    $object = $api->curlQueryGet($url);
                    if($object->status !=200 )  {echo "<div class='col-12 col-md-6'>Order no found</div>";
                    } else {
                    foreach ($object->order as $item) {
                    ?>
                    <div class="border-bottom p-3">
                        <h4 class="m-0">
                            <span><a href="account/orders"><i class="fas fa-arrow-left text-secondary">&nbsp;</i></a></span>Order details
                        </h4>
                    </div>
                    <div class="order_summary border-bottom p-3">
                        <ul class="p-0">
                            <li style="color: #91808D"><span><?= $item->order_qty; ?></span>&nbsp;<span>Items</span></li>
                            <li style="color: #91808D"><span>Placed on&nbsp;<?= date('j F,Y', strtotime($item->order_on)); ?></span></li>
                            <li style="color: #91808D"><span>Total:&nbsp;</span>₦<?= number_format($item->order_amount,0); ?></li>
                        </ul>
                    </div>
                    <div class="p-3">
                        <div><h6>ITEMS IN YOUR ORDER</h6></div>
                        <div class="container-fluid p-0 border">
                            <div class="border-bottom p-2">
                                <b>Order Status : <?= ($item->order_status==='Delivered') ?
                                        "<span class='text-success'>Delivered</span>":
                                        "<span class='text-muted'>".$item->order_status."</span>"; ?>
                                </b>
                            </div>
                            <?php } } ?>
                            <div class="row">
                                <?php
                                $url = CONTROLLER_ROOT_URL."/v1/read-order-by-product_id.php?order_id=".$_GET['order_id'];
                                $object = $api->curlQueryGet($url);
                                if($object->status !=200 )  {echo "<div class='col-12 col-md-6'>Product no found</div>";
                                } else {
                                    foreach ($object->products as $product) {
                                        ?>
                                        <div class="col-12 col-md-6">
                                            <div class="card item_card mb-3">
                                                <div class="row no-gutters">
                                                    <div class="col-4 img_container">
                                                        <img src="admin/adminImg/products/<?= $product->product_img; ?>" class="card-img" alt="item thumbnail">
                                                    </div>
                                                    <div class="col-8">
                                                        <div class="card-body">
                                                            <h6 class="card-title m-0"><?= $product->product_title; ?></h6>
                                                            <p class="card-text m-0">
                                                            <ul class="p-0">
                                                                <li><span>Quantity:</span>&nbsp;<span class="font-weight-bold"><?= $product->product_qty; ?></span></li>
                                                                <li><span>Price:</span>&nbsp;<span>₦&nbsp;</span><span class="font-weight-bold"><?= $product->product_price; ?></span></li>
                                                            </ul>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row no-gutters">
                                                    <div class="col">
                                                        <button data-odi="<?= $product->order_details_id; ?>" class="w-50 text-center remove-order-item rounded py-1 px-5 mx-5">
                                                            <i class="fas fa-undo mr-2"></i>Return
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <hr class="d-block d-md-none" style="color: #434343;width:93%;margin:0 auto;" />
                                    <?php } } ?>
                            </div>
                        </div>
                        <div class="container">
                            <div class="row">
                                <?php
                                $url = CONTROLLER_ROOT_URL."/v1/read-order-payment-details.php?order_id=".$_GET['order_id'];
                                $object = $api->curlQueryGet($url);
                                if($object->status !=200)  {
                                    echo "<div class='col-12 col-md-6 p-0'>Payment no found</div>";} else {
                                    foreach ($object->order_payment as $pay_item) {
                                        ?>
                                        <div class="col-12 col-md-6 p-0">
                                            <div class="card payment_card mr-md-3 my-md-4">
                                                <div class="card-body">
                                                    <h6>PAYMENT INFORMATION</h6>
                                                    <dl>
                                                        <dt>Payment Status: <span class="text-success font-weight-bold">
                                                        <?= ($pay_item->payment_status=="Unverified")?
                                                            "<span class='text-danger'>Pending Confirmation</span>":"Confirmed"; ?>
                                                    </span>
                                                        </dt>
                                                        <dt>Payment Method</dt>
                                                        <dd style="color: #91808D"><?= ($pay_item->payment_option=="DebitCard")? "Third-Party Payment Interface":"Bank Transfer"; ?></dd>
                                                        <dt>Payment Details</dt>
                                                        <dd style="color: #91808D">Items total: ₦ <?= number_format(($pay_item->payment_amount-$pay_item->order_ship_fee),0); ?></dd>
                                                    </dl>
                                                    <p style="color: #91808D">Shipping Fees: ₦ <?= number_format($pay_item->order_ship_fee,0); ?></p>
                                                    <p>Total: ₦ <?= number_format($pay_item->payment_amount,0); ?></p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-6 p-0">
                                            <div class="card delivery_card ml-md-3 my-md-4">
                                                <div class="card-body">
                                                    <h6>DELIVERY INFORMATION</h6>
                                                    <dl>
                                                        <dt>Delivery Method</dt>
                                                        <dd style="color: #91808D">Standard Door Delivery</dd>
                                                        <dt>Shipping Address</dt>
                                                        <dd style="color: #91808D"><?= $pay_item->receiver_full_add; ?> Nigeria.</dd>
                                                    </dl>
                                                    <p style="color: #91808D"><?=$pay_item->receiver_fullname;?></p>
                                                </div>
                                            </div>
                                        </div>
                                    <?php } } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
</div>
<?php include_once("../inc/footer.nav.php"); ?>
<script>
    $(document).ready(function () {
        $("#user_order_details").on("click",".remove-order-item",function (e) {
            e.preventDefault();
            var odi = $(this).data('odi');

            $(".remove-order-item").attr("disabled", true);$('.remove-order-item').css("cursor", 'not-allowed');
            $.confirm({
                type:'dark',title:false,content:'Are you sure you want to return item ?',autoClose:'cancelAction|8000',
                buttons: {
                    confirm: {text: 'Yes, Return',action: function () {
                            $.get("account/order-action-3.php?odi="+parseInt(odi), function () {
                                $.alert("Request sent, our customer support will contact you shortly");
                                // setTimeout(function () {window.location.replace('account/orders');},3500);
                            });
                        }},
                    cancelAction: {text: 'cancel',action: function () {} }
                }
            });
            $(".remove-order-item").attr("disabled", false);$('.remove-order-item').css("cursor", 'pointer');
        });
    });
</script>
