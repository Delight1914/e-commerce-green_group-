<?php

// include headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Content-type: application/json; charset=UTF-8");

include_once('../config/database.php');
include_once('../classes/User.class.php');

//create object for db
$db = new Database();
$connection = $db->connect();
$user = new User($connection);
if ($_SERVER['REQUEST_METHOD'] === "GET") {
    $user->order_id = isset($_GET['order_id']) ? hex2bin($_GET['order_id']) : die();
    $order = $user->order_by_id();
    if ($order->num_rows > 0) {
        $order_arr = array();
        while ($row = $order->fetch_assoc()) {
            $order_arr[] = array(
                "order_id" => $row['order_id'],                
                "customer_id" => $row['customer_id'],
                "order_amount" => $row['order_amount'],
                "order_qty" => $row['order_qty'],
                "receiver_fullname" => $row['receiver_fname']." ".$row['receiver_lname'],
                "order_on" => $row['order_on'],
                "receiver_email" => $row['receiver_email'],
                "order_status" => $row['order_status']
            );
        }
        http_response_code(200);
        echo json_encode(array("status" => 200, "order" => $order_arr,));
    } else {
        http_response_code(404);
        echo json_encode(array("status" => 404, "message" => "No Record Found"));
    }
} else {
    http_response_code(503);
    echo json_encode(array("status" => 503, "message" => "Access Denied"));
}