<?php
// include headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Content-type: application/json; charset=UTF-8");

include_once('../config/database.php');
include_once('../classes/User.class.php');

//create object for db
$db = new Database();
$connection = $db->connect();
$user = new User($connection);

if ($_SERVER['REQUEST_METHOD'] === "POST") {
    $data = json_decode(file_get_contents("php://input"));
    if (!empty($data->password) && !empty($data->confirm_password)) {
        if (trim($data->password) == trim($data->confirm_password)) {
            $user->reset_selector = $data->selector;
            $reset_data = $user->check_reset_pwd_credentials();
            if (!empty($reset_data)){
                $tokenBin = hex2bin($data->validator);
                $tokenCheck = password_verify($tokenBin, $reset_data['reset_token']);
                if ($tokenCheck===false){
                    http_response_code(500);
                    echo json_encode(array("status" => 500, "message" => "You need to submit a reset request"));
                    exit();
                } elseif($tokenCheck===true) {
                    $user->email = $reset_data['reset_email'];
                    $user->check_email();
                    if (!empty($reset_data)){
                        $user->email = $reset_data['reset_email'];
                        $user->password = password_hash($data->password,PASSWORD_DEFAULT);
                        if ($user->update_reset_password()){
                            http_response_code(200);
                            echo json_encode(array("status" => 200, "message" => "Password successfully changed."));
                        } else {
                            http_response_code(400);
                            echo json_encode(array("status" =>400, "message" => "Error while trying to reset your password, contact our admin for help (support@amazonlagos.com)"));
                        }
                    }
                }
            } else {
                http_response_code(404);
                echo json_encode(array("status" => 404, "message" => "Invalid/Expired link, re-submit your reset link"));
            }
        } else {
            http_response_code(404);
            echo json_encode(array("status" => 404, "message" => "Password combination do not match"));
        }
    } else {
        http_response_code(503);
        echo json_encode(array("status" => 500, "message" => "Kindly fill the required field"));
    }
} else {
    http_response_code(503);
    echo json_encode(array("status" => 503, "message" => "Access Denied"));
}