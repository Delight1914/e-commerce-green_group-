<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Content-type: application/json; charset=UTF-8");

include_once('../config/database.php');
include_once('../classes/User.class.php');
include_once('../classes/Product.class.php');

//create object for db
$db = new Database();
$connection = $db->connect();
$user = new User($connection);
$product = new Product($connection);

if ($_SERVER['REQUEST_METHOD'] === "GET") {
    $subCatProd = $product->read_products_subcategories_id($_GET['subcat_id']);
    if ($subCatProd->num_rows > 0) {
        $subCatProd_arr = array();
        while ($row = $subCatProd->fetch_assoc()){
            $subCatProd_arr[] = array(
                "product_id" => $row['product_id'],
                "subcat_id" => $row['subcat_id'],
                "product_title" => $row['product_title'],
                "product_sku" => $row['product_sku'],
                "product_img" => $row['product_img'],
                "product_price" => $row['product_price']
            );
        }
        http_response_code(200);
        echo json_encode(array("status" => 200,"subcategories" => $subCatProd_arr));
    } else {
        http_response_code(404);
        echo json_encode(array("status"=>404,"message"=>"No Record Found"));
    }
} else {
    http_response_code(503);
    echo json_encode(array("status"=>503,"message"=>"Access Denied"));
}