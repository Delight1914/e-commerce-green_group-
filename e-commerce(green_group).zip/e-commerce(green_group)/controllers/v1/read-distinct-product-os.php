<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Content-type: application/json; charset=UTF-8");

include_once('../config/database.php');
include_once('../classes/User.class.php');
include_once('../classes/Product.class.php');

//create object for db
$db = new Database();
$connection = $db->connect();
$user = new User($connection);
$product = new Product($connection);

if ($_SERVER['REQUEST_METHOD'] === "GET") {
    $tvOs = $product->select_distinct_product_os();
    if ($tvOs->num_rows > 0) {
        $tvOs_arr = array();
        while ($row = $tvOs->fetch_assoc()){
            $tvOs_arr[] = array("product_os"=>$row['product_os']);
        }
        http_response_code(200);
        echo json_encode(array("status" => 1,"tv_os" => $tvOs_arr));
    } else {
        http_response_code(404);
        echo json_encode(array("status"=>0,"message"=>"No Record Found"));
    }
} else {
    http_response_code(503);
    echo json_encode(array("status"=>0,"message"=>"Access Denied"));
}