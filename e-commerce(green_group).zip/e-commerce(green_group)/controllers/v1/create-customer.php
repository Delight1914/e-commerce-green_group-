<?php
// include headers
session_start();
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Content-type: application/json; charset=UTF-8");

include_once('../config/database.php');
include_once('../classes/User.class.php');

//create object for db
$db = new Database();
$connection = $db->connect();
$user = new User($connection);

if ($_SERVER['REQUEST_METHOD'] === "POST") {
    $data = json_decode(file_get_contents("php://input"));
    if (!empty($data->firstname) && !empty($data->lastname) && !empty($data->email) && !empty($data->phone) && !empty($data->password)
        && !empty($data->confirm_password)) {

        if ($data->password !== $data->confirm_password){
            http_response_code(500);
            echo json_encode(array("status" => 0, "message" => "Password combination did not match, try again."));
        } else {
            //submit data
            $user->firstname = $data->firstname;
            $user->lastname = $data->lastname;
            $user->email = $data->email;
            $user->phone = $data->phone;
            $user->password = password_hash($data->password, PASSWORD_DEFAULT);
            $email_data = $user->check_email();
            if (!empty($email_data)) {
                http_response_code(500);
                echo json_encode(array("status"=>0,"message" =>"Customer email already exists, try another email address"));
            } else {
                $user->email = $data->email;
                $result = $user->create_user();
                if (!empty($result)) {
                    if (isset($_SESSION['user_login_temp']['oldUrl'])){$location = "checkout";} else {$location= "index";}
                    $account_arr = array("customer_id"=>$result['customer_id'],"firstname"=>$result['firstname'],"lastname"=>$result['lastname'],"email"=>$result['email'],"phone"=>$result['phone']);
                    http_response_code(200);
                    echo json_encode(array(
                        "status" => "200","user_details"=>$account_arr,"message"=>"User can now login to continue shopping","location"=>$location
                    ));
                    $_SESSION['user_login'] = $account_arr;
                } else {
                    http_response_code(500);
                    echo json_encode(array("status"=>0,"message"=>"Failed to save user"));
                }
            }
        }
    } else {
        http_response_code(500);
        echo json_encode(array("status" => 0, "message" => "Kindly fill the required field"));
    }
} else {
    http_response_code(503);
    echo json_encode(array("status" => 0, "message" => "Access Denied"));
}