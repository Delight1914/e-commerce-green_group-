<?php
    session_start();
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Methods: POST");
    header("Content-type: application/json; charset=UTF-8");

    $number = count($_POST["product_name"]);

if ($number > 0) {
    $error=0;
    $_SESSION['shoppingList'] = array();
    for ($i = 1; $i <= $number; $i++) {
        if ($_POST["product_name"][$i]=='' || $_POST["producer"][$i]=='' || $_POST["qty"][$i]=='') {
            $error = $error + 1;
        } else {
            $_SESSION['shoppingList'][$i] = array(
                'product_name' => $_POST["product_name"][$i],
                'producer' => $_POST["producer"][$i],
                'qty' => $_POST["qty"][$i],
                'c_s_o' => $_POST["c_s_o"][$i]
            );
        }
    }

    if ($error <= 29) {
        $status=array_walk_recursive( $_SESSION['shoppingList'], function($v,$k){
            global $output; if( empty( $v ) && $v!==0 )$output[$k]=$v;
        });

        if(empty($output)) http_response_code(200);echo json_encode(array("status"=>200,"message"=>'Data Saved'));
    } else {
        http_response_code(400);echo json_encode(array("status"=>400,"message"=>'You need to shop at least one product'));
    }
} else {
    http_response_code(400);
    echo json_encode(array("status"=>400,"message"=>"No data found"));
}

?>
