<?php
session_start();
// include headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Content-type: application/json; charset=UTF-8");

include_once('../config/database.php');
include_once('../classes/User.class.php');

//create object for db
$db = new Database();
$connection = $db->connect();
$user = new User($connection);

if ($_SERVER['REQUEST_METHOD'] === "POST") {
    $data = json_decode(file_get_contents("php://input"));
    if (!empty($data->firstname) && !empty($data->lastname) && !empty($data->phone) && !empty($data->email)) {
        if (!empty(trim($data->new_password))){
            if (empty(trim($data->repeat_password)) || strlen($data->new_password) < 6) {
                http_response_code(404);
                echo json_encode(array("status" =>404, "message" => "New/Repeat password must be at least six(6) character"));
            } else {
                if (trim($data->new_password) !== trim($data->repeat_password)) {
                    http_response_code(500);
                    echo json_encode(array("status" =>500,"message"=>"New password combination did not match, try again."));
                } else {
                    $user->email = $_SESSION['user_login']['email'];
                    $user_data = $user->login_user();
                    if (password_verify($data->new_password, $user_data['password'])) {
                        http_response_code(500);
                        echo json_encode(array("status" =>500,"message"=>"Password already in use."));
                    } else {
                        $user->firstname = $data->firstname;
                        $user->lastname = $data->lastname;
                        $user->phone = $data->phone;
                        $user->email = $data->email;
                        $user->customer_id = $_SESSION['user_login']['customer_id'];
                        $user->new_password = password_hash($data->new_password, PASSWORD_DEFAULT);
                        if ($user->update_complete_user_profile()){
                            http_response_code(200);
                            echo json_encode(array("status"=>200,"message"=>"Your account has been updated. N.B.Changes will take effect on your next login."));
                        } else {
                            http_response_code(500);
                            echo json_encode(array("status" =>500,"message"=>"Failed to update user, contact admin via the help line or try again 1"));
                        }
                    }
                }
            }
        } else {
            $user->firstname = $data->firstname;
            $user->lastname = $data->lastname;
            $user->phone = $data->phone;
            $user->email = $data->email;
            $user->customer_id = $_SESSION['user_login']['customer_id'];
            if ($user->update_user_profile()){
                http_response_code(200);
                echo json_encode(array("status"=>200,"message"=>"Your account has been updated. N.B. Changes will take effect on your next login."));
            } else {
                http_response_code(400);
                echo json_encode(array("status" => 400, "message" => "No changes on user profile"));
            }
        }

    } else {
        http_response_code(500);
        echo json_encode(array("status" => 500, "message" => "Kindly fill the required field"));
    }
} else {
    http_response_code(503);
    echo json_encode(array("status" => 503, "message" => "Access Denied"));
}