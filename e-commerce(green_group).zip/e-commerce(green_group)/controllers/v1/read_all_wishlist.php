<?php

// include headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Content-type: application/json; charset=UTF-8");

include_once('../config/database.php');
include_once('../classes/User.class.php');

//create object for db
$db = new Database();

//object
$connection = $db->connect();
$user = new User($connection);

if ($_SERVER['REQUEST_METHOD'] === "GET") {
    $user->customer_id = isset($_GET['customer_id']) ? $_GET['customer_id'] : die();
    $wList = $user->read_customer_wish_list_();
    if ($wList->num_rows > 0) {
        $wList_arr = array();
        while ($row = $wList->fetch_assoc()) {
            $wList_arr[] = array(
                "wlist_id" => $row['wlist_id'],
                "product_id" => $row['product_id'],
                "product_title" => $row['product_title'],
                "product_sku" => $row['product_sku'],
                "product_price" => $row['product_price'],
                "product_img" => $row['product_img']
            );
        }
        http_response_code(200);
        echo json_encode(array("status" => 200, "wishlist" => $wList_arr));
    } else {
        http_response_code(404);
        echo json_encode(array("status" => 404, "message" => "No Record Found"));
    }
} else {
    http_response_code(503);
    echo json_encode(array("status" => 503, "message" => "Access Denied"));
}