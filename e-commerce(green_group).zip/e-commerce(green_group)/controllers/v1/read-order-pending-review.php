<?php

// include headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Content-type: application/json; charset=UTF-8");

include_once('../config/database.php');
include_once('../classes/User.class.php');
include_once('../classes/Product.class.php');

//create object for db
$db = new Database();

//object
$connection = $db->connect();
$user = new User($connection);
$product = new Product($connection);

if ($_SERVER['REQUEST_METHOD'] === "GET") {
    // set ID property of record to read
    $user->customer_id = isset($_GET['customer_id']) ? $_GET['customer_id'] : die();

    $pend_review = $user->order_pending_review();
    if ($pend_review->num_rows > 0) {
        $product_arr = array();
        while ($row = $pend_review->fetch_assoc()){
            $product_arr[] = array(
                "order_id" => $row['order_id'],
                "order_details_id" => $row['order_details_id'],
                "product_id" => $row['product_id'],
                "product_qty" => $row['product_qty'],
                "product_title" => $row['product_title'],
                "product_price" => $row['product_price'],
                "product_img" => $row['product_img'],
                "order_on" => $row['order_on'],
                "order_status" => $row['order_status']
            );
        }
        http_response_code(200); //200 means Ok status
        echo json_encode(array("status" => 200, "pendingReview" => $product_arr,));
    } else {
        http_response_code(404);
        echo json_encode(array("status" => 404, "message" => "No Record Found"));
    }
} else {
    http_response_code(503);
    echo json_encode(array("status" => 503, "message" => "Access Denied"));
}