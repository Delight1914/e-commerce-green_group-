<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Content-type: application/json; charset=UTF-8");

include_once('../config/database.php');
include_once('../classes/User.class.php');
include_once('../classes/Product.class.php');

//create object for db
$db = new Database();
$connection = $db->connect();
$user = new User($connection);
$product = new Product($connection);

if ($_SERVER['REQUEST_METHOD'] === "GET") {
    $cat = $product->product_category_by_id($_GET['cat_id']);
    if ($cat->num_rows > 0) {
        $cat_arr = array();
        while ($row = $cat->fetch_assoc()){
            $cat_arr[] = array("cat_id"=>$row['cat_id'],"category_name"=>$row['category_name']);
        }
        http_response_code(200);
        echo json_encode(array("status" => 1,"category" => $cat_arr));
    } else {
        http_response_code(404);
        echo json_encode(array("status"=>0,"message"=>"No Record Found"));
    }
} else {
    http_response_code(503);
    echo json_encode(array("status"=>0,"message"=>"Access Denied"));
}