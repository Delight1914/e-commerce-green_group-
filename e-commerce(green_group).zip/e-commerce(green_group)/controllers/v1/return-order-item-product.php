<?php

header("Content-type: application/json; charset=UTF-8");

include_once('../config/database.php');
include_once('../classes/User.class.php');

//create object for db
$db = new Database();

//object
$connection = $db->connect();
$user = new User($connection);

if ($_SERVER['REQUEST_METHOD'] === "GET") {
    if (!empty($_GET['odi'])) {
        if ($user->update_order_details_return($_GET['odi'])) {
            http_response_code(200);
            echo json_encode(array("status"=>200,"message"=>"Order item flagged as return"));
        }  else {
            http_response_code(500);
            echo json_encode(array("status" => 500, "message" => "Item not flagged"));
        }
    } else {
        http_response_code(500);
        echo json_encode(array("status" => 500, "message" => "Empty order details id"));
    }
} else {
    http_response_code(500);
    echo json_encode(array("status" => 0, "message" => "Access Denied"));
}