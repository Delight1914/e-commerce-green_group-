<?php
ob_start();
session_start();
// include headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Content-type: application/json; charset=UTF-8");

include_once('../config/database.php');
include_once('../classes/Product.class.php');

//create object for db
$db = new Database();
$connection = $db->connect();
$product = new Product($connection);

if ($_SERVER['REQUEST_METHOD'] === "POST") {
    $data = json_decode(file_get_contents("php://input"));
    if (!empty($data->shop_fullname) && !empty($data->shop_email) && !empty($data->shop_phone)) {
        $product->shop_fullname = $data->shop_fullname;
        $product->shop_email = $data->shop_email;
        $product->shop_phone = $data->shop_phone;

        $ShopResp = $product->create_shopping_list();
        if ($ShopResp != false){
            $errCount=0;
                foreach ($_SESSION['shoppingList'] as $key => $value) {
                    if ($product->create_shopping_list_details($ShopResp,$value['product_name'],$value['producer'],$value['qty'],$value['c_s_o'])) $errCount=0;
                    else $errCount= $errCount+1;
                }
                if ($errCount==0) {
                    unset($_SESSION['shoppingList']);
                    $product->send_shoppingList_mail_to_admin($ShopResp);
                    http_response_code(200);
                    echo json_encode(array("status"=>200,"message" =>"Product list submitted successfully, our customer support will contact you shortly"));
                } else {
                    http_response_code(400);
                    echo json_encode(array("status"=>400,"message" => "Cannot complete order"));
                }
        } else {
            http_response_code(500);
            echo json_encode(array("status" =>500,"message"=>"Internal server error, cannot complete order"));
        }
    } else {
        http_response_code(500);
        echo json_encode(array("status"=>500,"message"=>"Fill all require field"));
    }
} else {
    http_response_code(503);
    echo json_encode(array("status"=>0,"message"=>"Access Denied"));
}