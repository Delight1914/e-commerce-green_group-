<?php

// include headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Content-type: application/json; charset=UTF-8");

include_once('../config/database.php');
include_once('../classes/User.class.php');

//create object for db
$db = new Database();

$connection = $db->connect();
$user = new User($connection);

if ($_SERVER['REQUEST_METHOD'] === "GET") {
    $user->order_id = isset($_GET['order_id']) ? hex2bin($_GET['order_id']) : die();
    $products = $user->order_by_product();
    if ($products->num_rows > 0) {
        $products_arr = array();
        while ($row = $products->fetch_assoc()) {
            $products_arr[] = array(
                "order_id" => $row['order_id'],
                "order_details_id" => $row['order_details_id'],
                "product_id" => $row['product_id'],
                "product_img" => $row['product_img'],
                "product_title" => $row['product_title'],
                "product_qty" => $row['product_qty'],
                "product_price" => $row['product_price'],
            );
        }
        http_response_code(200); //200 means Ok status
        echo json_encode(array("status" => 200, "products" => $products_arr,));
    } else {
        http_response_code(404);
        echo json_encode(array("status" => 404, "message" => "No Record Found"));
    }
} else {
    http_response_code(503); //503 means service unavailable
    echo json_encode(array("status" => 503, "message" => "Access Denied"));
}