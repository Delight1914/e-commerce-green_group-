<?php
session_start();
// include headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Content-type: application/json; charset=UTF-8");

include_once('../config/database.php');
include_once('../classes/User.class.php');

//create object for db
$db = new Database();
$connection = $db->connect();
$user = new User($connection);

if ($_SERVER['REQUEST_METHOD'] === "POST") {
    $data = json_decode(file_get_contents("php://input"));
    if (!empty($data->email) && !empty($data->password)){
        $user->email = $data->email;
        $user_data = $user->login_user();
        if (!empty($user_data)){
            $email = $user_data['email'];
            $password = $user_data['password'];

            if (password_verify($data->password,$password)){
                if (isset($_SESSION['user_login_temp']['oldUrl'])){$location = "checkout";}
                else {$location= "index";}
                $account_arr = array(
                    "customer_id"=>$user_data['customer_id'],
                    "firstname"=>$user_data['firstname'],
                    "lastname"=>$user_data['lastname'],
                    "email"=>$user_data['email'],
                    "phone"=>$user_data['phone']
                );
                http_response_code(200);
                echo json_encode(array(
                    "status"=>"200","user_details"=>$account_arr,"message"=>"User logged in successfully","location"=> $location
                ));
                $_SESSION['user_login'] = $account_arr;
            } else {
                http_response_code(404);
                echo json_encode(array("status"=>0,"message"=>"Invalid credentials, password incorrect. Try resetting your password."));
            }
        } else {
            http_response_code(404);
            echo json_encode(array("status"=>0,"message"=>"Invalid credentials, email does not match any record."));
        }
    } else {
        http_response_code(404);
        echo json_encode(array("status"=>0,"message"=>"Kindly fill the required field"));
    }
} else {
    http_response_code(503);
    echo json_encode(array("status"=>0,"message"=>"Access Denied"));
}