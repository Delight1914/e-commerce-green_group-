<?php
ob_start();
session_start();
// include headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Content-type: application/json; charset=UTF-8");

include_once('../config/database.php');
include_once('../classes/User.class.php');
include_once('../classes/Product.class.php');

//create object for db
$db = new Database();
$connection = $db->connect();
$user = new User($connection);
$product = new Product($connection);

if ($_SERVER['REQUEST_METHOD'] === "POST") {
    $data = json_decode(file_get_contents("php://input"));
        if (!empty($data->total_amount) && !empty($data->total_qty)) {
            if (isset($_SESSION['user_login']['customer_id'])) {
                $product->order_ref = 200000+rand(1000,9999);
                $product->customer_id = $_SESSION['user_login']['customer_id'];
                $product->order_amount = $data->total_amount;
                $product->order_ship_fee = $data->order_shipping;
                $product->order_qty = $data->total_qty;
                $product->receiver_fname = $data->firstname;
                $product->receiver_lname = $data->lastname;
                $product->receiver_email = $data->email;
                $product->receiver_phone = $data->phone;
                $product->receiver_address = $data->address;
                $product->receiver_state = $data->state;
                $product->shipping_type = $data->shipping_option;
                $product->payment_option = $data->payment_method;

                $response = $product->create_order();
            if ($response !== false){
                if (!empty($data->payment_ref)) $product->payment_ref = $data->payment_ref;
                else $product->payment_ref = "T".rand(100000000000000,999999999999999);

                if ($data->payment_method==="DebitCard") $product->payment_status = "Paid";
                else $product->payment_status = "Unverified";

                if ($product->create_order_payment()){
                    http_response_code(200);
                    echo json_encode(array("status"=>200,"order_id"=>$response));
                } else {
                    http_response_code(500);
                    echo json_encode(array("status" => "PaymentErr", "message" => "Payment cannot be created, cannot complete order"));
                }
            } else {
                http_response_code(500);
                echo json_encode(array("status" => "ServerErr", "message" => "Internal server error, cannot complete order"));
            }
        } else {
            $_SESSION['user_login_temp']['oldUrl'] = "true";
            http_response_code(500);
            echo json_encode(array("status" => "AuthErr", "message" => "Unauthorized, kindly login to complete order"));
        }
    } else {
        http_response_code(500);
        echo json_encode(array("status" => "CartErr", "message" => "Internal server error, cannot complete order"));
    }
} else {
    http_response_code(503);
    echo json_encode(array("status" => 0, "message" => "Access Denied"));
}