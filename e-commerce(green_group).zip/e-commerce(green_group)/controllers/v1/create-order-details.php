<?php
ob_start();
session_start();
// include headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Content-type: application/json; charset=UTF-8");

include_once('../config/database.php');
include_once('../classes/User.class.php');
include_once('../classes/Product.class.php');

//create object for db
$db = new Database();

//object
$connection = $db->connect();
$user = new User($connection);
$product = new Product($connection);
$errCount=0;
if ($_SERVER['REQUEST_METHOD'] === "POST") {
    $datas = json_decode(file_get_contents("php://input"));
    $product->order_id = $datas[0][0]->order_id;
    $product->customer_id = $_SESSION['user_login']['customer_id'];

    foreach ($datas[1] as $data => $item){
        $product->product_id = $item->id;
        $product->product_qty = $item->qty;
        if ($product->create_order_details()){}
        else {$errCount++;}
    }
} else { $errCount++; }

if ($errCount===0){
    unset($_SESSION['user_login_temp']);
    http_response_code(200);
    echo json_encode(array("status" => "SUCCESS", "message" => "Order successfully completed"));
} else  {
    http_response_code(500);
    echo json_encode(array("status" => "ServerErr", "message" => "Internal server error, cannot complete order"));
}