<?php


class Product
{
    public $cat_id;
    public $subCatId;

    public $product_id;
    public $customer_id;
    public $product_qty;
    public $account_name;
    public $transferred_amount;
    public $review_comment;
    public $review_rate;

    public $order_id;
    public $order_details_id;
    public $order_ref;
    public $payment_ref;
    public $payment_status;
    public $order_amount;
    public $order_qty;
    public $order_ship_fee;
    public $receiver_fname;
    public $receiver_lname;
    public $receiver_email;
    public $receiver_phone;
    public $receiver_address;
    public $receiver_state;
    public $shipping_type;
    public $payment_option;

    public $make_deposit;
    public $shop_type;
    public $shop_fullname;
    public $shop_email;
    public $shop_phone;

    private $conn;
    private $tbl_product;

    //constructor
    public function __construct($db) {
        $this->conn = $db;
        $this->tbl_product = 'tbl_product';
    }

    public function latest_products(){
        $latest_prod_query = "SELECT * FROM tbl_product ORDER BY sno DESC LIMIT 10";
        $latest_prod_obj = $this->conn->prepare($latest_prod_query);
        if ($latest_prod_obj->execute()) {
            return $latest_prod_obj->get_result();
        }
        return array();
    }

    public function best_selling_products(){
        $best_selling_query = "SELECT tbl_order_details.product_id, SUM(tbl_order_details.product_qty),tbl_product.* FROM tbl_order_details
                                INNER JOIN tbl_product ON tbl_order_details.product_id=tbl_product.product_id
                                GROUP BY tbl_order_details.product_id ORDER BY tbl_order_details.product_id DESC LIMIT 4";
        $best_selling_obj = $this->conn->prepare($best_selling_query);
        if ($best_selling_obj->execute()) {
            return $best_selling_obj->get_result();
        }
        return array();
    }
    
    public function laptops_phones_tablets_products(){
        $laps_tabs_query = "SELECT * FROM tbl_product WHERE (subcat_id=6892 OR subcat_id=6585) ORDER BY sno DESC LIMIT 6";
        $laps_tabs_obj = $this->conn->prepare($laps_tabs_query);
        if ($laps_tabs_obj->execute()) {
            return $laps_tabs_obj->get_result();
        }
        return array();
    }

    public function get_product_by_category() {
        $query = "SELECT tbl_product.*,tbl_category.cat_name,tbl_subcategory.subcat_name
                    FROM tbl_product
                    INNER  JOIN tbl_category
                    ON tbl_product.cat_id = tbl_category.cat_id
                    INNER  JOIN tbl_subcategory
                    ON tbl_product.subcat_id=tbl_subcategory.subcat_id
                    WHERE tbl_product.cat_id=?
                    ORDER BY tbl_product.sno DESC";
        $prod_cat_obj = $this->conn->prepare($query);
        $prod_cat_obj->bind_param("i",$this->cat_id);
        if ($prod_cat_obj->execute()) {
            return $prod_cat_obj->get_result();
        }

    }

    public function product_categories(){
        $cat_query = "SELECT * FROM tbl_category";
        $cat_obj = $this->conn->prepare($cat_query);
        if ($cat_obj->execute()) {
            return $cat_obj->get_result();
        }
        return array();
    }

    public function product_subcategory_by_id($subcat_id){
        $subCat_query = "SELECT * FROM tbl_subcategory INNER JOIN tbl_category 
                            ON tbl_subcategory.cat_id=tbl_category.cat_id WHERE tbl_subcategory.subcat_id=$subcat_id";
        $subCat_obj = $this->conn->prepare($subCat_query);
        if ($subCat_obj->execute()) {
            return $subCat_obj->get_result();
        }
        return array();
    }

    public function product_category_by_id($cat_id){
        $cat_query = "SELECT * FROM tbl_category WHERE cat_id=$cat_id";
        $cat_obj = $this->conn->prepare($cat_query);
        if ($cat_obj->execute()) {
            return $cat_obj->get_result();
        }
        return array();
    }

    public function select_product_brand($sid){
        $query = "SELECT DISTINCT tbl_product.brand_id,tbl_brand.* FROM tbl_product 
                    INNER JOIN tbl_brand ON tbl_brand.brand_id=tbl_product.brand_id WHERE subcat_id=$sid";
        $brand_obj = $this->conn->prepare($query);
        if ($brand_obj->execute()) {
            return $brand_obj->get_result();
        }
        return array();
    }

    public function select_product_review(){
        $query = "SELECT DISTINCT * FROM tbl_review";
        $rating_obj = $this->conn->prepare($query);
        if ($rating_obj->execute()) {
            return $rating_obj->get_result();
        }
        return array();
    }

    public function select_distinct_product_size(){
        $query = "SELECT DISTINCT product_size FROM tbl_product WHERE product_size !=''";
        $size_obj = $this->conn->prepare($query);
        if ($size_obj->execute()) {
            return $size_obj->get_result();
        }
        return array();
    }

    public function select_distinct_product_os(){
        $query = "SELECT DISTINCT product_os FROM tbl_product WHERE product_os !=''";
        $os_obj = $this->conn->prepare($query);
        if ($os_obj->execute()) {
            return $os_obj->get_result();
        }
        return array();
    }

    public function product_sub_categories_by_cat_id($cat_id){
        $subCat_query = "SELECT * FROM tbl_subcategory WHERE cat_id=$cat_id";
        $subCat_obj = $this->conn->prepare($subCat_query);
        if ($subCat_obj->execute()) {
            return $subCat_obj->get_result();
        }
        return array();
    }

    public function read_products_subcategories_id($sub_id){
        $subCat_query = "SELECT * FROM tbl_product WHERE subcat_id=$sub_id";
        $subCat_obj = $this->conn->prepare($subCat_query);
        if ($subCat_obj->execute()) {
            return $subCat_obj->get_result();
        }
        return array();
    }

    public function read_products_categories_id($cat_id){
        $cat_query = "SELECT * FROM tbl_product INNER JOIN tbl_subcategory ON tbl_subcategory.subcat_id=tbl_product.subcat_id
                        WHERE tbl_product.cat_id=$cat_id";
        $cat_obj = $this->conn->prepare($cat_query);
        if ($cat_obj->execute()) {
            return $cat_obj->get_result();
        }
        return array();
    }

    public function create_wish_list(){
        $wList_query = "SELECT * FROM tbl_wishlist WHERE customer_id=? AND product_id=?";
        $check_obj = $this->conn->prepare($wList_query);
        $check_obj->bind_param("is",$this->customer_id,$this->product_id);
        if ($check_obj->execute()){
            $result = $check_obj->get_result();
            if ($result->num_rows> 0){return "exist";}
        }

        $query = "INSERT INTO tbl_wishlist SET customer_id=?, product_id=?";
        $inserted_obj = $this->conn->prepare($query);
        $inserted_obj->bind_param("is",$this->customer_id,$this->product_id);
        $inserted_obj->execute();
        if ($inserted_obj->affected_rows > 0){
            return true;
        }
        return false;
    }

    public function fetch_all_wishlist_by_pid($pid){
        $wlist_query = "SELECT * FROM tbl_wishlist WHERE product_id='$pid'";
        $wlist_obj = $this->conn->prepare($wlist_query);
        if ($wlist_obj->execute()) {
            $data=$wlist_obj->get_result();
            if ($data->num_rows> 0) return true;
            else return false;
        }
    }

    public function read_product_details_by_sku($sku){
        $sku_query = "SELECT * FROM tbl_product
                    INNER  JOIN tbl_category
                    ON tbl_product.cat_id = tbl_category.cat_id
                    INNER  JOIN tbl_subcategory
                    ON tbl_product.subcat_id=tbl_subcategory.subcat_id
                    WHERE tbl_product.product_sku='$sku' LIMIT 1";
        $sku_obj = $this->conn->prepare($sku_query);
        if ($sku_obj->execute()) {
            return $sku_obj->get_result();
        }
        return array();
    }

    public function read_related_product($cid,$sku){
        $related_query = "SELECT * FROM tbl_product WHERE cat_id=$cid AND product_sku !='$sku' LIMIT 15";
        $related_obj = $this->conn->prepare($related_query);
        if ($related_obj->execute()) {
            return $related_obj->get_result();
        }
        return array();
    }

    public function create_order(){
        $query = "INSERT INTO tbl_order SET order_ref=?,customer_id=?,order_amount=?,order_qty=?,order_ship_fee=?,receiver_fname=?,receiver_lname=?,
                                receiver_email=?,receiver_phone=?,receiver_address=?,receiver_state=?,shipping_type=?,payment_option=?";
        $inserted_obj = $this->conn->prepare($query);
        $inserted_obj->bind_param(
            "sididssssssss",
            $this->order_ref,$this->customer_id,$this->order_amount,$this->order_qty,$this->order_ship_fee,$this->receiver_fname,$this->receiver_lname,
            $this->receiver_email,$this->receiver_phone,$this->receiver_address, $this->receiver_state,$this->shipping_type, $this->payment_option);
        $inserted_obj->execute();
        if ($inserted_obj->affected_rows > 0){
            $this->order_id = mysqli_insert_id($this->conn);
            return $this->order_id;
        }
        return false;
    }

    public function create_order_payment(){
        $query = "INSERT INTO tbl_payment SET order_id=?,payment_amount=?,payment_ref=?,payment_status=?";
        $inserted_obj = $this->conn->prepare($query);
        $inserted_obj->bind_param("idss",$this->order_id,$this->order_amount,$this->payment_ref,$this->payment_status);
        $inserted_obj->execute();
        if ($inserted_obj->affected_rows > 0){
            $id = mysqli_insert_id($this->conn);
            $this->send_order_mail_to_admin($id);
            return true;
        }
        return false;
    }

    public function create_order_details(){
        $query = "INSERT INTO tbl_order_details SET order_id=?,customer_id=?,product_id=?,product_qty=?";
        $inserted_obj = $this->conn->prepare($query);
        $inserted_obj->bind_param("iisi",$this->order_id,$this->customer_id,$this->product_id,$this->product_qty);
        $inserted_obj->execute();
        if ($inserted_obj->affected_rows > 0){
            return true;
        }
        return false;
    }

    public function create_transfer_request(){
        $query = "INSERT INTO tbl_transfer_payment SET order_id=?,account_name=?,transferred_amount=?";
        $inserted_obj = $this->conn->prepare($query);
        $inserted_obj->bind_param("isd",$this->order_id,$this->account_name,$this->transferred_amount);
        $inserted_obj->execute();
        if ($inserted_obj->affected_rows > 0){
            return true;
        }
        return false;
    }

    public function create_review_rating(){
        $query = "INSERT INTO tbl_review SET customer_id=?,product_id=?,review_comment=?,review_rate=?";
        $inserted_obj = $this->conn->prepare($query);
        $inserted_obj->bind_param("issi",$this->customer_id,$this->product_id,$this->review_comment,$this->review_rate);
        $inserted_obj->execute();
        if ($inserted_obj->affected_rows > 0){
            $q=mysqli_query($this->conn,"UPDATE tbl_order_details SET review_status=1 WHERE order_details_id='$this->order_details_id'");
            if($q) return true;
            else return false;
        }
        return false;
    }

    public function read_average_review_rating($pid){
        $query = "SELECT ROUND(AVG(review_rate), 0) AS AverageRate FROM tbl_review WHERE product_id='$pid'";
        $row = mysqli_fetch_assoc(mysqli_query($this->conn,$query));
        if ($row['AverageRate']>0) return $row['AverageRate'];
        else return 0;
    }

    public function read_product_review_by_id($pid){
        $review_query = "SELECT * FROM tbl_review INNER  JOIN tbl_customer ON tbl_customer.customer_id = tbl_review.customer_id
                        WHERE tbl_review.product_id='$pid' ORDER BY tbl_review.review_id DESC LIMIT 2";
        $review_obj = $this->conn->prepare($review_query);
        if ($review_obj->execute()) {
            return $review_obj->get_result();
        }
        return array();
    }

    public function count_customer_by_review_rate($val){
        $cnt = mysqli_num_rows(mysqli_query($this->conn, "SELECT * FROM tbl_review WHERE review_rate=$val"));
        if ($cnt > 0) return $cnt;
        return 0;
    }

    public function create_shopping_list() {
        $transaction_id = 500000000+rand(10000000,99999999);
        $query = "INSERT INTO tbl_shopping_list SET shopping_list_id=?,shop_fullname=?,shop_email=?,shop_phone=?";
        $inserted_obj = $this->conn->prepare($query);
        $inserted_obj->bind_param("ssss",$transaction_id,$this->shop_fullname,$this->shop_email,$this->shop_phone);
        $inserted_obj->execute();
        if ($inserted_obj->affected_rows > 0){
            return mysqli_insert_id($this->conn);
        }
        return false;
    }

    public function create_shopping_list_payment($shopping_list_id,$shop_amount,$shop_reference,$shop_pay_method,$shop_account_name) {
        $query = "INSERT INTO tbl_shopping_list_payment SET shopping_list_id=$shopping_list_id,shop_amount='$shop_amount',
                            shop_reference='$shop_reference',shop_pay_method='$shop_pay_method',shop_account_name='$shop_account_name' ";
        $inserted_obj = $this->conn->prepare($query);
        $inserted_obj->execute();
        if ($inserted_obj->affected_rows > 0){
            return true;
        }
        return false;
    }

    public function create_shopping_list_details($shopping_list_id,$shop_product_name,$shop_producer,$shop_qty,$shop_cso) {
        $query = "INSERT INTO tbl_shopping_list_details SET shopping_list_id=$shopping_list_id,shop_product_name='$shop_product_name',
                            shop_producer='$shop_producer',shop_qty=$shop_qty,shop_cos='$shop_cso'";
        $inserted_obj = $this->conn->prepare($query);
        $inserted_obj->execute();
        if ($inserted_obj->affected_rows > 0){
            return true;
        }
        return false;
    }

    public function send_order_mail_to_admin($id){
        $email_query = "SELECT * FROM tbl_payment 
                        INNER JOIN tbl_order ON tbl_order.order_id=tbl_payment.order_id 
                        INNER JOIN tbl_customer ON tbl_order.customer_id=tbl_customer.customer_id
                        WHERE tbl_payment.payment_id=$id";
        $user_obj = $this->conn->prepare($email_query);
        if ($user_obj->execute()){
            $res = $user_obj->get_result();
            $data= $res->fetch_assoc();
            $toEmail = 'amazonlagos20@gmail.com';
            $link="https://$_SERVER[HTTP_HOST]";
            $subject = "AmazonLagos New Order Alert!";
            $name = $data['fullname'];
            $content = "<html>
                        <head>
                            <meta http-equiv='Content-Type' content='text/html; charset=utf-8'>
                            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
                            <title>AMAZONLAGOS</title>
                            <style>
                                @import url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;0,500;0,700;0,900;1,300&display=swap');
                                body {font-family: 'Roboto', sans-serif;font-weight: 400}
                                .wrapper {max-width: 600px;margin: 0 auto}
                                .company-name {text-align: left}
                                table {width: 80%;}
                            </style>
                        </head>
                        <body>
                        <div class='wrapper'>
                            <table>
                                <thead>
                                    <tr><th class='table-head' colspan='4'><h1 class='company-name'>AmazonLagos</h1></th></tr>
                                </thead>
                                <tbody>
                                    <div class='mt-3'>
                                        <p>Hi, Admin</p>
                                        <p>New order just came in from ".$name.". Kindly login to admin dashboard to see order details. Thank You</p>
                                        <p>Follow this link to the admin dashboard <a href='".$link."/admin'>".$link."/admin</a></p>
                                    </div>
                                </tbody>
                            </table>
                        </div>
                        </body>
                        </html>";
            $mailHeaders ="MIME-Version: 1.0"."\r\n";
            $mailHeaders .="Content-type:text/html;charset=UTF-8"."\r\n";
            $mailHeaders .= "From: AMAZONLAGOS <amazonlagos20@gmail.com>\r\n";
            if (mail($toEmail, $subject, $content, $mailHeaders)) {
                return true;
            }
            return false;
        }
        return false;
    }

    public function send_shoppingList_mail_to_admin($id){
        $email_query = "SELECT * FROM tbl_shopping_list WHERE sno=$id";
        $user_obj = $this->conn->prepare($email_query);
        if ($user_obj->execute()){
            $data = $user_obj->get_result()->fetch_assoc();
            $toEmail = 'amazonlagos20@gmail.com';
            $link="https://$_SERVER[HTTP_HOST]";
            $subject = "AmazonLagos New Shopping List Alert!";
            $name = $data['shop_fullname'];
            $shop_email = $data['shop_email'];
            $content = "<html>
                        <head>
                            <meta http-equiv='Content-Type' content='text/html; charset=utf-8'>
                            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
                            <title>AMAZONLAGOS</title>
                            <style>
                                @import url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;0,500;0,700;0,900;1,300&display=swap');
                                body {font-family: 'Roboto', sans-serif;font-weight: 400}
                                .wrapper {max-width: 600px;margin: 0 auto}
                                .company-name {text-align: left}
                                table {width: 80%;}
                            </style>
                        </head>
                        <body>
                        <div class='wrapper'>
                            <table>
                                <thead>
                                    <tr><th class='table-head' colspan='4'><h1 class='company-name'>AmazonLagos</h1></th></tr>
                                </thead>
                                <tbody>
                                    <div class='mt-3'>
                                        <p>Hi, Admin</p>
                                        <p>
                                        New Shopping List Alert! just came in from ".$shop_email."(".$name.")"." 
                                        Kindly login to admin dashboard to see details. Thank You</p>
                                        <p>Follow this link to the admin dashboard <a href='".$link."/admin'>".$link."/admin</a></p>
                                    </div>
                                </tbody>
                            </table>
                        </div>
                        </body>
                        </html>";
            $mailHeaders ="MIME-Version: 1.0"."\r\n";
            $mailHeaders .="Content-type:text/html;charset=UTF-8"."\r\n";
            $mailHeaders .= "From: AMAZONLAGOS <amazonlagos20@gmail.com>\r\n";
            if (mail($toEmail, $subject, $content, $mailHeaders)) {
                return true;
            }
            return false;
        }
        return false;
    }

}

?>