<?php
$filepath = realpath(dirname(__FILE__));
include_once ($filepath.'/../config/database.php');
include_once ('GlobalApi.class.php');


class Admin {
    private $conn;
    public $gloApi;

    private $tbl_products;
    private $tbl_admin;

    //constructor
    public function __construct() {
        $db = new Database();
        $this->gloApi = new GlobalApi();
        $this->conn = $db->connect();
        $this->tbl_admin = "tbl_admin";
    }

    public function admin_login($a_email,$a_pwd){
        $admin_query = "SELECT * FROM ".$this->tbl_admin." WHERE email='$a_email'";
        $admin_obj = $this->conn->prepare($admin_query);
        if ($admin_obj->execute()){
            $data = $admin_obj->get_result()->fetch_assoc();
            if (password_verify($a_pwd,$data['password'])){
                return $data;
            } else {
                return array();
            }
        }
        return array();
    }

    public function create_admin_user($a_username,$a_email,$role,$a_password){
        $admin_query = "SELECT * FROM ".$this->tbl_admin." WHERE email='$a_email'";
        $admin_obj = $this->conn->prepare($admin_query);
        if ($admin_obj->execute()){
            $data = $admin_obj->get_result()->num_rows;
            if ($data > 0){
                return false;
            } else {
                $pass = password_hash($a_password, PASSWORD_DEFAULT);
                $admin_query = "INSERT INTO ".$this->tbl_admin." SET username='$a_username', email='$a_email',role='$role',password='$pass'";
                $admin_obj = $this->conn->prepare($admin_query);
                if ($admin_obj->execute()){
                    return true;
                }
                return false;
            }
        }
        return false;
    }

    public function list_admin_users(){
        $adm_query = "SELECT * FROM tbl_admin";
        $adm_obj = $this->conn->prepare($adm_query);
        if ($adm_obj->execute()) {
            return $adm_obj->get_result();
        }
        return array();
    }

    public function list_customers(){
        $user_query = "SELECT * FROM tbl_customer";
        $user_obj = $this->conn->prepare($user_query);
        if ($user_obj->execute()) {
            return $user_obj->get_result();
        }
        return array();
    }

    public function delete_admin_user($adm_id){
        $del_query = "DELETE FROM tbl_admin WHERE admin_id=$adm_id";
        $del_obj = $this->conn->prepare($del_query);
        if ($del_obj->execute()){
            if ($del_obj->affected_rows > 0){ return true; }
            return false;
        }
        return false;
    }

    public function update_admin_user($user,$email,$role,$admin_id){
        $product_query = "UPDATE tbl_admin SET username='$user',email='$email',role='$role' WHERE admin_id=$admin_id";
        $product_obj = $this->conn->prepare($product_query);
        if ($product_obj->execute()){
            if ($product_obj->affected_rows > 0){
                return true;
            }
            return false;
        }
        return false;
    }

    public function add_category_product($cat_name){
        $cat_query = "SELECT * FROM tbl_category WHERE category_name='$cat_name'";
        $cat_obj = $this->conn->prepare($cat_query);
        if ($cat_obj->execute()){
            $data = $cat_obj->get_result()->num_rows;
            if ($data > 0){
                return false;
            } else {
                $cat_id= 4000+rand(100,999);
                $admin_query = "INSERT INTO tbl_category SET cat_id=$cat_id, category_name='$cat_name'";
                $admin_obj = $this->conn->prepare($admin_query);
                if ($admin_obj->execute()){
                    return true;
                }
                return false;
            }
        }
        return false;
    }

    public function list_product_category(){
        $cat_query = "SELECT * FROM tbl_category";
        $cat_obj = $this->conn->prepare($cat_query);
        if ($cat_obj->execute()) {
            return $cat_obj->get_result();
        }
        return array();
    }

    public function count_subcat_by_cat_id($cat_id){
        $cnt = mysqli_num_rows(mysqli_query($this->conn, "SELECT * FROM tbl_subcategory WHERE cat_id='$cat_id'"));
        if ($cnt > 0) return $cnt;
        return 0;
    }

    public function delete_category_product($cat_id){
        $del_query = "DELETE FROM tbl_category WHERE cat_id=$cat_id";
        $del_obj = $this->conn->prepare($del_query);
        if ($del_obj->execute()){
            if ($del_obj->affected_rows > 0){ return true; }
            return false;
        }
        return false;
    }

    public function update_category_product($cat_id,$cat_name){
        $product_query = "UPDATE tbl_category SET category_name='$cat_name' WHERE cat_id=$cat_id";
        $product_obj = $this->conn->prepare($product_query);
        if ($product_obj->execute()){
            if ($product_obj->affected_rows > 0){
                return true;
            }
            return false;
        }
        return false;
    }

    public function add_product_brand($brand_name,$brand_img){
        $brand_query = "SELECT * FROM tbl_brand WHERE brand_name='$brand_name'";
        $brand_obj = $this->conn->prepare($brand_query);
        if ($brand_obj->execute()){
            $data = $brand_obj->get_result()->num_rows;
            if ($data > 0){
                return false;
            } else {
                $brand_id= 5000+rand(100,999);
                $admin_query = "INSERT INTO tbl_brand SET brand_id=$brand_id,brand_name='$brand_name',brand_logo='$brand_img'";
                $admin_obj = $this->conn->prepare($admin_query);
                if ($admin_obj->execute()){
                    return true;
                }
                return false;
            }
        }
        return false;
    }

    public function list_product_brand(){
        $brand_query = "SELECT * FROM tbl_brand";
        $brand_obj = $this->conn->prepare($brand_query);
        if ($brand_obj->execute()) {
            return $brand_obj->get_result();
        }
        return array();
    }

    public function delete_product_brand($brand_id){
        $query = "SELECT * FROM tbl_brand WHERE brand_id=$brand_id";
        $req_obj = $this->conn->prepare($query);
        if ($req_obj->execute()){
            $res = $req_obj->get_result()->fetch_assoc();
            $delLink = 'adminImg/brands/'.$res['brand_logo'];
            unlink($delLink);
        }

        $del_query = "DELETE FROM tbl_brand WHERE brand_id=$brand_id";
        $del_obj = $this->conn->prepare($del_query);
        if ($del_obj->execute()){
            if ($del_obj->affected_rows > 0){ return true; }
            return false;
        }
        return false;
    }

    public function update_product_brand($brand_id,$brand_name){
        $product_query = "UPDATE tbl_brand SET brand_name='$brand_name' WHERE brand_id=$brand_id";
        $product_obj = $this->conn->prepare($product_query);
        if ($product_obj->execute()){
            if ($product_obj->affected_rows > 0){
                return true;
            }
            return false;
        }
        return false;
    }

    public function add_product_subcategory($subcat_name,$cat_id){
        $sub_query = "SELECT * FROM tbl_subcategory WHERE subcat_name='$subcat_name' AND cat_id=$cat_id";
        $sub_obj = $this->conn->prepare($sub_query);
        if ($sub_obj->execute()){
            $data = $sub_obj->get_result()->num_rows;
            if ($data > 0){
                return false;
            } else {
                $subCat_id= 6000+rand(100,999);
                $subCat_query = "INSERT INTO tbl_subcategory SET subcat_id=$subCat_id,subcat_name='$subcat_name',cat_id=$cat_id";
                $subCat_obj = $this->conn->prepare($subCat_query);
                if ($subCat_obj->execute()){
                    return true;
                }
                return false;
            }
        }
        return false;
    }

    public function list_product_subcategory(){
        $brand_query = "SELECT * FROM tbl_subcategory INNER JOIN tbl_category ON tbl_category.cat_id=tbl_subcategory.cat_id";
        $brand_obj = $this->conn->prepare($brand_query);
        if ($brand_obj->execute()) {
            return $brand_obj->get_result();
        }
        return array();
    }

    public function get_subcategory_by_cat_id($cat_id){
        $cubcat_query = "SELECT * FROM tbl_subcategory WHERE cat_id=$cat_id";
        $cubcat_obj = $this->conn->prepare($cubcat_query);
        if ($cubcat_obj->execute()) {
            return $cubcat_obj->get_result();
        }
        return array();
    }

    public function delete_subcategory_product($subcat_id){
        $del_query = "DELETE FROM tbl_subcategory WHERE subcat_id=$subcat_id";
        $del_obj = $this->conn->prepare($del_query);
        if ($del_obj->execute()){
            if ($del_obj->affected_rows > 0){ return true; }
            return false;
        }
        return false;
    }

    public function update_product_subcategory($subcat_id,$subcat_name,$cat_id){
        $product_query = "UPDATE tbl_subcategory SET subcat_name='$subcat_name',cat_id=$cat_id WHERE subcat_id=$subcat_id";
        $product_obj = $this->conn->prepare($product_query);
        if ($product_obj->execute()){
            if ($product_obj->affected_rows > 0){
                return true;
            }
            return false;
        }
        return false;
    }

    public function create_coupon_code($c_title,$c_discount,$c_status){
        $coupon_query = "SELECT * FROM tbl_coupon WHERE coupon_title='$c_title' AND coupon_status='Active'";
        $coupon_obj = $this->conn->prepare($coupon_query);
        if ($coupon_obj->execute()){
            $data = $coupon_obj->get_result()->num_rows;
            if ($data > 0){
                return false;
            } else {
                $code = $this->generate_coupon(11);
                $admin_query = "INSERT INTO tbl_coupon SET coupon_title='$c_title',coupon_code='$code',coupon_discount=$c_discount,coupon_status='$c_status'";
                $admin_obj = $this->conn->prepare($admin_query);
                if ($admin_obj->execute()){
                    return true;
                }
                return false;
            }
        }
        return false;
    }

    public function generate_coupon($l){
        return "AL".substr(str_shuffle(str_repeat('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ',$l-2)),0,$l-2);
    }

    public function list_coupon_code(){
        $coupon_query = "SELECT * FROM tbl_coupon";
        $coupon_obj = $this->conn->prepare($coupon_query);
        if ($coupon_obj->execute()) {
            return $coupon_obj->get_result();
        }
        return array();
    }

    public function delete_coupon_code($coupon_id){
        $del_query = "DELETE FROM tbl_coupon WHERE coupon_id=$coupon_id";
        $del_obj = $this->conn->prepare($del_query);
        if ($del_obj->execute()){
            if ($del_obj->affected_rows > 0){ return true; }
            return false;
        }
        return false;
    }

    public function create_product($a,$b,$c,$d,$b_id,$e,$f,$g,$h,$i,$j,$imgUrl){
        $prod_query = "SELECT * FROM tbl_product WHERE product_sku='".$b."'";
        $prod_obj = $this->conn->prepare($prod_query);
        if ($prod_obj->execute()){
            $data = $prod_obj->get_result()->num_rows;
            if ($data > 0){
                return false;
            } else {
                $prod_id= 6000000000+rand(10000000,99999999);

                $admin_query = "INSERT INTO tbl_product SET product_id=?,product_title=?,product_sku=?,cat_id=?,subcat_id=?,brand_id=?,product_img=?,
                                    product_price=?,product_size=?,product_os=?,overview=?,description=?,warranty=?";
                $admin_obj = $this->conn->prepare($admin_query);
                $admin_obj->bind_param("sssiiisdsssss",$prod_id,$a,$b, $c,$d,$b_id,$imgUrl,$e,$f,$g,$h,$i,$j);
                if ($admin_obj->execute()){
                    return true;
                }
                return false;
            }
        }
        return false;
    }

    public function list_products(){
        $prod_query = "SELECT * FROM tbl_product 
                        INNER JOIN tbl_subcategory ON tbl_subcategory.subcat_id=tbl_product.subcat_id
                        INNER JOIN tbl_category ON tbl_category.cat_id=tbl_product.cat_id
                        LEFT JOIN tbl_brand ON tbl_brand.brand_id=tbl_product.brand_id";
        $prod_obj = $this->conn->prepare($prod_query);
        if ($prod_obj->execute()) {
            return $prod_obj->get_result();
        }
        return array();
    }

    public function delete_product($product_id){
        $del_query = "DELETE FROM tbl_product WHERE product_id='$product_id'";
        $del_obj = $this->conn->prepare($del_query);
        if ($del_obj->execute()){
            if ($del_obj->affected_rows > 0){ return true; }
            return false;
        }
        return false;
    }

    public function get_product_by_id($productId){
        $prod_query = "SELECT * FROM tbl_product INNER JOIN tbl_subcategory ON tbl_subcategory.subcat_id= tbl_product.subcat_id
                        WHERE tbl_product.product_id='$productId'";
        $prod_obj = $this->conn->prepare($prod_query);
        if ($prod_obj->execute()) {
            return $prod_obj->get_result();
        }
        return array();
    }

    public function update_product($a,$b,$c,$d,$b_id,$e,$f,$g,$h,$i,$j,$p_id){
        $i=mysqli_real_escape_string($this->conn,$i);
        $product_query = "UPDATE tbl_product SET product_title='$a',product_sku='$b',cat_id=$c,subcat_id=$d,brand_id=$b_id,product_price='$e',
                                 product_size='$f',product_os='$g',overview='$h',description='$i',warranty='$j' WHERE product_id='$p_id'";
        $product_obj = $this->conn->prepare($product_query);
        if ($product_obj->execute()){
            if ($product_obj->affected_rows > 0){
                return true;
            }
            return false;
        }
        return false;
    }

    public function list_news_subscribers(){
        $news_query = "SELECT * FROM tbl_newsletter";
        $news_obj = $this->conn->prepare($news_query);
        if ($news_obj->execute()) {
            return $news_obj->get_result();
        }
        return array();
    }

    public function send_rating_review_link($order_id){
        $url = "https://amazonlagos.com/controllers/v1/read-order-details-by-id.php?order_id=".bin2hex($order_id);
        $object = $this->gloApi->curlQueryGet($url);
        $productData = "";
        $n=0;
        foreach ($object->order as $item) {
            $toEmail= $item->receiver_email;
            $toName= $item->receiver_fullname;
            $orderId= $item->order_id;
            $url2 = "https://amazonlagos.com/controllers/v1/read-order-by-product_id.php?order_id=".bin2hex($orderId);
            $object2 = $this->gloApi->curlQueryGet($url2);

            foreach ($object2->products as $prodItem) {
                if ($n%2 == 0) $productData.="<tr>";
                $productData.= "<td>
                        <div class='item_card'>
                            <div class='img_wrapper'><img src=https://amazonlagos.com/admin/adminImg/products/".$prodItem->product_img."' alt=''></div>
                            <div class='card_text'>
                                <p>".$prodItem->product_title."<br><strong><span>Qty:</span>&nbsp;<span>".$prodItem->product_qty."</span></strong></p>
                                <a href='https://amazonlagos.com/account/review/".$prodItem->order_details_id."/".$prodItem->product_id."' class='rating_link'>
                                    <div>
                                        <label>Rate it&nbsp;&nbsp;</label><img src='https://amazonlagos.com/images/star.png' class='pl pr' alt=''>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </td>";
                if ($n%2 == 0) $productData.="</tr>";
                ++$n;
            }
        }

        $link="https://$_SERVER[HTTP_HOST]";
        $subject = "Amazon Lagos Product Feedback";
        $content = "<html>
                    <head>
                        <meta http-equiv='Content-Type' content='text/html; charset=utf-8'>
                        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
                        <title>AMAZONLAGOS</title>
                        <style>
                            @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;500;700;900&display=swap');
                            * {box-sizing: border-box;}
                            body {font-family: 'Roboto', sans-serif;margin: 0;padding: 0;font-size: 14px;line-height: 20px;}
                            .brand_logo{width: 120px;}
                            .brand_logo img{width: 100%;}
                            h2 {margin: 0;}
                            .wrapper {max-width: 600px;margin: 0 auto;line-height: 30px;}
                            th {background-color: #c3df34;color: #ffffff;padding: .8em .7em;}
                            .brand_logo {text-align: left;}
                            .company_name {font-weight: bolder;font-size: 1.3rem;}
                            .item_card {display: flex;align-items: center;border: 1px solid #ccc;padding: .4em;}
                            .item_card .img_wrapper {flex-basis: 30%;}
                            .item_card .img_wrapper img {width: 100%;}
                            .item_card .card_text {flex-basis: 70%;line-height: 19px;}
                            .item_card .card_text p {margin: 0;font-size: 12px;line-height: 18px;}
                            .item_card .card_text .rating_link .fa-star {color: #ffbf43;}
                            .item_card .card_text .rating_link>div {background-color: #202020;display: inline-block;font-size: .8rem;padding: .3em;}
                            .item_card .card_text .rating_link>div label {color: #ffffff;}
                            @media(min-width: 700px) {  body {font-size: 15px;}  }
                        </style>
                    </head>
                    <body>
                        <div class='wrapper'>
                        <table>
                            <thead>
                                <tr><th colspan='2'><h2 class='brand_logo'>
                                <img src='https://amazonlagos.com/images/brandlogo_white.png' alt='' />
                                </h2></th></tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan='2'>
                                        <p>Dear <strong>".$toName."</strong>,<br />
                                            Thank you for stopping by Amazon Lagos.<br />
                                            Please help us improve our service and give all customers a better understanding about the
                                            product(s) you ordered!</p>
                                    </td>
                                </tr>
                                ".$productData."
                                <tr>
                                    <td>
                                        <p>Happy Shopping!<br>Best Regards,</p>
                                        <p>AL Team</p>
                                        <div class='brand_logo'><img src='https://amazonlagos.com/images/amazon_brand_logo.png' alt=''></div>
                                        <p><strong>Got any questions?</strong><br>Get in touch wit us via email or call 01 888 1100 / 0700 600 0000</p>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    </body>
                    </html>";
        $mailHeaders ="MIME-Version: 1.0"."\r\n";
        $mailHeaders .="Content-type:text/html;charset=UTF-8"."\r\n";
        $mailHeaders .= "From: AmazonLagos <support@amazonlagos.com>\r\n";
        if (mail($toEmail, $subject, $content, $mailHeaders)) {
            return true;
        }
        return false;
    }

    public function count_customer(){
        $cnt = mysqli_num_rows(mysqli_query($this->conn, "SELECT * FROM tbl_customer"));
        if ($cnt > 0) return $cnt;
        return 0;
    }

    public function count_all_product(){
        $cnt = mysqli_num_rows(mysqli_query($this->conn, "SELECT * FROM tbl_product"));
        if ($cnt > 0) return $cnt;
        return 0;
    }

    public function count_all_order(){
        $cnt = mysqli_num_rows(mysqli_query($this->conn, "SELECT * FROM tbl_order"));
        if ($cnt > 0) return $cnt;
        return 0;
    }

    public function today_booking_amt(){
        $amt_query = "SELECT SUM(order_amount) as myAmt FROM tbl_order WHERE order_on > DATE_SUB(NOW(), INTERVAL 1 DAY)";
        $amt_obj = $this->conn->prepare($amt_query);
        if ($amt_obj->execute()) {
            $data= $amt_obj->get_result()->fetch_assoc();
            return $data['myAmt'];
        }
        return array();
    }

    public function month_booking_amt(){
        $amt_query = "SELECT SUM(order_amount) as myAmt FROM tbl_order WHERE order_on > DATE_SUB(NOW(), INTERVAL 1 MONTH)";
        $amt_obj = $this->conn->prepare($amt_query);
        if ($amt_obj->execute()) {
            $data= $amt_obj->get_result()->fetch_assoc();
            return $data['myAmt'];
        }
        return array();
    }

    public function total_booking_amt(){
        $amt_query = "SELECT SUM(order_amount) as myAmt FROM tbl_order ";
        $amt_obj = $this->conn->prepare($amt_query);
        if ($amt_obj->execute()) {
            $data= $amt_obj->get_result()->fetch_assoc();
            return $data['myAmt'];
        }
        return array();
    }

    public function best_selling_product_amount(){
        $amt_query = "SELECT product_id, SUM(product_qty) AS TotalQty FROM tbl_order_details
                        GROUP BY product_id ORDER BY SUM(product_qty) DESC LIMIT 5";
        $amt_obj = $this->conn->prepare($amt_query);
        if ($amt_obj->execute()) {
            $data= $amt_obj->get_result()->fetch_assoc();
            return $data['TotalQty'];
        }
        return array();
    }

    public function list_best_selling(){
        $prod_query= "SELECT tbl_product.*, tbl_order_details.product_id, SUM(tbl_order_details.product_qty) AS TotalQty FROM tbl_order_details 
                        INNER JOIN tbl_product ON tbl_product.product_id=tbl_order_details.product_id
                        GROUP BY tbl_order_details.product_id ORDER BY SUM(tbl_order_details.product_qty) DESC LIMIT 6";
        $prod_obj = $this->conn->prepare($prod_query);
        if ($prod_obj->execute()) {
            return $prod_obj->get_result();
        }
        return array();
    }

    public function pending_transfer_request(){
        $amt_query = "SELECT SUM(transferred_amount) as myAmt FROM tbl_transfer_payment WHERE transferred_status=0";
        $amt_obj = $this->conn->prepare($amt_query);
        if ($amt_obj->execute()) {
            $data= $amt_obj->get_result()->fetch_assoc();
            return $data['myAmt'];
        }
        return array();
    }

    public function list_latest_five_orders(){
        $order_query = "SELECT * FROM tbl_order";
        $order_obj = $this->conn->prepare($order_query);
        if ($order_obj->execute()) {
            return $order_obj->get_result();
        }
        return array();
    }

    public function list_orders(){
        $order_query = "SELECT * FROM tbl_order INNER JOIN tbl_payment ON tbl_payment.order_id=tbl_order.order_id
                        INNER JOIN tbl_customer ON tbl_customer.customer_id=tbl_order.customer_id";
        $order_obj = $this->conn->prepare($order_query);
        if ($order_obj->execute()) {
            return $order_obj->get_result();
        }
        return array();
    }

    public function list_ordered_items($order_id){
        $order_query = "SELECT * FROM tbl_order_details INNER JOIN tbl_product 
                        ON tbl_product.product_id=tbl_order_details.product_id WHERE tbl_order_details.order_id=$order_id";
        $order_obj = $this->conn->prepare($order_query);
        if ($order_obj->execute()) {
            return $order_obj->get_result();
        }
        return array();
    }

    public function list_ordered_details_items($order_id){
        $order_query = "SELECT * FROM tbl_order_details INNER JOIN tbl_product 
                        ON tbl_product.product_id=tbl_order_details.product_id WHERE tbl_order_details.order_details_id=$order_id";
        $order_obj = $this->conn->prepare($order_query);
        if ($order_obj->execute()) {
            return $order_obj->get_result();
        }
        return array();
    }

    public function update_order_status($order_id){
        $order_query = "UPDATE tbl_order SET order_status='Delivered' WHERE order_id='$order_id'";
        $order_obj = $this->conn->prepare($order_query);
        if ($order_obj->execute()) {
            $this->send_rating_review_link($order_id);
            return true;
        }
        return false;
    }

    public function update_vendor_due_payment_status($odi){
        $ven_query = "UPDATE tbl_order_details SET vendor_pay_status='Yes' WHERE order_details_id=$odi";
        $ven_obj = $this->conn->prepare($ven_query);
        if ($ven_obj->execute()) {
            return true;
        }
        return false;
    }

    public function transfer_request(){
        $order_query = "SELECT * FROM tbl_transfer_payment 
                        INNER JOIN tbl_order ON tbl_order.order_id=tbl_transfer_payment.order_id
                        INNER JOIN tbl_customer ON tbl_order.customer_id=tbl_customer.customer_id 
                        WHERE tbl_transfer_payment.transferred_status=0";
        $order_obj = $this->conn->prepare($order_query);
        if ($order_obj->execute()) {
            return $order_obj->get_result();
        }
        return array();
    }

    public function update_transfer_request($order_id){
        $transfer_query = "UPDATE tbl_transfer_payment SET transferred_status=1 WHERE order_id=$order_id";
        $transfer_query2 = "UPDATE tbl_payment SET payment_status='Paid' WHERE order_id=$order_id";
        $order_status_query = "UPDATE tbl_order SET order_status='Processing/shipped' WHERE order_id=$order_id";
        $transfer_obj = $this->conn->prepare($transfer_query);
        $transfer_obj2 = $this->conn->prepare($transfer_query2);
        $order_status_obj = $this->conn->prepare($order_status_query);
        if ($transfer_obj->execute()) {
            if ($transfer_obj2->execute()){
                $order_status_obj->execute();
                if ($this->send_order_receipt_mail_to_customer($order_id)){
                    return true;
                }
            }
        }
        return false;
    }

    public function send_order_receipt_mail_to_customer($id){
        $req_query = "SELECT * FROM tbl_transfer_payment 
                        INNER JOIN tbl_order ON tbl_order.order_id=tbl_transfer_payment.order_id 
                        INNER JOIN tbl_customer ON tbl_order.customer_id=tbl_customer.customer_id
                        WHERE tbl_transfer_payment.order_id=$id";
        $req_obj = $this->conn->prepare($req_query);
        if ($req_obj->execute()){
            $res = $req_obj->get_result();
            $data= $res->fetch_assoc();
            $toEmail = $data['email'];
            $link="https://$_SERVER[HTTP_HOST]";
            $subject = "Amazon Lagos Order Receipt";
            $name = $data['fullname'];
            $content = "<html>
                        <head>
                            <meta http-equiv='Content-Type' content='text/html; charset=utf-8'>
                            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
                            <title>AMAZON LAGOS</title>
                            <style>
                             @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;500;700;900&display=swap');
                            * {box-sizing: border-box;}
                            body {font-family: 'Roboto', sans-serif;margin: 0;padding: 0;font-size: 14px;line-height: 10px;}
                            .brand_logo{width: 120px;}
                            .brand_logo img{width: 100%;}
                            h2 {margin: 0;}
                            .wrapper {max-width: 600px;margin: 0 auto;line-height: 15px;}
                            th {background-color: #c3df34;color: #ffffff;padding: .8em .7em;}
                            .brand_logo {text-align: left;}
                            </style>
                        </head>
                        <body>
                        <div class='wrapper'>
                            <table>
                                <thead>
                                    <tr><th class='table-head' colspan='4'><h1 class='company-name'>Receipt from Amazon Lagos</h1></th></tr>
                                </thead>
                                <tbody>
                                    <div class='mt-3'>
                                        <p>Hi, ".$name."</p>
                                        <p>Your payment was successful and has been received by Amazon Lagos.</p>
                                        <h4>Amount Paid: <span style='color:#740774;'>₦".number_format($data['order_amount'],0)."</span></h4>
                                        <h5>Quantity: ".$data['order_qty']."</h5>
                                        <h5 >Order Reference: #".$data['order_ref']."</h5>
                                        <hr style='width: 100%; margin: auto;' />
                                        <p style='color:#c3df34;text-align:center;'>". date('l F j Y', strtotime($data['order_on']))."</p>
                                        <p>If you have questions or issues with this payment, contact Amazon Lagos at 
                                        support@amazonlagos.com or simply reply to this email.</p>
                                    </div>
                                </tbody>
                            </table>
                        </div>
                        </body>
                        </html>";
            $mailHeaders ="MIME-Version: 1.0"."\r\n";
            $mailHeaders .="Content-type:text/html;charset=UTF-8"."\r\n";
            $mailHeaders .= "From: Amazon Lagos <support@amazonlagos.com>\r\n";
            if (mail($toEmail, $subject, $content, $mailHeaders)) {
                return true;
            }
            return false;
        }
        return false;
    }

    public function payments(){
        $order_query = "SELECT * FROM tbl_payment 
                        INNER JOIN tbl_order ON tbl_order.order_id=tbl_payment.order_id
                        INNER JOIN tbl_customer ON tbl_order.customer_id=tbl_customer.customer_id
                        ";
        $order_obj = $this->conn->prepare($order_query);
        if ($order_obj->execute()) {
            return $order_obj->get_result();
        }
        return array();
    }

    public function count_new_order(){
        $cnt = mysqli_num_rows(mysqli_query($this->conn, "SELECT * FROM tbl_order WHERE order_status='New Order'"));
        if ($cnt > 0) return $cnt;
        return 0;
    }

    public function get_last_order_time(){
        $order_query = "SELECT order_status,order_on,order_id FROM tbl_order WHERE order_status='New Order' ORDER BY order_id DESC";
        $order_obj = $this->conn->prepare($order_query);
        if ($order_obj->execute()) {
            $data= $order_obj->get_result()->fetch_assoc();
            return $data['order_on'];
        }
        return array();
    }

    public function read_shopping_list() {
        $list_query = "SELECT * FROM tbl_shopping_list";
        $list_obj = $this->conn->prepare($list_query);
        if ($list_obj->execute()) {
            return $list_obj->get_result();
        }
        return array();
    }

    public function read_shopping_list_details($shop_id) {
        $list_query = "SELECT * FROM tbl_shopping_list_details WHERE shopping_list_id=$shop_id";
        $list_obj = $this->conn->prepare($list_query);
        if ($list_obj->execute()) {
            return $list_obj->get_result();
        }
        return array();
    }

    public function read_shopping_list_payment($shop_id) {
        $list_query = "SELECT * FROM tbl_shopping_list_payment WHERE shopping_list_id=$shop_id";
        $list_obj = $this->conn->prepare($list_query);
        if ($list_obj->execute()) {
            return $list_obj->get_result();
        }
        return array();
    }

    public function read_shopping_list_by_id($shop_id) {
        $list_query = "SELECT * FROM tbl_shopping_list WHERE sno=$shop_id LIMIT 1";
        $list_obj = $this->conn->prepare($list_query);
        if ($list_obj->execute()) {
            return $list_obj->get_result();
        }
        return array();
    }

    public function update_shopping_list_payment_status($shopping_list_id){
        $pay_query = "UPDATE tbl_shopping_list SET shop_payment_status='Paid' WHERE sno=$shopping_list_id";
        $pay_obj = $this->conn->prepare($pay_query);
        if ($pay_obj->execute()) {
            return true;
        }
        return false;
    }

   

    public function list_vendor_due_payment_item(){
        $order_query = "SELECT * FROM tbl_order_details
                        INNER JOIN tbl_product ON tbl_product.product_id=tbl_order_details.product_id
                        INNER JOIN tbl_order ON tbl_order.order_id=tbl_order_details.order_id 
                        INNER JOIN tbl_brand ON tbl_brand.brand_id=tbl_product.brand_id 
                        WHERE tbl_order_details.returned ='N' AND tbl_order.order_on >= DATE_SUB(NOW(), INTERVAL 1 WEEK)
                        AND tbl_order_details.vendor_pay_status='No'
                        ORDER BY tbl_order_details.order_details_id DESC";
        $order_obj = $this->conn->prepare($order_query);
        if ($order_obj->execute()) {
            return $order_obj->get_result();
        }
        return array();
    }

    public function find_order_item_detail_by_vendor($bid,$year){
        $ven_query = "SELECT * FROM tbl_order_details
                        INNER JOIN tbl_order ON tbl_order.order_id=tbl_order_details.order_id 
                        INNER JOIN tbl_product ON tbl_product.product_id=tbl_order_details.product_id 
                        WHERE tbl_product.brand_id=$bid AND YEAR(tbl_order.order_on)='$year'";
        $ven_obj = $this->conn->prepare($ven_query);
        if ($ven_obj->execute()) {
            return $ven_obj->get_result();
        }
        return array();
    }

    public function find_order_by_brand_id($bid,$year){
        $ven_query = "SELECT SUM(tbl_order_details.product_qty*tbl_product.product_price) As totAl FROM tbl_order_details
                        INNER JOIN tbl_product ON tbl_product.product_id=tbl_order_details.product_id 
                        INNER JOIN tbl_order ON tbl_order.order_id=tbl_order_details.order_id 
                        WHERE tbl_product.brand_id=$bid AND YEAR(tbl_order.order_on)='$year' AND tbl_order_details.returned='N'";
        $ven_obj = $this->conn->prepare($ven_query);
        if ($ven_obj->execute()) {
            $d= $ven_obj->get_result()->fetch_assoc();
            return $d['totAl'];
        }
        return array();
    }

    public function find_returned_order_by_brand_id($bid,$year){
        $ven_query = "SELECT SUM(tbl_order_details.product_qty*tbl_product.product_price) As totAl FROM tbl_order_details
                        INNER JOIN tbl_product ON tbl_product.product_id=tbl_order_details.product_id 
                        INNER JOIN tbl_order ON tbl_order.order_id=tbl_order_details.order_id 
                        WHERE tbl_product.brand_id=$bid AND YEAR(tbl_order.order_on)='$year' AND tbl_order_details.returned='Y'
                        AND tbl_order_details.vendor_pay_status='Yes'";
        $ven_obj = $this->conn->prepare($ven_query);
        if ($ven_obj->execute()) {
            $d= $ven_obj->get_result()->fetch_assoc();
            return $d['totAl'];
        }
        return array();
    }

    public function get_brand_name_by_id($bid){
        $query = "SELECT * FROM tbl_brand WHERE brand_id=$bid";
        $req_obj = $this->conn->prepare($query);
        if ($req_obj->execute()){
            $res = $req_obj->get_result()->fetch_assoc();
            return $res['brand_name'];
        }
    }

//    public function find_order_rev_ret_by_month($bid,$year,$month,$sta,$ret){
//        $ven_query = "SELECT SUM(tbl_order_details.product_qty*tbl_product.product_price) As totAl FROM tbl_order_details
//                        INNER JOIN tbl_product ON tbl_product.product_id=tbl_order_details.product_id
//                        INNER JOIN tbl_order ON tbl_order.order_id=tbl_order_details.order_id
//                        WHERE tbl_product.brand_id=$bid AND YEAR(tbl_order.order_on)='$year' AND tbl_order_details.returned='$ret'
//                        AND tbl_order_details.vendor_pay_status='$sta' AND MONTH(tbl_order.order_on)='$month'";
//        $ven_obj = $this->conn->prepare($ven_query);
//        if ($ven_obj->execute()) {
//
//        }
//    }

}
$admin = new Admin();
?>
