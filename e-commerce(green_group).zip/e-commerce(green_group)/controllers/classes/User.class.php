<?php


class User
{
    public  $firstname;
    public  $lastname;
    public $email;
    public $phone;
    public $password;
    public $reset_selector;

    public $customer_id;
    public $new_password;

    public $order_id;
    public $order_detail_id;
    public $product_id;

    private $conn;
    private $tbl_customer;

    //constructor
    public function __construct($db) {
        $this->conn = $db;
        $this->tbl_customer = 'tbl_customer';
    }

    public function create_subscriber() {
        $client_query = "INSERT INTO tbl_newsletter SET client_email=?";
        $client_obj = $this->conn->prepare($client_query);
        $this->email = htmlspecialchars(strip_tags($this->email));
        $client_obj->bind_param("s",$this->email);
        if ($client_obj->execute()){
            return true;
        }
        return false;
    }

    public function check_news_subscriber_email(){
        $email_query = "SELECT * FROM tbl_newsletter WHERE client_email=?";
        $client_obj = $this->conn->prepare($email_query);
        $client_obj->bind_param("s", $this->email);
        if ($client_obj->execute()){
            $data = $client_obj->get_result();
            return $data->fetch_assoc();
        }
        return array();
    }

    public function create_user() {
        $cust_query = "INSERT INTO ".$this->tbl_customer." SET firstname=?,lastname=?,email=?,phone=?,password=?,active='1'";
        $cust_obj = $this->conn->prepare($cust_query);
        //sanitize variables
        $this->firstname = htmlspecialchars(strip_tags($this->firstname));
        $this->lastname = htmlspecialchars(strip_tags($this->lastname));
        $this->email = htmlspecialchars(strip_tags($this->email));
        $this->phone = htmlspecialchars(strip_tags($this->phone));
        $this->password = htmlspecialchars(strip_tags($this->password));
        //bind parameter
        $cust_obj->bind_param("sssss",$this->firstname,$this->lastname,$this->email,$this->phone,$this->password);
        //execute query
        if ($cust_obj->execute()){
            //login on successfully signup
            $email_query = "SELECT customer_id,firstname,lastname,email,phone FROM ".$this->tbl_customer." WHERE email=?";
            $user_obj = $this->conn->prepare($email_query);
            $user_obj->bind_param("s", $this->email);
            if ($user_obj->execute()){
                $data = $user_obj->get_result();
                return $data->fetch_assoc();
            }
        }
        return array();
    }

    public function check_email(){
        $email_query = "SELECT * FROM ".$this->tbl_customer." WHERE email=?";
        $cust_obj = $this->conn->prepare($email_query);
        $cust_obj->bind_param("s", $this->email);
        if ($cust_obj->execute()){
            $data = $cust_obj->get_result();
            return $data->fetch_assoc();
        }
        return array();
    }

    public function login_user() {
        $email_query = "SELECT * FROM ".$this->tbl_customer." WHERE email=? AND active='1'";
        $user_obj = $this->conn->prepare($email_query);
        $user_obj->bind_param("s", $this->email);
        if ($user_obj->execute()){
            $data = $user_obj->get_result();
            return $data->fetch_assoc();
        }
        return array();
    }

    public function reset_password_request(){
        $selector = bin2hex(random_bytes(8));
        $token = random_bytes(32);

        $host = "https://$_SERVER[HTTP_HOST]";
        $url= $host."/reset-password/".$selector."/".bin2hex($token);

        $expires = date("U") + 1200;

        //Delete any existing user token entry
        $del_reset_obj = $this->conn->prepare("DELETE FROM tbl_pwd_reset WHERE reset_email=?");
        $del_reset_obj->bind_param("s",$this->email);
        $del_reset_obj->execute();

        //Insert reset credentials
        $reset_query = "INSERT INTO tbl_pwd_reset SET reset_email=?,reset_selector=?,reset_token=?,reset_expires=?";
        $reset_obj = $this->conn->prepare($reset_query);
        $hashedToken = password_hash($token, PASSWORD_DEFAULT);
        $reset_obj->bind_param("ssss",$this->email,$selector,$hashedToken,$expires);
        //execute query
        if ($reset_obj->execute()){
            $to = $this->email;
            $subject = "AmazonLagos password reset";
            $content = "<html>
                    <head>
                        <meta http-equiv='Content-Type' content='text/html; charset=utf-8'>
                        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
                        <title>AmazonLagos</title>
                        <style>
                            @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;500;700;900&display=swap');
                            * { box-sizing: border-box;}h2 {margin: 0;}
                            body {font-family: \"Roboto\", sans-serif;margin: 0;padding: 0;font-size:14px;}
                            .wrapper {max-width: 500px;margin: 0 auto;line-height: 30px;}table { margin: 2em;}
                            th {background-color: #c3df34;color: #ffffff;padding: .8em .7em;}
                            .brand_logo { text-align: left;}
                            @media(min-width: 700px) { body {font-size: 16px;}}
                        </style>
                    </head>
                    <body>
                    <div class='wrapper'>
                        <table>
                            <thead>
                                <tr><th><h2 class='brand_logo'>
                                    <img src='https://i.ibb.co/fr2hHrd/brandlogo-white.png' alt='brandlogo-white' border='0'>
                                    </h2></th></tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        <p>
                                        You’re receiving this mail because you requested a password reset for your &nbsp;
                                        <span>AMAZON LAGOS</span>.
                                            <br /><br />
                                            Please tap the link below to create a new password :<br />
                                            <a class='not-active' href='".$url."'>".$url."</a>
                                        </p>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    </body>
                </html>";
            $mailHeaders ="MIME-Version: 1.0"."\r\n";
            $mailHeaders .="Content-type:text/html;charset=UTF-8"."\r\n";
            $mailHeaders .= "From: AmazonLagos <support@amazonlagos.com>\r\n";
            if (mail($to, $subject, $content, $mailHeaders)) {
                return true;
            }
            return false;
        }
        return false;
    }

    public function check_reset_pwd_credentials(){
        $currentDate = date("U");
        $email_query = "SELECT * FROM tbl_pwd_reset WHERE reset_selector=? AND reset_expires >= ?";
        $cust_obj = $this->conn->prepare($email_query);
        $cust_obj->bind_param("ss", $this->reset_selector,$currentDate);
        if ($cust_obj->execute()){
            $data = $cust_obj->get_result();
            return $data->fetch_assoc();
        }
        return array();
    }

    public function update_reset_password() {
        $update_query = "UPDATE ".$this->tbl_customer." SET password=? WHERE email=?";
        $update_obj = $this->conn->prepare($update_query);
        $update_obj->bind_param("ss",$this->password,$this->email);
        if ($update_obj->execute()){
            if ($update_obj->affected_rows > 0) {
                //Delete any existing user token entry
                $del_reset_obj = $this->conn->prepare("DELETE FROM tbl_pwd_reset WHERE reset_email=?");
                $del_reset_obj->bind_param("s",$this->email);
                $del_reset_obj->execute();
                return true;
            }
            return false;
        }
        return false;
    }

    public function update_user_profile(){
        $update_query = "UPDATE ".$this->tbl_customer." SET firstname=?,lastname=?,email=?,phone=? WHERE customer_id=?";
        $update_obj = $this->conn->prepare($update_query);
        $update_obj->bind_param("ssssi",$this->firstname,$this->lastname,$this->email,$this->phone,$this->customer_id);
        if ($update_obj->execute()){
            if ($update_obj->affected_rows > 0){
                return true;
            }
            return false;
        } else {
            return false;
        }
    }

    public function update_complete_user_profile(){
        $update_query = "UPDATE ".$this->tbl_customer." SET firstname=?,lastname=?,email=?,phone=?,password=? WHERE customer_id=?";
        $update_obj = $this->conn->prepare($update_query);
        $update_obj->bind_param("sssssi",$this->firstname,$this->lastname,$this->email,$this->phone,$this->new_password,$this->customer_id);
        if ($update_obj->execute()){
            if ($update_obj->affected_rows > 0){
                return true;
            }
            return false;
        } else {
            return false;
        }
    }

    public function read_customer_wish_list_(){
        $wlist_query = "SELECT * FROM tbl_wishlist
                        INNER JOIN tbl_product ON tbl_wishlist.product_id=tbl_product.product_id
                        WHERE tbl_wishlist.customer_id=?";
        $wlist_obj = $this->conn->prepare($wlist_query);
        $wlist_obj->bind_param("i",$this->customer_id);
        if ($wlist_obj->execute()) {
            return $wlist_obj->get_result();
        }
        return array();
    }

    public function delete_customer_wish_list_item($cid,$wid){
        $delquery = "DELETE FROM tbl_wishlist WHERE customer_id=$cid AND wlist_id=$wid";
        $delete_obj = $this->conn->prepare($delquery);
        if ($delete_obj->execute()){
            if ($delete_obj->affected_rows > 0){
                return true;
            }
            return false;
        } else {
            return false;
        }
    }

    public function get_latest_shop_to_address($cid){
        $query = "SELECT order_id,receiver_address,receiver_state FROM tbl_order WHERE customer_id=$cid ORDER BY order_id DESC LIMIT 1";
        $add_obj = $this->conn->prepare($query);
        if ($add_obj->execute()){
            $address = $add_obj->get_result();
            if ($address->num_rows > 0){ return $address->fetch_assoc(); }
            return false;
        }
        return false;
    }

    public function orders(){
        $order_query = "SELECT * FROM tbl_order INNER JOIN tbl_payment ON tbl_payment.order_id=tbl_order.order_id WHERE tbl_order.customer_id=?";
        $order_obj = $this->conn->prepare($order_query);
        $order_obj->bind_param("i",$this->customer_id);
        if ($order_obj->execute()) {
            return $order_obj->get_result();
        }
        return array();
    }

    public function order_by_id(){
        $order_query = "SELECT * FROM tbl_order WHERE order_id=?";
        $order_obj = $this->conn->prepare($order_query);
        $order_obj->bind_param("i",$this->order_id);
        if ($order_obj->execute()) {
            return $order_obj->get_result();
        }
        return array();
    }

    public function order_by_payment(){
        $order_query = "SELECT * FROM tbl_payment 
                        INNER JOIN tbl_order ON tbl_payment.order_id=tbl_order.order_id
                        WHERE tbl_payment.order_id=?";
        $order_obj = $this->conn->prepare($order_query);
        $order_obj->bind_param("i",$this->order_id);
        if ($order_obj->execute()) {
            return $order_obj->get_result();
        }
        return array();
    }

    public function order_by_product(){
        $order_query = "SELECT * FROM tbl_order_details
                        INNER JOIN tbl_product ON tbl_order_details.product_id=tbl_product.product_id
                        WHERE tbl_order_details.order_id=?";
        $order_obj = $this->conn->prepare($order_query);
        $order_obj->bind_param("i",$this->order_id);
        if ($order_obj->execute()) {
            return $order_obj->get_result();
        }
        return array();
    }

    public function read_product_by_order_details_id(){
        $order_query = "SELECT * FROM tbl_order_details
                        INNER JOIN tbl_product ON tbl_order_details.product_id=tbl_product.product_id
                        WHERE tbl_order_details.product_id=? AND tbl_order_details.order_details_id=?";
        $order_obj = $this->conn->prepare($order_query);
        $order_obj->bind_param("si",$this->product_id,$this->order_detail_id);
        if ($order_obj->execute()) {
            return $order_obj->get_result();
        }
        return array();
    }

    public function order_pending_review(){
        $order_query = "SELECT * FROM tbl_order
                        INNER JOIN tbl_order_details ON tbl_order_details.order_id=tbl_order.order_id  
                        INNER JOIN tbl_product ON tbl_product.product_id=tbl_order_details.product_id  
                        WHERE tbl_order_details.customer_id=? AND tbl_order_details.review_status=0";
        $order_obj = $this->conn->prepare($order_query);
        $order_obj->bind_param("i",$this->customer_id);
        if ($order_obj->execute()) {
            return $order_obj->get_result();
        }
        return array();
    }

    public function send_contact_us_mail($email,$message){
            $toEmail = 'amazonlagos20@gmail.com';
            $link="https://$_SERVER[HTTP_HOST]";
            $subject = "Contact Us Alert!";
            $content = "<html>
                        <head>
                            <meta http-equiv='Content-Type' content='text/html; charset=utf-8'>
                            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
                            <title>AMAZON LAGOS</title>
                            <style>
                                @import url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;0,500;0,700;0,900;1,300&display=swap');
                                body {font-family: 'Roboto', sans-serif;font-weight: 400}
                                .wrapper {max-width: 600px;margin: 0 auto}
                                .company-name {text-align: left}
                                table {width: 80%;}
                            </style>
                        </head>
                        <body>
                        <div class='wrapper'>
                            <table>
                                <thead>
                                    <tr><th class='table-head' colspan='4'><h1 class='company-name'>AMAZONLAGOS</h1></th></tr>
                                </thead>
                                <tbody>
                                    <div class='mt-3'>
                                        <p>Hi, Admin</p>
                                        <p>".$email.". send the following message: </p>
                                        <p>".$message."</a></p>
                                    </div>
                                </tbody>
                            </table>
                        </div>
                        </body>
                        </html>";
            $mailHeaders ="MIME-Version: 1.0"."\r\n";
            $mailHeaders .="Content-type:text/html;charset=UTF-8"."\r\n";
            $mailHeaders .= "From: AMAZONLAGOS <".$email.">\r\n";
            if (mail($toEmail, $subject, $content, $mailHeaders)) {
                return true;
            }
            return false;
    }

    public function update_order_details_return($odi){
        $de_query = "UPDATE tbl_order_details SET returned='Y' WHERE order_details_id=$odi";
        $de_obj = $this->conn->prepare($de_query);
        if ($de_obj->execute()) {
//            if ($this->send_return_mail_admin($odi)){
            return true;
        }
//            return false;
//        }
        return false;
    }

    public function check_returned_order_item($odi){
        $email_query = "SELECT * FROM tbl_order_details INNER JOIN tbl_order ON tbl_order.order_id=tbl_order_details.order_id
                        WHERE tbl_order_details.order_details_id=$odi AND tbl_order.order_status ='Delivered' AND tbl_order.order_on > DATE_SUB(NOW(), INTERVAL 1 WEEK)";
        $user_obj = $this->conn->prepare($email_query);
        if ($user_obj->execute()){
            $data = $user_obj->get_result();
            if ($data->num_rows > 0){return true;}
            return false;
        }
        return false;
    }

    public function check_returned_order_item_status($odi){
        $email_query = "SELECT * FROM tbl_order_details WHERE order_details_id=$odi AND returned='Y'";
        $user_obj = $this->conn->prepare($email_query);
        if ($user_obj->execute()){
            $data = $user_obj->get_result();
            if ($data->num_rows > 0){return true;}
            return false;
        }
        return false;
    }
}

?>