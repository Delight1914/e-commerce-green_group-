<?php
ob_start();
session_start();
if (!isset($_SESSION['user_login']) && !isset($_SESSION['user_login']['customer_id'])) header('Location: login');
include_once("inc/header.nav.php");
?>
<div class="container" id="checkout_success_response_page">
    <div class="inner_container">
        <div class="text-center bg-white p-5">
            <h5>THANK YOU FOR THE FEEDBACK</h5>
            <p class="pt-3">
                <a href='account/pending-review' class='d-block font-weight-bolder light_grn_btn px-5 py-3 text-white'>GO BACK TO PENDING REVIEWS</a>
            </p>
        </div>
    </div>
</div>

<script src="./js/jquery-3.5.1.min.js"></script>
<script src="./js/popper.min.js"></script>
<script src="./js/bootstrap.min.js"></script>
<script src="./js/owl.carousel.min.js"></script>
<script src="./js/serialObject.js"></script>
<script src="./js/jquery.validate.min.js"></script>
<script src="./js/main.js"></script>
<script src="./js/action-reducer.js"></script>
<script src="./js/cart-reducer.js"></script>
<script src="./js/toastr.min.js"></script>
</body>
</html>
