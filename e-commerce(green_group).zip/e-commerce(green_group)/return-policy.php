<?php ob_start(); session_start(); include_once("inc/header.nav.php"); ?>
<div id="return_and_refund_policy_page">
    <div class="cont_wrapper">
        <ul class="breadcrumb"><li><a href="./">Home</a></li><li><a href="javascript:void(0)">Help</a></li><li>Return and Refund Policy</li></ul>
    </div>
    <div class="title_container px-3 py-0">
        <div class="cont_wrapper"><h4 class="page_title text-center text-md-left m-0 text_capital">Return and Refund Policy</h4></div>
    </div>
    <div class="page_banner my-3"></div>
    <div class="content_content_wrapper bg-white p-4">
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quo sequi excepturi alias ducimus tempora laudantium ratione nemo labore pariatur, officia, itaque dignissimos dicta ipsam sit iusto quod voluptate minus veniam maiores debitis nesciunt qui vel repellendus? Reiciendis deserunt quo libero debitis ipsa magnam, similique consequuntur amet ipsam ullam repudiandae officiis hic modi quisquam? Ab magnam dignissimos mollitia provident, a est minima consequatur cupiditate vitae facilis adipisci rerum, dolores tenetur, in beatae doloribus ullam laudantium unde sunt odio similique. Voluptatum modi cumque commodi error culpa ad soluta! Hic impedit maiores fuga autem consequuntur. Eaque labore saepe aliquam, rerum eligendi deleniti quaerat excepturi consectetur, at magni cumque nihil, possimus natus temporibus blanditiis laborum eius non. Dolores velit aspernatur obcaecati, reprehenderit ipsum hic cumque itaque. Doloribus saepe blanditiis veniam dolorem quo itaque hic voluptate accusamus excepturi inventore? Ullam labore fugit sapiente porro aspernatur! Illum, rerum perspiciatis non tempore earum maiores eos alias saepe, exercitationem amet nemo repellendus blanditiis laborum molestiae, mollitia consequatur odio in nulla. Fuga sequi illum esse vero, nobis distinctio. Quasi quidem dolore voluptatem, id, sapiente, odit 
            commodi minus ut qui neque vel ad! Similique beatae exercitationem perferendis, earum corrupti iusto totam corporis quae labore sit? Soluta illum ducimus eveniet magni?
        </p>
        <section>
            <h5>Return Instructions</h5>
            <dl>
                <dt>Step 1: Prepare the Item</dt>
                <dd>
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Est, similique.
                </dd>
                <dt>Step 2: Drop Off the Items or Schedule a Pick up</dt>
                <dd>
                   Lorem ipsum dolor sit amet consectetur adipisicing elit. Cumque, qui.
                </dd>
                <dt>Step 3: Refund Processed</dt>
                <dd>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellendus, incidunt!
                </dd>
            </dl>
        </section>
        <section>
            <h5>Items not eligible for Returns</h5>
            <ol>
                <li>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Debitis enim quibusdam velit dolorum veniam ab magni obcaecati ducimus porro molestiae.</li>
                <li>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Debitis enim quibusdam velit dolorum veniam ab magni obcaecati ducimus porro molestiae.</li>
                <li>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Debitis enim quibusdam velit dolorum veniam ab magni obcaecati ducimus porro molestiae.</li>
                <li>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Debitis enim quibusdam velit dolorum veniam ab magni obcaecati ducimus porro molestiae.</li>
                <li>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Debitis enim quibusdam velit dolorum veniam ab magni obcaecati ducimus porro molestiae.</li>
                <li>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Debitis enim quibusdam velit dolorum veniam ab magni obcaecati ducimus porro molestiae.</li>
                <li>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Debitis enim quibusdam velit dolorum veniam ab magni obcaecati ducimus porro molestiae.</li>
                
            </ol>
        </section>
    </div>
</div>
<?php include_once("inc/footer.nav.php"); ?>