<?php ob_start(); session_start();
if (isset($_SESSION['user_login']) && isset($_SESSION['user_login']['customer_id'])) header('Location: index');
include_once("inc/header.nav.php"); ?>
    <style>.cstm_inner_wrapper {max-width: 650px;margin: 120px auto; }</style>
<div class="cont_wrapper" id="reset_password">
    <div class="bg-white cstm_inner_wrapper mt-5 pb-5">
        <div class="border-bottom p-3 text-center"><h6 class="m-0">Forgot Password</h6></div>

        <div class="errorResponse"></div>

        <div class="text-center py-4 px-2 successResp" style="display: grid; place-content: center">
            <p>Please enter the email address you registered with. We will send you a link</p>
            <form name="reset_pwd_form" id="reset_pwd_form">
                <div class="form_grp my-3">
                    <input class="py-2" type="text" placeholder="Enter email address" name="email" aria-label="">
                    <button type="submit" class="light_grn_btn py-2 px-3 rounded" id="reset_btn">
                        <i class="fa fa-spinner fa-spin mr-3 d-none"></i>Send Link
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php include_once("inc/footer.nav.php"); ?>