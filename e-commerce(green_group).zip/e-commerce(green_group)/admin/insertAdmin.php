<?php
include_once('../controllers/config/database.php');
include_once('../controllers/classes/Admin.class.php');

if ($admin->create_admin_user('Test Test',"admin@test.com",password_hash("test123", PASSWORD_DEFAULT))){
    echo "DONE";
} else {
    echo "ERROR";
}

?>