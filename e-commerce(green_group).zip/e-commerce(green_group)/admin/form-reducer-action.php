<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Content-type: application/json; charset=UTF-8");
include_once('../controllers/classes/Admin.class.php');

if ($_SERVER['REQUEST_METHOD'] === "POST") {
    $data = json_decode(file_get_contents("php://input"));
    if (trim($data->action_code) == '101' && !empty(trim($data->cat_name))) {
        if ($admin->add_category_product($data->cat_name)) {
            http_response_code(200);
            echo json_encode(array("status" => 1, "message" => "Product category successfully created."));
        } else  {
            http_response_code(500);
            echo json_encode(array("status" => 0, "message" => "Unable to Add Category."));
        }
    }

    if (trim($data->action_code) == '102' && !empty(trim($data->cat_id))) {
        if ($admin->delete_category_product($data->cat_id)) {
            http_response_code(200);
            echo json_encode(array("status" => 1, "message" => "Product category deleted successfully."));
        } else  {
            http_response_code(500);
            echo json_encode(array("status" => 0, "message" => "Unable to delete category."));
        }
    }

    if (trim($data->action_code) == '103' && !empty(trim($data->edit_cat_name)) && !empty(trim($data->edit_cat_id))) {
        if ($admin->update_category_product($data->edit_cat_id,$data->edit_cat_name)) {
            http_response_code(200);
            echo json_encode(array("status" => 1, "message" => "Product category updated successfully."));
        } else {
            http_response_code(500);
            echo json_encode(array("status" => 0, "message" => "Unable to update category."));
        }
    }

    if (trim($data->action_code) == '202' && !empty(trim($data->brand_id))) {
        if ($admin->delete_product_brand($data->brand_id)) {
            http_response_code(200);
            echo json_encode(array("status" => 1, "message" => "Product brand deleted successfully."));
        } else  {
            http_response_code(500);
            echo json_encode(array("status" => 0, "message" => "Unable to delete brand."));
        }
    }

    if (trim($data->action_code) == '203' && !empty(trim($data->edit_brand_name)) && !empty(trim($data->edit_brand_id))) {
        if ($admin->update_product_brand($data->edit_brand_id,$data->edit_brand_name)) {
            http_response_code(200);
            echo json_encode(array("status" => 1, "message" => "Product brand updated successfully."));
        } else {
            http_response_code(500);
            echo json_encode(array("status" => 0, "message" => "Unable to update brand."));
        }
    }

    if (trim($data->action_code) == '301' && !empty(trim($data->cat_id)) && !empty(trim($data->subcat_name))) {
        if ($admin->add_product_subcategory($data->subcat_name,$data->cat_id)) {
            http_response_code(200);
            echo json_encode(array("status" => 1, "message" => "Product sub-category successfully created."));
        } else  {
            http_response_code(500);
            echo json_encode(array("status" => 0, "message" => "Unable to Add Sub-Category."));
        }
    }

    if (trim($data->action_code) == '302' && !empty(trim($data->subcat_id))) {
        if ($admin->delete_subcategory_product($data->subcat_id)) {
            http_response_code(200);
            echo json_encode(array("status" => 1, "message" => "Product sub-category deleted successfully."));
        } else  {
            http_response_code(500);
            echo json_encode(array("status" => 0, "message" => "Unable to delete sub-category."));
        }
    }

    if (trim($data->action_code) == '303' && !empty(trim($data->edit_subcat_name)) && !empty(trim($data->edit_cat_id)) && !empty(trim($data->edit_subcat_id))) {
        if ($admin->update_product_subcategory($data->edit_subcat_id,$data->edit_subcat_name,$data->edit_cat_id)) {
            http_response_code(200);
            echo json_encode(array("status" => 1, "message" => "Product sub-category updated successfully."));
        } else {
            http_response_code(500);
            echo json_encode(array("status" => 0, "message" => "Unable to update sub-category."));
        }
    }

    if (trim($data->action_code) == '401' && !empty(trim($data->username))) {
        if ($admin->create_admin_user($data->username,$data->email,$data->role,$data->password)) {
            http_response_code(200);
            echo json_encode(array("status" => 1, "message" => "Admin User successfully created."));
        } else  {
            http_response_code(500);
            echo json_encode(array("status" => 0, "message" => "Unable to Create User."));
        }
    }

    if (trim($data->action_code) == '402' && !empty(trim($data->admin_id))) {
        if ($admin->delete_admin_user($data->admin_id)) {
            http_response_code(200);
            echo json_encode(array("status" => 1, "message" => "Admin user deleted successfully."));
        } else {
            http_response_code(500);
            echo json_encode(array("status" => 0, "message" => "Unable to delete user."));
        }
    }

    if (trim($data->action_code) == '403' && !empty(trim($data->edit_adm_username))) {
        if ($admin->update_admin_user($data->edit_adm_username,$data->edit_adm_email,$data->edit_adm_role,$data->edit_adm_id)) {
            http_response_code(200);
            echo json_encode(array("status" => 1, "message" => "Admin user updated successfully."));
        } else {
            http_response_code(500);
            echo json_encode(array("status" => 0, "message" => "Unable to update user."));
        }
    }

    if (trim($data->action_code) == '501' && !empty(trim($data->coupon_title))) {
        if ($admin->create_coupon_code($data->coupon_title,$data->coupon_discount,$data->coupon_valid)) {
            http_response_code(200);
            echo json_encode(array("status" => 1, "message" => "Coupon Code successfully created."));
        } else  {
            http_response_code(500);
            echo json_encode(array("status" => 0, "message" => "Unable to Create Coupon Code."));
        }
    }

    if (trim($data->action_code) == '502' && !empty(trim($data->coupon_id))) {
        if ($admin->delete_coupon_code($data->coupon_id)) {
            http_response_code(200);
            echo json_encode(array("status" => 1, "message" => "Coupon code deleted successfully."));
        } else {
            http_response_code(500);
            echo json_encode(array("status" => 0, "message" => "Unable to delete coupon code."));
        }
    }

    if (trim($data->action_code) == '602' && !empty(trim($data->product_id))) {
        if ($admin->delete_product($data->product_id)) {
            http_response_code(200);
            echo json_encode(array("status" => 1, "message" => "Product deleted successfully."));
        } else {
            http_response_code(500);
            echo json_encode(array("status" => 0, "message" => "Unable to delete product."));
        }
    }

    if (trim($data->action_code) == '603' && !empty(trim($data->title))) {
        $a =$data->title;$b = $data->sku;$c =(int)$data->category;$d =(int)$data->subcategory;
        $b_id = isset($data->brand)?(int)$data->brand:null;$e =(float)$data->price;
        $f = isset($data->size)?$data->size:'';$g = isset($data->os)?$data->os:'';
        $h =$data->overview;$i =$data->description;$j =$data->warranty;
        if ($admin->update_product($a,$b,$c,$d,$b_id,$e,$f,$g,$h,$i,$j,$data->p_id)) {
            http_response_code(200);
            echo json_encode(array("status" => 1, "message" => "Product updated successfully."));
        } else {
            http_response_code(500);
            echo json_encode(array("status" => 0, "message" => "Unable to update product."));
        }
    }

    if (trim($data->action_code) == '1001' && !empty(trim($data->ven_brand_name))) {
        $ven_brand_name = $data->ven_brand_name;
        $ven_year = $data->ven_year;
        $filter = $admin->find_order_by_brand_id($ven_brand_name,$ven_year);
        $return = $admin->find_returned_order_by_brand_id($ven_brand_name,$ven_year);
        $brand = $admin->get_brand_name_by_id($ven_brand_name);
//
        http_response_code(200); //200 means Ok status
        echo json_encode(array("status"=>200,"revenue"=>$filter,"returned"=>$return,"brand"=>$brand));


    }
}