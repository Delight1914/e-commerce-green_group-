<!-- footer start-->
<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6 footer-copyright">
                <p class="mb-0">Copyright 2020 © GAC Corporation All rights reserved.</p>
            </div>
        </div>
    </div>
</footer>
<!-- footer end-->
</div>

</div>

<script src="./adminJs/jquery-3.3.1.min.js"></script>
<script src="./adminJs/popper.min.js"></script>
<script src="./adminJs/bootstrap.js"></script>
<script src="./adminJs/icons/feather-icon/feather.min.js"></script>
<script src="./adminJs/icons/feather-icon/feather-icon.js"></script>

<script src="./adminJs/serialObject.js"></script>
<script src="./adminJs/jquery.validate.min.js"></script>

<script src="./adminJs/jquery.dataTables.min.js"></script>

<script src="./adminJs/sidebar-menu.js"></script>

<script src="./adminJs/counter/jquery.waypoints.min.js"></script>
<script src="./adminJs/counter/jquery.counterup.min.js"></script>
<script src="./adminJs/counter/counter-custom.js"></script>

<!--dashboard custom js-->
<script src="./adminJs/admin-script.js"></script>
<script src="./adminJs/toastr.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>


</body>
</html>
