<?php
include_once('../../controllers/classes/Admin.class.php');

$out = "<option value=''>--Select Subcategory--</option>";
if ($_SERVER['REQUEST_METHOD'] === "GET" && !empty($_GET['cat_id'])) {
    $sub = $admin->get_subcategory_by_cat_id($_GET['cat_id']);
    if ($sub->num_rows > 0) {
        while ($subcat = $sub->fetch_assoc()) {
            $out.="<option value='".$subcat['subcat_id']."'>" .$subcat['subcat_name']."</option>";
        }
    }
}
echo $out;
?>