<?php include_once("adminComponents/aheader.nav.php") ; ?>
<div class="page-body">
    <!-- Container-fluid starts-->
    <div class="container-fluid">
        <div class="page-header">
            <div class="row">
                <div class="col-lg-6">
                    <div class="page-header-left">
                        <h3>
                            ADD PRODUCTS<small>GAC Corporation Admin panel</small>
                        </h3>
                    </div>
                </div>
                <div class="col-lg-6">
                    <ol class="breadcrumb pull-right">
                        <li class="breadcrumb-item"><a href="dashboard"><i data-feather="home"></i></a></li>
                        <li class="breadcrumb-item">Products</li>
                        <li class="breadcrumb-item active">Add</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <!-- Container-fluid Ends-->

    <div class="container-fluid">
        <div class="row product-adding">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-header">
                        <h5>Product Details</h5>
                    </div>
                    <form name="createProduct" id="createProduct">
                    <div class="card-body">
                        <div class="digital-add needs-validation">
                            <div class="row">
                                <div class="form-group col-md-8">
                                    <label for="title" class="col-form-label pt-0"><span>*</span> Product Title</label>
                                    <input class="form-control prep_sku" id="title" name="title" type="text">
                                    <input type="hidden" name="action_code" value="601">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="category" class="col-form-label pt-0"><span>*</span> Categories</label>
                                    <select class="custom-select" name="category" id="category">
                                        <option value="">--Select Category--</option>
                                        <?php
                                        $cat = $admin->list_product_category();
                                        if ($cat->num_rows > 0) {
                                        while ($category = $cat->fetch_assoc()) {
                                        ?>
                                        <option value="<?=$category['cat_id'];?>"><?=$category['category_name'];?></option>
                                        <?php } }?>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="sku" class="col-form-label pt-0"><span>*</span> SKU</label>
                                    <input class="form-control" id="sku" name="sku" type="text">
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="brand" class="col-form-label pt-0">Brand</label>
                                    <select class="custom-select" name="brand" id="brand">
                                        <option value="">--Select Brand--</option>
                                        <?php
                                        $bra = $admin->list_product_brand();
                                        if ($bra->num_rows > 0) {
                                            while ($brand = $bra->fetch_assoc()) {
                                                ?>
                                                <option value="<?=$brand['brand_id'];?>"><?=$brand['brand_name'];?></option>
                                            <?php } }?>
                                    </select>
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="subcategory" class="col-form-label pt-0"><span>*</span> Sub Categories</label>
                                    <select class="custom-select" name="subcategory" id="subcategory">
                                        <option value="">--Select Subcategory--</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row tvExtraFilter" style="display: none;">
                                <div class="form-group col-md-6">
                                    <label for="size" class="col-form-label pt-0"><span>*</span> Screen Size</label>
                                    <select class="custom-select" name="size" id="size">
                                        <option value="">--Select Screen Size--</option>
                                        <option value='24Inches'>24" (inches)</option>
                                        <option value='32Inches'>32" (inches)</option>
                                        <option value='40Inches'>40" (inches)</option>
                                        <option value='43Inches'>43" (inches)</option>
                                        <option value='49Inches'>49" (inches)</option>
                                        <option value='50Inches'>50" (inches)</option>
                                        <option value='55Inches'>55" (inches)</option>
                                        <option value='65Inches'>65" (inches)</option>
                                        <option value='75Inches'>75" (inches)</option>
                                        <option value='90Inches'>90" (inches)</option>
                                    </select>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="os" class="col-form-label pt-0"><span>*</span> Operating System</label>
                                    <select class="custom-select" name="os" id="os">
                                        <option value="">--Select Operating System--</option>
                                        <option value="Android">Android</option>
                                        <option value="Linux">Linux</option>
                                        <option value="Other">Other</option>
                                        <option value="None">None</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-5">
                                    <label class="col-form-label pt-2"><span>*</span> Product Image</label>
                                    <input type="file" id="image" name="image" class="form-control">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="price" class="col-form-label pt-2"><span>*</span> Product Price (₦)</label>
                                    <input type="number" id="price" name="price" class="form-control">
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="warranty" class="col-form-label pt-2"><span>*</span> Product Warranty (Years)</label>
                                    <input type="number" id="warranty" name="warranty" class="form-control">
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="description" class="col-form-label">Product Specifications (separated by ;)</label>
                                    <textarea name="description" id="description" rows="5" cols="12"></textarea>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="overview" class="col-form-label">Product Overview</label>
                                    <textarea name="overview" id="overview" rows="5" cols="12"></textarea>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col"><hr style="1px solid #ccc" /></div>
                            </div>
                            <div class="form-group mb-0">
                                <div class="product-buttons text-center">
                                    <button type="submit" class="btn btn-primary" id="createProductBtn">
                                        <i class="fa fa-spinner fa-spin mr-3 d-none"></i>Create Product
                                    </button>
                                    <button type="reset" class="btn btn-light">Discard</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include_once("adminComponents/afooter.nav.php") ; ?>
<script src="adminJs/admin-form-reducer.js"></script>
<script>
    $('.prep_sku').on('blur', function () {
        $('input[name="sku"]').val(($(this).val()).replace(/[^a-z0-9\s]/gi, '').replace(/[_\s]/g,'-').toLowerCase());
        $('input[name="title"]').val(($(this).val()).replace(/[^a-z0-9\s]/gi, ''));
    });
    $("#category").on('change', function () {
        $("#subcategory").load("adminComponents/subCatGetter.php?cat_id=" + $("#category").val());
    });
    $("#subcategory").on('change', function () {
        var selected_option = $('#subcategory').val();
        if (selected_option === '6413') {$('.tvExtraFilter').show();}
        if (selected_option !== '6413') {$(".tvExtraFilter").hide();}
    });
</script>
