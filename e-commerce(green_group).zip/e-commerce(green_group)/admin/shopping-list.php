<?php include_once("adminComponents/aheader.nav.php") ; ?>
<div class="page-body">
    <!-- Container-fluid starts-->
    <div class="container-fluid">
        <div class="page-header">
            <div class="row">
                <div class="col-lg-6">
                    <div class="page-header-left">
                        <h3>Shopping List<small>GAC Corporation Admin panel</small></h3>
                    </div>
                </div>
                <div class="col-lg-6">
                    <ol class="breadcrumb pull-right">
                        <li class="breadcrumb-item"><a href="dashboard"><i data-feather="home"></i></a></li>
                        <li class="breadcrumb-item">Shopping List</li>
                        <li class="breadcrumb-item active">All</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <!-- Container-fluid Ends-->
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header"><h5>Shopping List</h5></div>
                    <div class="card-body">
                        <table class="display" id="Product">
                            <thead>
                            <tr>
                                <th></th>
                                <th>Order ID</th>
                                <th>FullName</th>
                                <th>Email</th>
                                <th>WhatsApp No</th>
                                <th>Payment Status</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php
                            $list= $admin->read_shopping_list();
                            if ($list->num_rows > 0) {$n=0;
                            while ($s_list = $list->fetch_assoc()) {
                            ?>
                            <tr>
                                <td><?=++$n;?></td>
                                <td>#<?=$s_list['shopping_list_id'];?></td>
                                <td><?=$s_list['shop_fullname'];?></td>
                                <td><?=$s_list['shop_email'];?></td>
                                <td><?=$s_list['shop_phone'];?></td>
                                <td><span class="text-info"><?=$s_list['shop_payment_status'];?></span></td>
                                <td>
                                    <a href="shopping-list-details/<?=$s_list['sno'];?>" class="btn btn-success">
                                        <i class="fa fa-spinner fa-spin mr-3 d-none"></i>View Item Details
                                    </a>
                                </td>
                            </tr>
                            <?php } } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include_once("adminComponents/afooter.nav.php") ; ?>
    <script src="adminJs/admin-form-reducer.js"></script>
    <script>
        $(document).ready(function() {
            $('#Product').DataTable({
                "bSort":false
            });
        });
    </script>
