<?php include_once("adminComponents/aheader.nav.php") ; ?>
<div class="page-body">
    <!-- Container-fluid starts-->
    <div class="container-fluid">
        <div class="page-header">
            <div class="row">
                <div class="col-lg-6">
                    <div class="page-header-left">
                        <h3>
                            Product List<small>GAC Corporation Admin panel</small>
                        </h3>
                    </div>
                </div>
                <div class="col-lg-6">
                    <ol class="breadcrumb pull-right">
                        <li class="breadcrumb-item"><a href="dashboard"><i data-feather="home"></i></a></li>
                        <li class="breadcrumb-item">Products</li>
                        <li class="breadcrumb-item active">List</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <!-- Container-fluid Ends-->

    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <h5>Product List</h5>
                    </div>
                    <div class="card-body">
                        <table class="display" id="Product">
                            <thead>
                            <tr>
                                <th>Product Id</th>
                                <th>Image</th>
                                <th>Title</th>
                                <th>Category</th>
                                <th>SubCategory</th>
                                <th>Brand</th>
                                <th>Price</th>
                                <th>Size</th>
                                <th>O.S</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php
                            $prod = $admin->list_products();
                            if ($prod->num_rows > 0) {
                                while ($product = $prod->fetch_assoc()) {
                                    ?>
                                    <tr>
                                        <td class="font-weight-bold">#<?= $product['product_id'];?></td>
                                        <td><img src="./adminImg/products/<?=$product['product_img'];?>" alt="" style="height: 50px; width: 50px;"></td>
                                        <td><h6><?=$product['product_title'];?></h6></td>
                                        <td><h6><?=$product['category_name'];?></h6></td>
                                        <td><h6><?=$product['subcat_name'];?></h6></td>
                                        <td><h6><?=$product['brand_name'];?></h6></td>
                                        <td class="font-weight-bold text-success">
                                            <h6>₦<?=number_format($product['product_price'],0); ?></h6>
                                        </td>
                                        <td><h6><?=$product['product_size'];?></h6></td>
                                        <td><h6><?=$product['product_os'];?></h6></td>
                                        <td>
                                            <div>
                                                <a href="edit-product/<?= $product['product_id']; ?>"><i style="cursor: pointer;" class="fa fa-edit mr-2 font-success"></i></a>
                                                <i style="cursor: pointer;" class="fa fa-trash font-danger" id="delete_product" data-id="<?= $product['product_id'];?>"></i>
                                            </div>
                                        </td>
                                    </tr>
                                <?php } }?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include_once("adminComponents/afooter.nav.php") ; ?>
    <script src="adminJs/admin-form-reducer.js"></script>
    <script>
        $(document).ready(function() {
            $('#Product').DataTable({
                "bSort":false
            });
        });
    </script>
