<?php include_once("adminComponents/aheader.nav.php") ; ?>
<div class="page-body">
    <!-- Container-fluid starts-->
    <div class="container-fluid">
        <div class="page-header">
            <div class="row">
                <div class="col-lg-6">
                    <div class="page-header-left">
                        <h3>
                            Top 6 Best Selling Product<small>GAC Corporation Admin panel</small>
                        </h3>
                    </div>
                </div>
                <div class="col-lg-6">
                    <ol class="breadcrumb pull-right">
                        <li class="breadcrumb-item"><a href="dashboard"><i data-feather="home"></i></a></li>
                        <li class="breadcrumb-item active">Best Selling</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <!-- Container-fluid Ends-->

    <div class="container-fluid">
        <div class="row products-admin ratio_asos">
            <?php
            $prod = $admin->list_best_selling();
            if ($prod->num_rows > 0) {
            while ($product = $prod->fetch_assoc()) {
            ?>
            <div class="col-xl-3 col-sm-6">
                <div class="card product">
                    <div class="card-body">
                        <div class="product-box p-0">
                            <div class="product-imgbox">
                                <div class="product-front">
                                    <img src="./adminImg/products/<?=$product['product_img'];?>" class="img-fluid  " alt="product">
                                </div>
                                <div class="product-back">
                                    <img src="./adminImg/products/<?=$product['product_img'];?>" class="img-fluid  " alt="product">
                                </div>
                                <div class="new-label1">
                                    <div><?=$product['TotalQty'];?></div>
                                </div>
                            </div>
                            <div class="product-detail detail-inline p-0">
                                <div class="detail-title">
                                    <div class="detail-left">
                                        <div class="rating-star">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <a href="#">
                                            <h6 class="price-title"><?=$product['product_title'];?></h6>
                                        </a>
                                    </div>
                                    <div class="detail-right">
                                        <div class="price">
                                            <div class="price">₦ <?=$product['product_price'];?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php } } ?>
        </div>
    </div>
</div>

<?php include_once("adminComponents/afooter.nav.php") ; ?>
<script src="adminJs/admin-form-reducer.js"></script>

