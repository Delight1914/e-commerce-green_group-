<?php
include_once ('../controllers/classes/Admin.class.php');

if (isset($_GET['order_id'])) {
    if ($admin->update_order_status($_GET['order_id'])) {
        http_response_code(200);
        echo json_encode(array("status" => 200, "message" => "Order status updated and mark as delivered"));
    }
}

if (isset($_GET['code']) && $_GET['code']==300){
    if ($admin->update_shopping_list_payment_status($_GET['shop_list_payment_id'])){
        http_response_code(200);
        echo json_encode(array("status"=>200,"message"=>"Order status updated and mark as delivered"));
    }
}

if (isset($_GET['code']) && $_GET['code']==400 && isset($_GET['order_details_id'])){
    if ($admin->update_vendor_due_payment_status($_GET['order_details_id'])){
        http_response_code(200);
        echo json_encode(array("status"=>200,"message"=>"Vendor payment status updated mark as paid"));
    }
}

?>