<?php include_once("adminComponents/aheader.nav.php") ; ?>
<div class="page-body">
    <!-- Container-fluid starts-->
    <div class="container-fluid">
        <div class="page-header">
            <div class="row">
                <div class="col-lg-6">
                    <div class="page-header-left">
                        <h3>Shopping List Details<small>GAC Corporation Admin panel</small></h3>
                    </div>
                </div>
                <div class="col-lg-6">
                    <ol class="breadcrumb pull-right">
                        <li class="breadcrumb-item"><a href="dashboard"><i data-feather="home"></i></a></li>
                        <li class="breadcrumb-item">Shopping List</li>
                        <li class="breadcrumb-item active">Details</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <!-- Container-fluid Ends-->
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-8">
                <div class="card">
                    <div class="card-header py-3"><h5 style="font-size:1.1em">Shopping List Items</h5></div>
                    <div class="card-body">
                        <div class="table-responsive map-table mt-0">
                            <table class="table mb-0">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Product Name</th>
                                    <th>Producer/Author</th>
                                    <th>Quantity</th>
                                    <th>Size/Color/Other</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                $list= $admin->read_shopping_list_details($_GET['shop_list_id']);
                                if ($list->num_rows > 0) {$n=0;
                                while ($s_list = $list->fetch_assoc()) {
                                ?>
                                    <tr>
                                        <td>#<?=++$n;?></td>
                                        <td><?=$s_list['shop_product_name'];?></td>
                                        <td><?=$s_list['shop_producer'];?></td>
                                        <td><?=$s_list['shop_qty'];?></td>
                                        <td><?=$s_list['shop_cos'];?></td>
                                    </tr>
                                <?php } } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="card">
                    <div class="card-header py-3"><h5 style="font-size:1.1em">Shopping List Payment Status</h5></div>
                    <div class="card-body payment-data">
                        <?php
                        $list= $admin->read_shopping_list_by_id($_GET['shop_list_id']);
                        if ($list->num_rows > 0) { while ($s_list = $list->fetch_assoc()) {
                        ?>
                            <h5 class="text-danger">Order Id : #<?=$s_list['shopping_list_id'];?></h5>
                            <?php if ($s_list['shop_payment_status']=='Unverified') { ?>
                                <button class="btn btn-primary btn-block mt-3" data-id="<?=$s_list['sno'];?>" type="submit" id="payment_status">Make Payment As Confirm</button>
                            <?php } else { ?>
                                <button class="btn btn-success btn-block mt-3" style="cursor: not-allowed" disabled>Paid</button>
                            <?php } ?>
                        <?php } } ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include_once("adminComponents/afooter.nav.php") ; ?>
    <script src="adminJs/admin-form-reducer.js"></script>
    <script>
        $(document).ready(function() {
            $('#Product').DataTable({
                "bSort":false
            });

            $(".payment-data").on("click",'#payment_status',function (e) {
                e.preventDefault();
                var shop_list_payment_id = $(this).data('id');
                $.get("shop-list-action.php?shop_list_payment_id="+shop_list_payment_id, function () {
                    toastr["success"]('Payment status updated successfully');
                    setTimeout(function () {window.location.reload()}, 1500);
                });
            });
        });
    </script>
