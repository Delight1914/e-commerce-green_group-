<?php session_start(); ?>
<?php
if (isset($_GET['admin_id']) && $_GET['admin_id'] != NULL) {
    unset($_SESSION['adminLogin']);
    header("Location: ../");
}
?>
