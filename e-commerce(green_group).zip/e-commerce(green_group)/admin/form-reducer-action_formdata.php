<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Content-type: application/json; charset=UTF-8");
include_once('../controllers/classes/Admin.class.php');

if ($_SERVER['REQUEST_METHOD'] === "POST") {
    if (trim($_POST['action_code']) == '201' && !empty(trim($_POST['brand_name']))) {
        $uploadDir = 'adminImg/brands/';

        if(!empty($_FILES["brand_img"]["name"])){
            $fileName = basename($_FILES["brand_img"]["name"]);
            $targetFilePath = $uploadDir . $fileName;
            $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);
            $allowTypes = array('jpg', 'png', 'jpeg');
            if(in_array($fileType, $allowTypes)){
                if(move_uploaded_file($_FILES["brand_img"]["tmp_name"], $targetFilePath)){
                    if ($admin->add_product_brand($_POST['brand_name'],$fileName)){
                        http_response_code(200);
                        echo json_encode(array("status" => 1, "message" => "Product brand successfully created."));
                    }  else  {
                        http_response_code(500);
                        echo json_encode(array("status" => 0, "message" => "Unable to create brand."));
                    }
                } else{
                    echo json_encode(array("status" => 0, "message" => "Sorry, there was an error uploading your file."));
                    exit();
                }
            } else {
                http_response_code(500);
                echo json_encode(array("status" => 0, "message" => "Sorry, only JPG, JPEG, & PNG files are allowed to upload."));
                exit();
            }
        } else {
            http_response_code(500);
            echo json_encode(array("status" => 0, "message" => "Product image is missing "));
            exit();
        }
    }

    if (trim($_POST['action_code']) == '601' && !empty(trim($_POST['title']))) {
        $uploadDir = 'adminImg/products/';
        $a =$_POST['title'];$b =$_POST['sku'];$c =$_POST['category'];$d =$_POST['subcategory'];$b_id =$_POST['brand'];
        $e =$_POST['price'];$f =$_POST['size'];$g =$_POST['os'];$h =$_POST['overview'];$i =$_POST['description'];$j =$_POST['warranty'];

        if(!empty($_FILES["image"]["name"])){
//            $fileName = basename($_FILES["image"]["name"]);
            $fileName = bin2hex(random_bytes(16));
            $fileType = pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION);
            $targetFilePath = $uploadDir.$fileName.'.'.$fileType;
            $allowTypes = array('jpg', 'png', 'jpeg');
            if(in_array($fileType, $allowTypes)){
                if(move_uploaded_file($_FILES["image"]["tmp_name"], $targetFilePath)){
                    if ($admin->create_product($a,$b,$c,$d,$b_id,$e,$f,$g,$h,$i,$j,$fileName.'.'.$fileType)){
                        http_response_code(200);
                        echo json_encode(array("status" => 1, "message" => "Product added successfully."));
                    }  else  {
                        http_response_code(500);
                        echo json_encode(array("status" => 0, "message" => "Unable to add product."));
                    }
                } else{
                    echo json_encode(array("status" => 0, "message" => "Sorry, there was an error uploading your file."));
                    exit();
                }
            } else {
                http_response_code(500);
                echo json_encode(array("status" => 0, "message" => "Sorry, only JPG, JPEG, & PNG files are allowed to upload."));
                exit();
            }
        } else {
            http_response_code(500);
            echo json_encode(array("status" => 0, "message" => "Product image is missing "));
            exit();
        }
    }


}