$(function() {
    $("form[name='addCategory']").validate({
        rules: {cat_name: {"required":true,minlength:3}},
        submitHandler: function (form, e) {
            e.preventDefault();
            var addCategory = $('#addCategory');
            var form_data = JSON.stringify(addCategory.serializeObject());
            $("#addCategoryBtn").attr("disabled", true);
            $('#addCategoryBtn').css("cursor", 'not-allowed');
            $(".fa-spin").addClass("d-inline-block");

            $.ajax({
                url: "form-reducer-action.php",
                type: "POST",
                contentType: 'application/json',
                data: form_data,
                success: function (data) {
                    toastr.options = {"closeButton": true, "positionClass": "toast-top-right"};
                    toastr["success"](data.message);
                    setTimeout(function () {
                        document.getElementById("addCategory").reset();
                        window.location.replace('product-category');
                    }, 1500);
                },
                error: function (errData) {
                    toastr.options = {"closeButton": true, "positionClass": "toast-top-right"};
                    toastr["error"](errData.responseJSON.message);
                },
                complete: function () {
                    $('#addCategoryBtn').attr("disabled", false);
                    $('#addCategoryBtn').css("cursor", 'pointer');
                    $(".fa-spin").removeClass("d-inline-block");
                }
            });
        }
    });

    $("form[name='updateCategory']").validate({
        rules: {edit_cat_name: {"required":true,minlength:3}},
        submitHandler: function (form, e) {
            e.preventDefault();
            var updateCategory = $('#updateCategory');
            var form_data = JSON.stringify(updateCategory.serializeObject());
            $("#updateCategoryBtn").attr("disabled", true);
            $('#updateCategoryBtn').css("cursor", 'not-allowed');
            $(".fa-spin").addClass("d-inline-block");

            $.ajax({
                url: "form-reducer-action.php",
                type: "POST",
                contentType: 'application/json',
                data: form_data,
                success: function (data) {
                    toastr.options = {"closeButton": true, "positionClass": "toast-top-right"};
                    toastr["success"](data.message);
                    setTimeout(function () {
                        document.getElementById("updateCategory").reset();
                        window.location.replace('product-category');
                    }, 1000);
                },
                error: function (errData) {
                    toastr.options = {"closeButton": true, "positionClass": "toast-top-right"};
                    toastr["error"](errData.responseJSON.message);
                },
                complete: function () {
                    $('#updateCategoryBtn').attr("disabled", false);
                    $('#updateCategoryBtn').css("cursor", 'pointer');
                    $(".fa-spin").removeClass("d-inline-block");
                }
            });
        }
    });

    $("form[name='addBrand']").validate({
        rules: {
            brand_name: {"required":true,minlength:3},
            brand_img: "required"
            },
        submitHandler: function (form, e) {
            e.preventDefault();
            var addBrand = $('#addBrand');
            $("#addBrandBtn").attr("disabled", true);
            $('#addBrandBtn').css("cursor", 'not-allowed');
            $(".fa-spin").addClass("d-inline-block");

            $.ajax({
                url: "form-reducer-action_formdata.php",
                type: "POST",
                data: new FormData(form),
                dataType: 'json',
                contentType: false,
                cache: false,
                processData:false,
                success: function (data) {
                    toastr["success"](data.message);
                    setTimeout(function () {
                        document.getElementById("addBrand").reset();
                        window.location.replace('product-brand');
                    }, 1500);
                },
                error: function (errData) {
                    toastr["error"](errData.responseJSON.message);
                },
                complete: function () {
                    $('#addBrandBtn').attr("disabled", false);
                    $('#addBrandBtn').css("cursor", 'pointer');
                    $(".fa-spin").removeClass("d-inline-block");
                }
            });
        }
    });

    $("form[name='updateBrand']").validate({
        rules: {edit_brand_name: {"required":true,minlength:3}},
        submitHandler: function (form, e) {
            e.preventDefault();
            var updateBrand = $('#updateBrand');
            var form_data = JSON.stringify(updateBrand.serializeObject());
            $("#updateBrandBtn").attr("disabled", true);
            $('#updateBrandBtn').css("cursor", 'not-allowed');
            $(".fa-spin").addClass("d-inline-block");

            $.ajax({
                url: "form-reducer-action.php",
                type: "POST",
                contentType: 'application/json',
                data: form_data,
                success: function (data) {
                    toastr.options = {"closeButton": true, "positionClass": "toast-top-right"};
                    toastr["success"](data.message);
                    setTimeout(function () {
                        document.getElementById("updateBrand").reset();
                        window.location.replace('product-brand');
                    }, 1000);
                },
                error: function (errData) {
                    toastr.options = {"closeButton": true, "positionClass": "toast-top-right"};
                    toastr["error"](errData.responseJSON.message);
                },
                complete: function () {
                    $('#updateBrandBtn').attr("disabled", false);
                    $('#updateBrandBtn').css("cursor", 'pointer');
                    $(".fa-spin").removeClass("d-inline-block");
                }
            });
        }
    });

    $("form[name='addSubCategory']").validate({
        rules: {
            subcat_name: {"required":true,minlength:3},
            cat_id: "required"
        },
        submitHandler: function (form, e) {
            e.preventDefault();
            var addSubCategory = $('#addSubCategory');
            var form_data = JSON.stringify(addSubCategory.serializeObject());
            $("#addSubCategoryBtn").attr("disabled", true);
            $('#addSubCategoryBtn').css("cursor", 'not-allowed');
            $(".fa-spin").addClass("d-inline-block");

            $.ajax({
                url: "form-reducer-action.php",
                type: "POST",
                contentType: 'application/json',
                data: form_data,
                success: function (data) {
                    toastr.options = {"closeButton": true, "positionClass": "toast-top-right"};
                    toastr["success"](data.message);
                    setTimeout(function () {
                        document.getElementById("addSubCategory").reset();
                        window.location.replace('product-sub-category');
                    }, 1500);
                },
                error: function (errData) {
                    toastr.options = {"closeButton": true, "positionClass": "toast-top-right"};
                    toastr["error"](errData.responseJSON.message);
                },
                complete: function () {
                    $('#addSubCategoryBtn').attr("disabled", false);
                    $('#addSubCategoryBtn').css("cursor", 'pointer');
                    $(".fa-spin").removeClass("d-inline-block");
                }
            });
        }
    });

    $("form[name='updateSubCategory']").validate({
        rules: {
            edit_subcat_name: {"required":true,minlength:3},
            edit_cat_id: "required"
        },
        submitHandler: function (form, e) {
            e.preventDefault();
            var updateSubCategory = $('#updateSubCategory');
            var form_data = JSON.stringify(updateSubCategory.serializeObject());
            $("#updateSubCategoryBtn").attr("disabled", true);
            $('#updateSubCategoryBtn').css("cursor", 'not-allowed');
            $(".fa-spin").addClass("d-inline-block");

            $.ajax({
                url: "form-reducer-action.php",
                type: "POST",
                contentType: 'application/json',
                data: form_data,
                success: function (data) {
                    toastr.options = {"closeButton": true, "positionClass": "toast-top-right"};
                    toastr["success"](data.message);
                    setTimeout(function () {
                        document.getElementById("updateSubCategory").reset();
                        window.location.replace('product-sub-category');
                    }, 1000);
                },
                error: function (errData) {
                    toastr.options = {"closeButton": true, "positionClass": "toast-top-right"};
                    toastr["error"](errData.responseJSON.message);
                },
                complete: function () {
                    $('#updateSubCategoryBtn').attr("disabled", false);
                    $('#updateSubCategoryBtn').css("cursor", 'pointer');
                    $(".fa-spin").removeClass("d-inline-block");
                }
            });
        }
    });

    $("form[name='createUser']").validate({
        rules: {
            username: {required:true,minlength:5},
            email: {required:true,email: true},
            role: "required",
            password: {required:true,minlength:6},
            confirm_password: { equalTo: '[name="password"]'}
        },
        errorPlacement: function(error, element) {
        if(element[0].id === "confirm_password") error.appendTo($(element).parents('div').find($('.errorCPass')));
        if(element[0].id ==='password') error.appendTo($(element).parents('div').find($('.errorPass')));
    },
        submitHandler: function (form, e) {
            e.preventDefault();
            var createUser = $('#createUser');
            var form_data = JSON.stringify(createUser.serializeObject());
            $("#createUserBtn").attr("disabled", true);
            $('#createUserBtn').css("cursor", 'not-allowed');
            $(".fa-spin").addClass("d-inline-block");

            $.ajax({
                url: "form-reducer-action.php",
                type: "POST",
                contentType: 'application/json',
                data: form_data,
                success: function (data) {
                    toastr.options = {"closeButton": true, "positionClass": "toast-top-right"};
                    toastr["success"](data.message);
                    setTimeout(function () {
                        document.getElementById("createUser").reset();
                        window.location.replace('user-list');
                    }, 1500);
                },
                error: function (errData) {
                    toastr.options = {"closeButton": true, "positionClass": "toast-top-right"};
                    toastr["error"](errData.responseJSON.message);
                },
                complete: function () {
                    $('#createUserBtn').attr("disabled", false);
                    $('#createUserBtn').css("cursor", 'pointer');
                    $(".fa-spin").removeClass("d-inline-block");
                }
            });
        }
    });

    $("form[name='updateAdmUser']").validate({
        rules: {
            edit_adm_username: {"required":true,minlength:3},
            edit_adm_email: {"required":true,email:true},
            edit_adm_role: "required"
        },
        submitHandler: function (form, e) {
            e.preventDefault();
            var updateAdmUser = $('#updateAdmUser');
            var form_data = JSON.stringify(updateAdmUser.serializeObject());
            $("#updateAdmUserBtn").attr("disabled", true);
            $('#updateAdmUserBtn').css("cursor", 'not-allowed');
            $(".fa-spin").addClass("d-inline-block");

            $.ajax({
                url: "form-reducer-action.php",
                type: "POST",
                contentType: 'application/json',
                data: form_data,
                success: function (data) {
                    toastr["success"](data.message);
                    setTimeout(function () {
                        document.getElementById("updateAdmUser").reset();
                        window.location.replace('user-list');
                    }, 1000);
                },
                error: function (errData) {
                    toastr["error"](errData.responseJSON.message);
                },
                complete: function () {
                    $('#updateAdmUserBtn').attr("disabled", false);
                    $('#updateAdmUserBtn').css("cursor", 'pointer');
                    $(".fa-spin").removeClass("d-inline-block");
                }
            });
        }
    });

    $("form[name='addCoupon']").validate({
        rules: {
            coupon_title: {"required":true,minlength:5},
            coupon_discount: "required",
            coupon_valid: "required"
        },
        submitHandler: function (form, e) {
            e.preventDefault();
            var addCoupon = $('#addCoupon');
            var form_data = JSON.stringify(addCoupon.serializeObject());
            $("#addCouponBtn").attr("disabled", true);
            $('#addCouponBtn').css("cursor", 'not-allowed');
            $(".fa-spin").addClass("d-inline-block");

            $.ajax({
                url: "form-reducer-action.php",
                type: "POST",
                contentType: 'application/json',
                data: form_data,
                success: function (data) {
                    toastr["success"](data.message);
                    setTimeout(function () {
                        document.getElementById("addCoupon").reset();
                        window.location.replace('coupon-list');
                    }, 1000);
                },
                error: function (errData) {
                    toastr["error"](errData.responseJSON.message);
                },
                complete: function () {
                    $('#addCouponBtn').attr("disabled", false);
                    $('#addCouponBtn').css("cursor", 'pointer');
                    $(".fa-spin").removeClass("d-inline-block");
                }
            });
        }
    });

    $("form[name='createProduct']").validate({
        rules: {
            title: {"required":true,minlength:10},
            category: "required",
            sku: "required",
            subcategory: "required",
            image: "required",
            price: {"required":true,number:true},
            warranty: "required"
        },
        submitHandler: function (form, e) {
            e.preventDefault();
            $("#createProductBtn").attr("disabled", true);
            $('#createProductBtn').css("cursor", 'not-allowed');
            $(".fa-spin").addClass("d-inline-block");

            $.ajax({
                url: "form-reducer-action_formdata.php",
                type: "POST",
                data: new FormData(form),
                dataType: 'json',
                contentType: false,
                cache: false,
                processData:false,
                success: function (data) {
                    toastr["success"](data.message);
                    setTimeout(function () {
                        document.getElementById("createProduct").reset();
                        window.location.replace('product-list');
                    }, 1000);
                },
                error: function (errData) {
                    toastr["error"](errData.responseJSON.message);
                },
                complete: function () {
                    $('#createProductBtn').attr("disabled", false);
                    $('#createProductBtn').css("cursor", 'pointer');
                    $(".fa-spin").removeClass("d-inline-block");
                }
            });
        }
    });

    $("form[name='editProduct']").validate({
        rules: {
            title: {"required":true,minlength:10},
            category: "required",
            sku: "required",
            subcategory: "required",
            price: {"required":true,number:true},
            warranty: "required"
        },
        submitHandler: function (form, e) {
            e.preventDefault();
            var editProduct = $('#editProduct');
            var form_data = JSON.stringify(editProduct.serializeObject());
            $("#editProductBtn").attr("disabled", true);
            $('#editProductBtn').css("cursor", 'not-allowed');
            $(".fa-spin").addClass("d-inline-block");

            $.ajax({
                url: "form-reducer-action.php",
                type: "POST",
                contentType: 'application/json',
                data: form_data,
                success: function (data) {
                    toastr["success"](data.message);
                    setTimeout(function () {
                        document.getElementById("editProduct").reset();
                        window.location.replace('product-list');
                    }, 1000);
                },
                error: function (errData) {
                    toastr["error"](errData.responseJSON.message);
                },
                complete: function () {
                    $('#editProductBtn').attr("disabled", false);
                    $('#editProductBtn').css("cursor", 'pointer');
                    $(".fa-spin").removeClass("d-inline-block");
                }
            });
        }
    });

    $("form[name='vendorReport']").validate({
        rules: {ven_brand_name: "required", ven_year: "required"},
        submitHandler: function (form, e) {
            e.preventDefault();
            var vendorReport = $('#vendorReport');
            var form_data = JSON.stringify(vendorReport.serializeObject());
            $("#vendorReportBtn").attr("disabled", true);$('#vendorReportBtn').css("cursor", 'not-allowed');$(".fa-spin").addClass("d-inline-block");

            $.ajax({
                url: "form-reducer-action.php", type: "POST", contentType: 'application/json', data: form_data,
                success: function (data) {
                    $(".total_revenue").html('₦ '+data.revenue);
                    $(".total_return").html('₦ '+data.returned);
                    $(".headings").html(data.brand);
                },
                error: function (errData) {toastr["error"](errData.responseJSON.message);},
                complete: function () {
                    $('#vendorReportBtn').attr("disabled", false);$('#vendorReportBtn').css("cursor", 'pointer');$(".fa-spin").removeClass("d-inline-block");
                }
            });
        }
    });

});

$(document).on("click", "#delete_category", function (e) {
    e.preventDefault();
    var cat_id = $(this).data("id");
    var r = confirm("Are you sure you want to delete category?");
    if (r===true){
        $.ajax({
            url: "form-reducer-action.php", type: "POST",
            data: JSON.stringify({cat_id:cat_id,action_code:102}),
            success: function (data) {
                toastr["success"](data.message);
                setTimeout(function () {window.location.replace('product-category'); }, 500);
            },
            error: function (errData)  {toastr["error"](data.message); }
        });
    }
});

$(document).on("click", "#edit_category", function (e) {
    e.preventDefault();
    var cat_id = $(this).data("id");
    var cat_name = $(this).data("cat_name");
    $("#edit_cat_name").val(cat_name);
    $("#edit_cat_id").val(cat_id);
});

$(document).on("click", "#delete_brand", function (e) {
    e.preventDefault();
    var brand_id = $(this).data("id");
    var r = confirm("Are you sure you want to delete brand?");
    if (r===true){
        $.ajax({
            url: "form-reducer-action.php", type: "POST",
            data: JSON.stringify({brand_id:brand_id,action_code:202}),
            success: function (data) {
                toastr["success"](data.message);
                setTimeout(function () {window.location.replace('product-brand'); }, 500);
            },
            error: function (errData)  {toastr["error"](data.message); }
        });
    }
});

$(document).on("click", "#edit_brand", function (e) {
    e.preventDefault();
    var brand_id = $(this).data("id");
    var brand_name = $(this).data("brand_name");
    $("#edit_brand_name").val(brand_name);
    $("#edit_brand_id").val(brand_id);
});

$(document).on("click", "#delete_subcategory", function (e) {
    e.preventDefault();
    var subcat_id = $(this).data("id");
    var r = confirm("Are you sure you want to delete subcategory?");
    if (r===true){
        $.ajax({
            url: "form-reducer-action.php", type: "POST",
            data: JSON.stringify({subcat_id:subcat_id,action_code:302}),
            success: function (data) {
                toastr["success"](data.message);
                setTimeout(function () {window.location.replace('product-sub-category'); }, 500);
            },
            error: function (errData)  {toastr["error"](data.message); }
        });
    }
});

$(document).on("click", "#edit_subcategory", function (e) {
    e.preventDefault();
    var subcat_id = $(this).data("id");
    var subcat_name = $(this).data("subcat_name");
    var cat_id = $(this).data("cat_id");
    $("#edit_subcat_name").val(subcat_name);
    $("#edit_subcat_id").val(subcat_id);
    $("#edit_cat_id").val(cat_id);
});

$(document).on("click", "#delete_adm_user", function (e) {
    e.preventDefault();
    var admin_id = $(this).data("id");
    var r = confirm("Are you sure you want to delete admin user?");
    if (r===true){
        $.ajax({
            url: "form-reducer-action.php", type: "POST",
            data: JSON.stringify({admin_id:admin_id,action_code:402}),
            success: function (data) {
                toastr["success"](data.message);
                setTimeout(function () {window.location.replace('user-list'); }, 500);
            },
            error: function (errData)  {toastr["error"](data.message); }
        });
    }
});

$(document).on("click", "#edit_adm_user", function (e) {
    e.preventDefault();
    var id = $(this).data("id");
    var user = $(this).data("user");
    var email = $(this).data("email");
    var role = $(this).data("role");

    $("#edit_adm_id").val(id);
    $("#edit_adm_username").val(user);
    $("#edit_adm_email").val(email);
    $("#edit_adm_role").val(role);
});

$(document).on("click", "#delete_coupon_code", function (e) {
    e.preventDefault();
    var coupon_id = $(this).data("id");
    var r = confirm("Are you sure you want to delete coupon code?");
    if (r===true){
        $.ajax({
            url: "form-reducer-action.php", type: "POST",
            data: JSON.stringify({coupon_id:coupon_id,action_code:502}),
            success: function (data) {
                toastr["success"](data.message);
                setTimeout(function () {window.location.replace('coupon-list'); }, 500);
            },
            error: function (errData)  {toastr["error"](data.message); }
        });
    }
});

$(document).on("click", "#delete_product", function (e) {
    e.preventDefault();
    var product_id = $(this).data("id");
    var r = confirm("Are you sure you want to delete product?");
    if (r===true){
        $.ajax({
            url: "form-reducer-action.php", type: "POST",
            data: JSON.stringify({product_id:product_id,action_code:602}),
            success: function (data) {
                toastr["success"](data.message);
                setTimeout(function () {window.location.replace('product-list'); }, 500);
            },
            error: function (errData)  {toastr["error"](data.message); }
        });
    }
});