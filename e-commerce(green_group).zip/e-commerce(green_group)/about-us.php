<?php ob_start(); session_start(); include_once("inc/header.nav.php"); ?>
    <div id="faq_page">
        <div class="cont_wrapper">
            <ul class="breadcrumb">
                <li><a href="./">Home</a></li><li>About Us</li>
            </ul>
        </div>
        <div class="title_container px-3 py-0">
            <div class="cont_wrapper"><h4 class="page_title text-center text-md-left m-0 text_capital">About Us</h4></div>
        </div>
        <div class="page_banner my-3"></div>
        <div class="content_content_wrapper bg-white p-3">
            <h5 class="text-center py-4">COMPANY OVERVIEW</h5>
            <p class="px-5 text-center">
                GAC Corporation is Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugiat commodi rerum sunt dicta laboriosam sequi pariatur, 
                asperiores similique! Ipsa, quo deleniti? Perferendis blanditiis ex adipisci unde aliquam doloribus, temporibus veritatis libero dolorum voluptas 
                velit aperiam veniam quia nulla quibusdam molestias corrupti. Maiores impedit facilis necessitatibus consequuntur, nisi tenetur adipisci omnis.
            </p>
        </div>
    </div>
<?php include_once("inc/footer.nav.php"); ?>